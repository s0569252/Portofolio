# -*- coding: utf-8 -*-
"""
Created on Sat Jun 26 20:35:47 2021

@author: asus
"""

import spotipy
from spotipy.oauth2 import SpotifyClientCredentials
import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt
import seaborn as sns
import time 
import warnings

client_id = 'cb56a718956647f2a86d622eebad85f3'
client_secret_id = '9ba4edd233174e3e912277e55c6eaef5'

client_credentials_manager = SpotifyClientCredentials(client_id, client_secret_id)
sp = spotipy.Spotify(client_credentials_manager=client_credentials_manager)

# creating function to get playlist 
def TrackIDs(user, playlist_id):
    ids = []
    playlist = sp.user_playlist(user, playlist_id)
    for item in playlist['tracks']['items']:
        track = item['track']
        ids.append(track['id'])
    return ids

ids = TrackIDs('imdimelvana', '5TDtuKDbOhrfW7C58XnriZ')

#now want to check the length of the playlist. My playlist has 37 tracks. 
print(len(ids))
print(ids)

def TrackFeatures(id):
    meta = sp.track(id)
    features = sp.audio_features(id)
    artists = sp.artist(meta['artists'][0]['external_urls']['spotify'])

    # metadata
    name = meta['name']
    album = meta['album']['name']
    artist = meta['album']['artists'][0]['name']
    music_category = artists['genres']
    release_date = meta['album']['release_date']
    length = meta['duration_ms']
    popularity = meta['popularity']
    link = meta['external_urls']['spotify']

    # specific feartures 
    acousticness = features[0]['acousticness']
    danceability = features[0]['danceability']
    energy = features[0]['energy']
    instrumentalness = features[0]['instrumentalness']
    liveness = features[0]['liveness']
    loudness = features[0]['loudness']
    speechiness = features[0]['speechiness']
    tempo = features[0]['tempo']
    time_signature = features[0]['time_signature']
    

    track = [name, album, artist, music_category, release_date, length, popularity, link, danceability, acousticness, danceability, energy, instrumentalness, liveness, loudness, speechiness, tempo, time_signature]
    return track
# loop over each track Ids 
tracks = []
for i in range(len(ids)):
   time.sleep(.5)
   track = TrackFeatures(ids[i])
   tracks.append(track)

# wrap dataset in dataframe
df = pd.DataFrame(tracks, columns = ['name', 'album', 'artist', 'music_category', 'release_date', 'length', 'popularity', 'link', 'danceability', 'acousticness', 'danceability', 'energy', 'instrumentalness', 'liveness', 'loudness', 'speechiness', 'tempo', 'time_signature'])
df.to_csv("spotifydatawithgenre.csv", sep = ',')

# convert dataframe to csv named spotifyafro and export to desktop 
df.to_csv('C:/Users/asus/OneDrive/Desktop/spotifydatawithgenre.csv', sep = ',' )


#read extracted data

pop_data = pd.read_csv("spotifydatawithgenre.csv")



pop_data.head(5)



#Outliers Check

pop_data.describe()



#DROP UNANMED COLUMN

pop_data.drop('Unnamed: 0', axis=1, inplace=True)



#MOST DANCEABLE SONG IN THE Playlist

pop_data[pop_data.danceability == np.max(pop_data.danceability)]



#TOP 5 danceable songs



pop_data.nlargest(5, ['danceability']) 


#MOST ENERGETIC SONG

pop_data[pop_data.energy == np.max(pop_data.energy)]

#TOP 5 ENERGETIC SONGS

pop_data.nlargest(5, ['energy']) 

    

# with most danceable songs

top_danceability = pop_data[['name','danceability']].sort_values('danceability', ascending=False)[0:10]





plt.figure(figsize=(10,5))

chart = sns.barplot('name','danceability', data=top_danceability,palette ='rocket')

chart.set_xticklabels(chart.get_xticklabels(), rotation = 45)

chart.set(xlabel = 'track', ylabel = 'danceablility')

chart.set_title('Top 10 danceable songs')

    

# CORRELATION BETWEEN LOUDNESS AND DANCEABILITY

sns.jointplot(x='loudness',y='danceability', data=pop_data[['loudness', 'danceability']],kind = 'hex').set_axis_labels("loudness","danceability")



#Most Energetic Artist

energetic_artist = pop_data[['artist','energy']].sort_values('energy', ascending=False)[0:20]

plt.figure(figsize=(10,5))

chart = sns.countplot(y='artist', data=energetic_artist)

chart.set_title('ENERGY')    