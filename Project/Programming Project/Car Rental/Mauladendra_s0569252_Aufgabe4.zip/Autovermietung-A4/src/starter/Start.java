package starter;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.FileAlreadyExistsException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.regex.Pattern;
import daten.Adresse;
import generator.KundenIdGenerator;
import model.Auto;
import model.Autovermietung;
import model.Eingabe;
import model.GeschaeftsKunde;
import model.Kunde;
import model.NameComparator;
import model.PrivatKunde;
import model.Rechnung;
import model.RechnungsBetragComparator;

/**
 * @author Imdi Melvana Mauladendra
 * @version 2.0
 *
 */
public class Start {
	private static Scanner scan = new Scanner(System.in);
	private static Eingabe eingabe = new Eingabe();
	static Adresse adresseCag = new Adresse("Grunertrasse 5","Stockwerk 1, Buerogebaeude A","10179","Berlin");
	static Autovermietung cag = new Autovermietung("Car-AG", adresseCag);
	
	/**
	 * Start
	 * @param args
	 */
	public static void main (String args[]){
		
	Adresse adresseMax = new Adresse("Bodinstrasse 1a","Apartement 2","10217","Berlin");
	Adresse adresseJean = new Adresse("Karl-Marxstasse 6","Gebaeude B","10213","Berlin");
	Adresse adresseAnsel = new Adresse ("Leinestrasse 3","Etage 2, Gebaeude C","10165","Berlin");
	Adresse adresseCarl = new Adresse("Musterstrasse 34","Etage 3, Gebaeude A", "10559", "Berlin");
	
	Auto auto1 = new Auto("B A 3452",200, 1);
	Auto auto2 = new Auto("B HA 455", 500, 1.25);
	Auto auto3 = new Auto("B ER 212", 540, 0.52);
	Auto auto4 = new Auto("B BQ 313", 270, 0.49);
	Auto auto5 = new Auto("B I 123", 170, 0.89);
	
	
	Kunde max = new PrivatKunde("SE-123-BA", "herr", "Max", "Havelar", "11.02.1983", adresseMax, "017633300121", "Havelar@gmail.com");
	Kunde jean = new PrivatKunde("SI-133-NA", "frau", "Jean", "Anastasya", "09.12.1990", adresseJean, "017633212431", "Anastasya@gmail.com");
	Kunde eva = new PrivatKunde("FE-212-KA", "frau", "Eva", "Mueller", "13.06.1993", adresseAnsel, "017413300741", "Jeager@gmail.com");
	//Kunde carl = new PrivatKunde("KO-123-BE", "herr", "Carl", "Hudson", "28.04.1997", adresseCarl,"015325212315", "Hudson@gmail.com");
	Kunde muellergmbh=new GeschaeftsKunde("GE-069-KL", "Mueller Services GMBH", adresseCarl, "015456412121", "MuelllerGMBH@gmail.com");
	
	cag.addKunde("SE-123-BA",max);
	cag.addKunde("SI-133-NA",jean);
	cag.addKunde("FE-212-KA",eva);
	cag.addKunde("GE-069-KL", muellergmbh);
	
	
	max.addAuto(auto1);
	jean.addAuto(auto3);
	muellergmbh.addAuto(auto5);
	
	cag.addAuto("B HA 455",auto2);
	cag.addAuto("B BQ 313",auto4);
	
	Rechnung a= new Rechnung(max,100);
	Rechnung b= new Rechnung(muellergmbh,300);
	Rechnung c= new Rechnung(200);
	Rechnung d= new Rechnung(300);
	Rechnung e= new Rechnung(500);
	Rechnung f= new Rechnung(100);
	Rechnung g= new Rechnung(80);
	Rechnung h= new Rechnung(125);
	Rechnung i= new Rechnung(145);
	Rechnung j= new Rechnung(275);
	
	cag.addRechnung(a);
	cag.addRechnung(b);
	cag.addRechnung(c);
	cag.addRechnung(d);
	cag.addRechnung(e);
	cag.addRechnung(f);
	cag.addRechnung(g);
	cag.addRechnung(h);
	cag.addRechnung(i);
	cag.addRechnung(j);
	
	System.out.println("Autovermietung");
	
	while (true) {
		auswahlMenu();
		int eingabe = eingabeMenu();
		menuEingabe(eingabe);
		System.out.println("\n==================================================");
	}
	}
	
	/**
	 * Metode zum Aufrufen des gewuenschten Menues
	 * @return eingabe
	 */
	private static int eingabeMenu() {
		int ein = eingabe.nummerEingabe("die Nummer des Menueeintrages",1,14);
		return ein;
	}
	
	/**
	 * menueingabe
	 * @param eingabe
	 */
	private static void menuEingabe(int eingabe) {
		switch (eingabe) {
		case 1:
			pkundeAnlegen();
			break;
		case 2:
			fkundeAnlegen();
			break;
		case 3:
			autoAnlegen();
			break;
		case 4:
			autoMieten();
			break;
		case 5:
			kundeAnzeigenNummer();
			break;
		case 6:
			uvAutoAnzeigen();
			break;
		case 7:
			autoAnzeigen();
			break;
		case 8:
			autoAbgeben();
			break;
		case 9:
			rechnungsAnzeigen();
			break;
		case 10:
			zeigtSortRechnung();
			break;
		case 11:
			vermietungsDatenSpeichern();
			break;
		case 12:
			vermietungsDatenLaden();
			break;
		case 13:
			exportCSV();
			break;
		case 14:
			quitApp();
			break;
		
			
		default: {
			System.out.println("Ungueltige Eingabe. Bitte Ihre Eingabe ueberpruefen");
			scan.reset();
			}
		}
	}
	
	
	/**
	 * Methode Privatkunden anlegen 
	 */
	public static void pkundeAnlegen() {
		String kundenId = kundenId();
		String anrede;
		do {
			  anrede = eingabe.stringEingabe("Anrede");
			  }while (!anrede.equalsIgnoreCase("herr") && !anrede.equalsIgnoreCase("frau") && !anrede.equalsIgnoreCase("andere"));
		String vorname = eingabe.stringEingabe("Vorname");
		String name = eingabe.stringEingabe("Nachname");
		String geburtsdatum = eingabe.datumEingabe("Geburtsdatum");
		String email = eingabe.stringEingabe("Email");
		String telefonnummer = eingabe.stringTelefon("Telefonnummer");
		Adresse kundenAdresse = kundeAdresse();
		
		PrivatKunde pkunde = new PrivatKunde(kundenId,anrede,vorname,name,geburtsdatum,kundenAdresse,telefonnummer,email);
		cag.addKunde(kundenId,pkunde);
		System.out.println(pkunde);		
	}
	
	/**
	 * lies Adresse
	 * @return Adresse
	 */
	
	public static Adresse kundeAdresse() {
		String adressZeile1 = eingabe.stringEingabe("Adresszeile1");
		String adressZeile2 = eingabe.stringEingabe("Adresszeile2");
		String plz = eingabe.plzEingabe();
		String ort = eingabe.stringEingabe("Ort");
		
		Adresse adresse = new Adresse(adressZeile1,adressZeile2,plz,ort);

		return adresse;
	}
	
	/**
	 * get KundenID
	 * @return KundenID
	 */
	public static String kundenId() {
		String kundenId;
			KundenIdGenerator kId = new KundenIdGenerator();
			kundenId = kId.getKundenId();
			
		return kundenId;
	}
	
	/**
	 * Methode Firmenkunden anlegen 
	 */
	public static void fkundeAnlegen() {
		String kundenId = kundenId();
		String name = eingabe.stringEingabe("Firmenname");
		String email = eingabe.stringEingabe("email");
		String telefonnummer = eingabe.stringTelefon("telefonnummer");
		Adresse kundenAdresse = kundeAdresse();
		
		GeschaeftsKunde fkunde = new GeschaeftsKunde(kundenId,name,kundenAdresse,telefonnummer,email);
		cag.addKunde(kundenId,fkunde);
		System.out.println(fkunde);
	}

	/**
	 * Methode Auto Anlegen
	 */
	public static void autoAnlegen() {
		
		String Kennzeichen = eingabe.stringEingabe("Kennzeichen eingeben: ");
		double kmStand = eingabe.nummerEingabe("KM Stand", 1, 1000);
		double preis = eingabe.nummerEingabe("Preis", 1, 1000);
		
		Auto auto= new Auto(Kennzeichen, kmStand, preis);
		cag.addAuto(Kennzeichen,auto);
		System.out.println(auto);
	}
	
	/**
	 * lies das gemietete Auto unter der Kundennummer 
	 */
	public static void autoMietenKId() {
		kNummerAnzeigen();
		String kId = eingabe.stringEingabe("die Kundennummer");
		uvAutoAnzeigen();		
		
		String aKenn = eingabe.stringEingabe("Auto Kennzeichen");
		
		if(cag.getKunde(kId)!=null) {
			if(cag.getKunde(kId).getAuto()==null) {
				if(cag.getAuto(aKenn)!=null) {
					cag.getKunde(kId).addAuto(cag.getAuto(aKenn));
					cag.getAutoMap().remove(aKenn);
					System.out.println("Kunde <"+kId+"> hat das Auto <"+ aKenn +"> erfolgreich gemietet!");
				}
				else {
					System.out.println("\nAuto nicht gefunden");	
				}
			}
			else System.out.println("\nNicht erlaubt! Kunde hat bereits ein Auto gemietet");
		}
		else {
			System.out.println("\nKunde nicht gefunden");	
		}
	}
	
	
	/**
	 * lies das gemietete Auto unter dem Namen des Kundes  
	 */
	public static void autoMietenKName() {
		HashMap<String, String> h = new HashMap<>();
		cag.getKundenMap().forEach((k, v) -> h.put(k,v.getName()));
		h.forEach((k, v) -> System.out.println("K: "+k+"\tV: "+v));
		
		String kName = eingabe.nameEingabe();
		uvAutoAnzeigen();
		
		String aKenn = eingabe.stringEingabe("Auto Kennzeichen");
		
		if(h.containsValue(kName)) {
			
			if(cag.getAuto(aKenn)!=null) {
				
				for (Entry<String, String> e : h.entrySet()) {
					if (e.getValue().equalsIgnoreCase(kName)) {
		            	cag.getKunde(e.getKey()).addAuto(cag.getAuto(aKenn));
		            	cag.getAutoMap().remove(aKenn);
		            	System.out.println("Kunde <"+kName+"> hat das Auto <"+ aKenn +"> erfolgreich gemietet!");
		            }
					else System.out.println("\nNicht erlaubt! Kunde hat bereits ein Auto gemietet");
		        }
						
			}
			
		}
		else {
			System.out.println("Kunde nicht gefunden");	
		}

	}
	
	/**
	 * ein Auto wird von Kunden gemietet 
	 */
	public static void autoMieten() {
		System.out.println("(1) KundenId \t (2) Kundenname");
		int rTyp = eingabe.nummerEingabe("Nummer 1 oder Nummer 2",1,2);
		
		if (rTyp==1) {

			autoMietenKId();

		}
		if (rTyp==2) {

			autoMietenKName();
			
			if (rTyp!=1 && rTyp!=2) {
					System.out.print("fehler \n\n");
			}
		
		}
	}
	
	/**
	 * Kundennummer werden angezeigt 
	 */
	public static void kNummerAnzeigen() {	
		cag.getKundenMap().forEach((k, v) -> System.out.println(k+"        "+v.getName()));
	
	}
	
	/**
	 * Kunde mit evtl. gemietetem Auto werden angezeigt. Auswahl durch KundenId 
	 */
	public static void kundeAnzeigenNummer() {
		kNummerAnzeigen();
		String kundenId;
		do {
			kundenId = eingabe.stringEingabe("Bitte geben Sie die verfuegbare Kundennummer von Kunden ein");
			} while (!(Pattern.matches("\\w{2}-\\d{3}-\\w{2}", kundenId)));
				
				if(cag.getKundenMap().containsKey(kundenId)) {
					
					System.out.println(cag.getKundenMap().get(kundenId).toString());
					System.out.println(cag.getKundenMap().get(kundenId).getAuto());
					
				}
				else System.out.println("Nicht gefunden!");
	}
	
	/**
	 * alle unvermieteten Autos werden angezeigt  
	 */
	public static void uvAutoAnzeigen() {
		int i=0;
		for(Auto value : cag.getAutoMap().values()) {
				System.out.println(i+1+") "+value);
			i++;
		}	
	}
	

	/**
	 * Auto mit aktuellem Mieter anzeigen
	 */
	private static void autoAnzeigen() {
		System.out.println("Gemietete Autos: ");
		cag.getKundenMap().forEach((k, v) -> {if (v.getAuto()!=null) System.out.println(v.getAuto().getKennzeichen()+" ===>   Mieter: "+v.getName());});
		String aKenn = eingabe.stringEingabe("Auto Kennzeichen");
		cag.getKundenMap().forEach((k, v) -> {
			if (v.getAuto()!=null) {
				if (v.getAuto().getKennzeichen().equalsIgnoreCase(aKenn)) {
					System.out.println("\n"+v.getAuto().getKennzeichen()+"  ===> "+v.toString());
					}
				}
			}
		);
	}	
	
	/**
	 * Auto wird abgegebn und Rechnung erstellen
	 */
	private static void autoAbgeben() {
		kNummerAnzeigen();
		String kundenId;
		System.out.println("\nAUTO ABGABE");
		do {
		kundenId = eingabe.stringEingabe("die verfuegbare Kundennummer");
		} while (!(Pattern.matches("\\w{2}-\\d{3}-\\w{2}", kundenId)));
			
			if(cag.getKundenMap().containsKey(kundenId)) {
				if(cag.getKunde(kundenId).getAuto()!=null) {
				double neuKmstand = eingabe.doubleEingabe("den neuen Km Stand ");
				Rechnung r = new Rechnung(cag.getKunde(kundenId), neuKmstand);
				cag.addRechnung(r);
				cag.getKunde(kundenId).getAuto().setKmStand(neuKmstand);
				cag.addAuto(cag.getKunde(kundenId).getAuto().getKennzeichen(),cag.getKunde(kundenId).getAuto());
				cag.getKunde(kundenId).setAuto(null);
				System.out.println("\nRechnung "+r.getRechnungsNummer()+" wurde erstellt!");
				}
			else System.out.println("\nNicht erlaubt! Kunde hat noch kein Auto gemietet/Kunde hat schon Auto abgegeben");
			}
			else System.out.println("Nicht gefunden!");

	}
	
	/**
	 * Methode Rechnungs anzeigen durch Rechnungsnummer
	 */
	private static void rechnungsAnzeigen() {
		String rNummer;
		do {
		rNummer = eingabe.stringEingabe("die Rechnungsnummer");
		} while (!(Pattern.matches("\\w{2}\\d{6}\\w{2}", rNummer)));
		
		boolean gefunden=false;
		
		for (int i=0; i<cag.getRechnung().size(); i++) {
		    if(cag.getRechnung().get(i).getRechnungsNummer().equalsIgnoreCase(rNummer)) {
		    	gefunden=true;
		    	System.out.println(cag.getRechnung().get(i).toString());
		    	break;
		    }
		}
		if (!gefunden) {
		    	System.out.println("\nRechnugsnummer "+rNummer+" ist nicht gefunden");
		}
		
	}

	/**
	 * Rechnungs werden mit sortierten Rechnungsbetraegen angezeigt 
	 */
	private static void zeigtSortRechnung() {
		List<Rechnung> rechnungsList = new ArrayList<>(cag.getRechnung());
		System.out.println();
		Collections.sort(rechnungsList, new RechnungsBetragComparator());
		for(int i=0; i<rechnungsList.size(); i++) {
			System.out.println(rechnungsList.get(i).toString());
		}
	}

	/**
	 * Methode Vermietungsdaten speichern
	 */
	public static void vermietungsDatenSpeichern() {
		FileOutputStream file = null;
		String fileName="Vermietung.txt";
		try
        {    
            file = new FileOutputStream(fileName); 
            ObjectOutputStream out = new ObjectOutputStream(file);              
            
            out.writeObject(cag);
            
            out.close(); 
            file.close(); 
              
            System.out.println("Daten wurden gespeichert"); 
            
        } 
          
        catch(FileNotFoundException e0) {
			 System.err.println("Die Datei wurde nicht gefunden.");
		 }
		 catch(FileAlreadyExistsException e1) {
			 System.err.println("Datei existiert bereits.");
		 }
		 catch(IOException e) {
			 System.err.println("Eingabe- oder Ausgabefehler!");
		 }
		catch(Exception exc) {
			 System.err.println("Fehler!");
		} 
	}
	
	/**
	 * Methode Vermietungsdaten laden
	 */
	private static void vermietungsDatenLaden() {
	
		InputStream file = null;
		
		try
		{
			file = new FileInputStream("Vermietung.txt");
			ObjectInputStream o = new ObjectInputStream( file );
			cag= (Autovermietung) o.readObject();
			o.close();
			
			System.out.println(cag.toString());
			cag.getKundenMap().forEach((k, v) -> {System.out.println(k+"        "+v.getName()+" "+v.getAuto());});
			System.out.println(cag.getRechnung());
			
		}
		catch ( IOException e ) { System.err.println( e ); }
		catch ( ClassNotFoundException e ) { System.err.println( e ); }
		finally { try { file.close(); } catch ( Exception e ) { } }
	}


	/**
	 * Csv-Datei wird exportiert
	 */
	private static void exportCSV() {
		String path= "Autovermietung.csv";
		
		 try {
			 List<Kunde> kundenList = new ArrayList<>(cag.getKundenMap().values());
			 Collections.sort(kundenList, new NameComparator());
	    	 FileWriter writer = new FileWriter(path);
	         writer.write("Kundennummer;Name;Kundentyp;Rechnungsbetrag" + System.lineSeparator());
	    		for(String key : cag.getKundenMap().keySet()) {
	    			writer.write(cag.getKundenMap().get(key).getKundenId());
	    			writer.write(";");
	    			writer.write(cag.getKundenMap().get(key).getName());
	    			writer.write(";");
	    			writer.write(cag.getKundenMap().get(key).getKundentyp());
	    			writer.write(";");
	    			if (cag.getRechnung() != null || !cag.getRechnung().isEmpty()) {
	    				for(int j=0; j<cag.getRechnung().size();j++) {
	    					if(cag.getRechnung().get(j).getRechnungskunde()!=null && cag.getRechnung().get(j).getRechnungskunde().getKundenId().equalsIgnoreCase(key)) {
	    						writer.write(String.valueOf(cag.getRechnung().get(j).getRechnungsBetrag()));
	    					}
	    				}
	    			}
	    			writer.write(System.lineSeparator());
	    		}
	            writer.close();
	            System.out.println(cag.getKundenMap().size() + " Datensaetze in die Datei "+ path+ " exportiert");
	        } catch (IOException e) {
	             e.printStackTrace();
	        }
		
	}

	/**
	 * QuitApp 
	 */
	private static void quitApp() {
		scan.close();
		System.exit(0);
	}
	
		
	/**
	 * Auswahlmenu 
	 */
	private static void auswahlMenu() {
		String menuList[] = { "(01)\tPrivatkunde anlegen", "(02)\tGesch�ftskunde anlegen",
				"(03)\tAuto anlegen", "(04)\tKunde mietet ein Auto", "(05)\tKunde mit evtl. gemietetem Auto anzeigen (Auswahl durch Kundennummer)", 
				"(06)\talle unvermieteten Autos anzeigen", "(07)\tAuto evtl. mit aktuellem Mieter anzeigen (Auswahl durch Kennzeichen)", 
				"(08)\tAuto abgeben und passende Rechnung erstellen", "(09)\tRechnung anzeigen (Auswahl durch Rechnungsnummer)", 
				"(10)\tAlle Rechnungen anzeigen sortiert nach Rechnungsbetrag", "(11)\tVermietungsdaten speichern", "(12)\tVermietungsdaten laden", "(13)\tKunden nach Namen sortiert als CSV-Datei exportieren", "(14)\tBeenden" };

		for (int i = 0; i < menuList.length; i++) {
			System.out.println(menuList[i]);
		}
	}
}
