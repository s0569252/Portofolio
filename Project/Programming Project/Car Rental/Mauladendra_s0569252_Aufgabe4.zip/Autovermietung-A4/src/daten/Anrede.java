package daten;

public enum Anrede {
	herr, frau, andere;
}
