package daten;

import java.io.Serializable;

public class Adresse implements Serializable{
	
	/**
	 * Variablen
	 */
	
	private String az1;
	private String az2;
	private String plz;
	private String ort;
	
	/**
	 * Konstruktor
	 * @param az1
	 * @param az2
	 * @param plz
	 * @param ort
	 */
	public Adresse(String az1, String az2, String plz, String ort) {
		super();
		this.az1 = az1;
		this.az2 = az2;
		this.plz = plz;
		this.ort = ort;
	}

	/**
	 * getAdresszeile1
	 * @return az1
	 */
	public String getAz1() {
		return az1;
	}

	/**
	 * setAdresszeile1
	 * @param az1
	 */
	public void setAz1(String az1) {
		this.az1 = az1;
	}

	/**
	 * getAdresszeile2
	 * @return az2
	 */
	public String getAz2() {
		return az2;
	}

	/**
	 * setAdresszeile2
	 * @param az2
	 */
	public void setAz2(String az2) {
		this.az2 = az2;
	}

	/**
	 * getPlz
	 * @return plz
	 */
	public String getPlz() {
		return plz;
	}

	/**
	 * setPlz
	 * @param plz
	 */
	public void setPlz(String plz) {
		this.plz = plz;
	}

	/**
	 * getOrt
	 * @return ort
	 */
	public String getOrt() {
		return ort;
	}

	/**
	 * setOrt
	 * @param ort
	 */
	public void setOrt(String ort) {
		this.ort = ort;
	}

	@Override
	public String toString() {
		return "\nAdresse: " + az1 + ", " + az2 + ", " + plz + ", " + ort;
	}
}
