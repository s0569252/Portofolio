package generator;

import java.util.Random;

public class RechnungsNummerGenerator {
Random rand = new Random();
	
	private String buchstabe = "";
	private String buchstabeZwei = "";
	private int zahl;
	private String zufallsZahl = "";
	private String rechnungsNummer;
	
	
	/**
	 * generiert erste 2 Buchstabe
	 * @return Buchstabe f�r 1.stelle
	 */

	public String zufallsBuchstabeEins() {
		for(int i=0;i<2;i++) {
			zahl = rand.nextInt(25)+65;
			buchstabe += String.valueOf(Character.toChars(zahl));	
		}
		return buchstabe;	
	}	

	/**
	 * generiert die 6-stellige Zufallszahlen
	 * @return zuffals Zahlen f�r 2.stelle
	 * 
	 */
	
	public String zufallsZahl() {
		for(int i=0;i<6;i++) {
			zahl = rand.nextInt(10);
			zufallsZahl += zahl;
		}
	return zufallsZahl;
	}
	
	/**
	 * generiert zweite 2 Buchstabe
	 * @return Buchstabe f�r 3.stelle
	 */
	
	public String zufallsBuchstabeZwei() {
		for(int i=0;i<2;i++) {
			zahl = rand.nextInt(25)+65;
			buchstabeZwei += String.valueOf(Character.toChars(zahl));	
		}
		return buchstabeZwei;	
	}	
	
	/**
	 * get Rechnungsnummer
	 * @return generierte Rechnungsnummer
	 */
	
	public String getRechnungsNummer() {
		rechnungsNummer = zufallsBuchstabeEins() + zufallsZahl() + zufallsBuchstabeZwei();
		return rechnungsNummer;
	}
}
