package generator;

import java.util.Random;

public class KundenIdGenerator {
	Random rand = new Random();
	
	private String buchstabe = "";
	private String buchstabeZwei = "";
	private int zahl;
	private String zufallsZahl = "";
	private String kundenId;
	
	
	/**
	 * generiert erste 2 Buchstabe
	 * @return Buchstabe f�r 1.stelle
	 */

	public String zufallsBuchstabeEins() {
		for(int i=0;i<2;i++) {
			zahl = rand.nextInt(25)+65;
			buchstabe += String.valueOf(Character.toChars(zahl));	
		}
		return buchstabe;	
	}	

	/**
	 * generiert die 3-stellige Zufallszahlen
	 * @return zuffals Zahlen f�r 2.stelle
	 * 
	 */
	
	public String zufallsZahl() {
		for(int i=0;i<3;i++) {
			zahl = rand.nextInt(10);
			zufallsZahl += zahl;
		}
	return zufallsZahl;
	}
	
	/**
	 * generiert zweite 2 Buchstabe
	 * @return Buchstabe f�r 3.stelle
	 */
	
	public String zufallsBuchstabeZwei() {
		for(int i=0;i<2;i++) {
			zahl = rand.nextInt(25)+65;
			buchstabeZwei += String.valueOf(Character.toChars(zahl));	
		}
		return buchstabeZwei;	
	}	
	
	/**
	 * get KundenId
	 * @return generierte KundenId
	 */
	
	public String getKundenId() {
		kundenId = zufallsBuchstabeEins() + "-" + zufallsZahl() + "-" + zufallsBuchstabeZwei();
		return kundenId;
	}
}
