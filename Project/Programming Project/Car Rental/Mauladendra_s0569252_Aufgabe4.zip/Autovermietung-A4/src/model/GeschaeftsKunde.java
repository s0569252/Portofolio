package model;

import daten.Adresse;

public class GeschaeftsKunde extends Kunde{
	/**
	 * Variable
	 */
	String name;

	/**
	 * Konstruktor mit KundenId
	 * @param kundenId
	 * @param name
	 * @param adresse
	 * @param telefonNummer
	 * @param eAdresse
	 */
	public GeschaeftsKunde(String kundenId, String name, Adresse adresse, String telefonNummer, String eAdresse) {
		super(kundenId, adresse, telefonNummer, eAdresse);
		this.name = name;
		kundentyp="Geschaeftskunde";
	}
	
	/**
	 * getName
	 */
	public String getName() {
		return name;
	}

	/**
	 * setName
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Firmenkunde: " +"Firmenname= " + name + super.toString();
	}
	
	
}
