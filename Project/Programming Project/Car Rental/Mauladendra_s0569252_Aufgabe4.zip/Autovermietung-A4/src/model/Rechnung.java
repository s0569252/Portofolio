package model;

import java.io.Serializable;

import generator.RechnungsNummerGenerator;


public class Rechnung implements Serializable{
	
	/**
	 * Variablen
	 */
	private String rechnungsNummer;
	private String verweis;
	private double kmAnzahl;
	private double rechnungsBetrag;
	private String information;
	private boolean isOffen;
	private Kunde kunde;
	
	/**
	 * Konstruktor
	 * @param kunde
	 * @param neuKmstand
	 */
	public Rechnung(Kunde kunde, double neuKmstand) {
		super();
		this.rechnungsNummer = new RechnungsNummerGenerator().getRechnungsNummer();
		this.kunde=kunde;
		this.verweis = "Kunde "+this.kunde.getKundenId()+" hat das Auto ("+this.kunde.getAuto().getKennzeichen()+") mit dem neuen Km Stand: "+neuKmstand+" Km abgegeben";
		this.kmAnzahl = neuKmstand;
		this.rechnungsBetrag = this.kmAnzahl*this.kunde.getAuto().getPreis()+19*this.kmAnzahl*kunde.getAuto().getPreis()/100;
		this.isOffen = true;
	}
	
	/**
	 * eberladen des Konstruktor nur mit Rechnungsbetrag
	 * @param kunde
	 * @param neuKmstand
	 */
	public Rechnung(double rechnungsBetrag) {
		super();
		this.rechnungsNummer = new RechnungsNummerGenerator().getRechnungsNummer();
		this.rechnungsBetrag = rechnungsBetrag;
	}
	
	/**
	 * get Rechnungsnummer
	 * @return Rechnungsnummer
	 */
	public String getRechnungsNummer() {
		return rechnungsNummer;
	}

	/**
	 * set Rechnungsnummer
	 * @param rechnungsNummer
	 */
	public void setRechnungsNummer(String rechnungsNummer) {
		this.rechnungsNummer = rechnungsNummer;
	}

	/**
	 * get Verweis des Kunden
	 * @return verweis
	 */
	public String getVerweis() {
		return verweis;
	}

	/**
	 * set Verweis
	 * @param verweis
	 */
	public void setVerweis(String verweis) {
		this.verweis = verweis;
	}

	/**
	 * get gefahrene km Anzahl
	 * @return km Anzahl
	 */
	public double getKmAnzahl() {
		return kmAnzahl;
	}

	/**
	 * set gefahrene km Anzahl
	 * @param kmAnzahl
	 */
	public void setKmAnzahl(double kmAnzahl) {
		this.kmAnzahl = kmAnzahl;
	}

	/**
	 * get Rechnungsbetrag
	 * @return Rechnungsbetrag
	 */
	public double getRechnungsBetrag() {
		return rechnungsBetrag;
	}

	/**
	 * set Rechnungsbetrag
	 * @param rechnungsBetrag
	 */
	public void setRechnungsBetrag(double rechnungsBetrag) {
		this.rechnungsBetrag = rechnungsBetrag;
	}

	/**
	 * get Information
	 * @return Information
	 */
	public String getInformation() {
		return information;
	}

	/**
	 * set Information
	 * @param information
	 */
	public void setInformation(String information) {
		this.information = information;
	}
	
	/**
	 * Rechnungsstatus anzeigen
	 * @return status
	 */
	public String rechnungStatus() {
		if(isOffen) {
			return "OFFEN";
		}
		else return "BEZAHLT";
	}
	
	/**
	 * get Rechnungskunde
	 * @return Kunde
	 */
	public Kunde getRechnungskunde() {
		return kunde;
	}
	
	@Override
	public String toString() {
		return "\nRECHNUNG: "+this.rechnungsNummer+"\nVerweis:\n"+this.verweis+"\nzuzahlender Betrag: "+this.rechnungsBetrag+"\nStatus: "+rechnungStatus()+"\n";
	}
}
