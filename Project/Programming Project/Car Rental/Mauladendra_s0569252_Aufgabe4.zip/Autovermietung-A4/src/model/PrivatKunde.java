package model;

import daten.Adresse;
import daten.Anrede;

public class PrivatKunde extends Kunde{
	
	/**
	 * Variable
	 */
	private String vorName, nachName;
	private Anrede anrede;
	private String gDatum;
	
	/**
	 * Konstruktor mit KundenId
	 * @param kundenId
	 * @param anrede
	 * @param vorName
	 * @param name
	 * @param gDatum
	 * @param adresse
	 * @param telefonNummer
	 * @param eAdresse
	 */
	public PrivatKunde(String kundenId, String anrede, String vorName, String nachName, String gDatum, Adresse adresse, String telefonNummer, String eAdresse) {
		super(kundenId, adresse, telefonNummer, eAdresse);
		
		if(anrede.equalsIgnoreCase("herr")) {
			this.anrede = Anrede.herr;
		}
		if(anrede.equalsIgnoreCase("frau")) {
			this.anrede = Anrede.frau;
		}
		if(anrede.equalsIgnoreCase("andere")) {
			this.anrede = Anrede.andere;
		}
		this.vorName = vorName;
		this.nachName = nachName;
		this.gDatum = gDatum;
		kundentyp="Privatekunde";
	}
	
	/**
	 * getVorname
	 * @return Vorname
	 */
	public String getVorName() {
		return vorName;
	}

	/**
	 * setVorname
	 * @param vorName
	 */
	public void setVorName(String vorName) {
		this.vorName = vorName;
	}

	
	public String getNachName() {
		return nachName;
	}

	public void setNachName(String nachName) {
		this.nachName = nachName;
	}

	@Override
	public String getName() {
		return this.vorName + " " + this.nachName;
	}

	/**
	 * getAnrede
	 * @return Anrede
	 */
	public Anrede getAnrede() {
		return anrede;
	}

	/**
	 * setAnrede
	 * @param anrede
	 */
	public void setAnrede(Anrede anrede) {
		this.anrede = anrede;
	}

	/**
	 * getDatum
	 * @return Datum
	 */
	public String getgDatum() {
		return gDatum;
	}

	/**
	 * setDatum
	 * @param gDatum
	 */
	public void setgDatum(String gDatum) {
		this.gDatum = gDatum;
	}

	@Override
	public String toString() {
		return "Privatkunde: "+ anrede +" " + getName() + ", " + gDatum + super.toString() ;
	}
	
	
	
	
}
