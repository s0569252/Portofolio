package model;

import java.util.Comparator;

public class RechnungsBetragComparator implements Comparator<Rechnung> {
	public int compare(Rechnung r1, Rechnung r2) {
		int temp;
		temp = Double.compare(r1.getRechnungsBetrag(),r2.getRechnungsBetrag());
		return temp;
	}
}
