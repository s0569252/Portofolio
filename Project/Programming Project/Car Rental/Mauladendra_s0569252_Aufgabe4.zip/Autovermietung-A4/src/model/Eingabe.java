package model;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

public class Eingabe {

	private BufferedReader eingabe = new BufferedReader(new InputStreamReader(System.in));
	
	/**
	 * lies eingabe der User
	 * @return text eingeben
	 * @throws Exception 
	 */
	
	public String textEingabe() throws Exception {
		return eingabe.readLine();
	}
	 
	/**
	 * lies Eingabe im Form String
	 * @param text (gewunschte information)
	 * @return eingabe (string)
	 */
	
	public String stringEingabe(String text) {
		String inputString = "";
		boolean weiter = true;
		
		do {
			try {
			System.out.println("Bitte geben Sie "+text + " ein :");
			inputString = textEingabe();
			weiter = false;
			} catch (Exception e) {
				} if (weiter) {
					System.out.println("Fehler Meldung. Bitte machen Sie neue Eingabe");
				} 
		}	while(weiter);
		
		return inputString;
	}
	 
	/**
	 * lies Eingabe (im Form Nummer)
	 * @param text (gewunschte information)
	 * @param min (min eingegebene Zahl)
	 * @param max (max eingebebene Zahl)
	 * @return Zahl
	 */
	
	public int nummerEingabe(String text, int min, int max) {
		int inputNummer = 0;
		boolean weiter= true;
		
		do {
			try {
			System.out.println("Bitte geben Sie " + text + " ein :");
			inputNummer = Integer.parseInt(textEingabe());
			if (inputNummer>=min && inputNummer<=max) {
				weiter = false;
			}
		} catch (Exception e) {
		} if (weiter) {
			System.out.println("Fehler Meldung. Bitte machen Sie neue Eingabe");
			} 
		}	while(weiter);
		
		return inputNummer;
	}
	
	/**
	 * lies Eingabe (im Form DD.MM.YYY)
	 * @param text (gewunschte Datum)
	 * @return Datum
	 */
	
	public String datumEingabe(String text) {
		String inputDatum = "";
		boolean weiter=true;
		
		do {
			try {
			System.out.println("Bitte geben Sie "+text + " im Form DD.MM.YYYY ein : ");
			inputDatum = textEingabe();
			if (Pattern.matches("\\d{2}.\\d{2}.\\d{4}", inputDatum)) {
				weiter = false;
			}
		} catch (Exception e) {
		} if (weiter) {
			System.out.println("Fehler Meldung. Bitte machen Sie eine neue Eingabe");
			} 
		}	while(weiter);
		return inputDatum;
	}
	
	/**
	 * lies Telefonnummer 
	 * @param text (gewunschte Telefonnumer)
	 * @return Telefonnummer
	 */
	public String stringTelefon(String text) {
		String inputTelefon = "";
		boolean weiter = true;
		
		do {
			try {
			System.out.println("Bitte geben Sie "+text + " ein :");
			inputTelefon = textEingabe();
			weiter = false;
			} catch (Exception e) {
				} if (weiter) {
					System.out.println("Fehler Meldung. Bitte machen Sie neue Eingabe");
				} 
		}	while(weiter);
		
		return inputTelefon;
	}
	
	/**
	 * lies Postleitzahl {im Form '12345') 
	 * @return plz
	 */
	
	public String plzEingabe() {
		String inputPLZ = "";
		boolean weiter = true;
		
		do {
			try {
			System.out.println("Bitte geben Sie Postleitzahl ein im Form '12345' :");
			inputPLZ = textEingabe();
			if(Pattern.matches("\\d{5}", inputPLZ)) {
				weiter = false;
			}
		} catch (Exception e) {
		} if (weiter) {
			System.out.println("Fehler Meldung. Bitte machen Sie eine neue Eingabe");
			} 
		}	while(weiter);
		return inputPLZ;
	}
	
	/**
	 * lies auswahl f�r Kundenname
	 * @return Name
 	 */
	
	public String nameEingabe () {
		String inputName = "";
		boolean weiter = true;
		
		do {
			try {
			System.out.println("Bitte geben Sie die Kundenname ein: ");
			inputName = textEingabe();
			//pruef ob die Eingabe mit der erlaubte Form passt)
			if (Pattern.matches("\\d{1,5}", inputName)) {
				weiter = false;
			} if(Pattern.matches("\\D{1,100}", inputName)) {//Falls statt Kundennummer, den Menupunkt eingegeben wurde
				weiter = false;
			}
		} catch (Exception e) {
		} if (weiter) {
			System.out.print("Fehler Meldung. Bitte machen Sie eine neue Eingabe");
			} 
		}	while(weiter);
		return inputName;
	}
	
	/**
	 * lies Eingabe im Form double
	 * @param text
	 * @return zahl (double)
	 */
	public double doubleEingabe(String text) {
		double inputDouble = 0;
		boolean weiter= true;
		
		do {
			try {
			System.out.println("Bitte geben Sie " + text + " ein :");
			inputDouble = Double.parseDouble(textEingabe());
			weiter = false;
		} catch (Exception e) {
		} if (weiter) {
			System.out.print("Fehler Meldung. Bitte machen Sie neue Eingabe");
			} 
		}	while(weiter);
		
		return inputDouble;
	}
	
}
