package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import daten.Adresse;

public class Autovermietung implements Serializable{
	
	/**
	 * Variablen
	 */
	private String name;
	private Adresse ad;
	private Map<String,Kunde> kundenMap= new HashMap <String,Kunde>();
	private Map<String,Auto> autoMap= new HashMap <String,Auto>();
	private List<Rechnung> rechnung= new ArrayList<Rechnung>();

	/**
	 * Konstruktor
	 * 
	 * @param name
	 * @param ad
	 */
	public Autovermietung(String name, Adresse ad) {
		super();
		this.name = name;
		this.ad = ad;
		this.kundenMap = new HashMap<String,Kunde>();
		this.autoMap = new HashMap<String,Auto>();
	}
	
	/**
	 * Kunden werden addiert
	 * @param kunde
	 * @return false
	 */
	public void addKunde(String kundenId, Kunde neuKunde) {
		kundenMap.put(kundenId, neuKunde);
	}
	
	/**
	 * Auto werden addiert
	 * @param auto
	 * @return false
	 */
	public void addAuto(String kennzeichen, Auto neuAuto) {
		autoMap.put(kennzeichen, neuAuto);
	}
	
	/**
	 * neue rechnung werden addiert
	 * @param neuRechnung
	 */
	public void addRechnung(Rechnung neuRechnung) {
		this.rechnung.add(neuRechnung);
	}
	
	/**
	 * get Name des Unternehmens
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * set Name des Unternehmens
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * get Adresse des Unternehmens
	 * @return ad
	 */
	public Adresse getAd() {
		return ad;
	}

	/**
	 * set Adresse des Unternehmens
	 * @param ad
	 */
	public void setAd(Adresse ad) {
		this.ad = ad;
	}
	
	/**
	 * getKunde
	 * @return kunde
	 */
	public Kunde getKunde(String kId) {
		if(kundenMap.get(kId)!= null) {
			return kundenMap.get(kId);
		}
		else {
			System.out.println("Auto mit diesem Kennzeichen: "+kId+" ist nicht gefunden");
			return null;
		}
	}
	
	/**
	 * getKundenMap
	 * @return kunde
	 */
	public Map<String, Kunde> getKundenMap() {
		return kundenMap;
	}

	/**
	 * setKundenMap
	 * @param kunde
	 */
	public void setKundenMap(Map<String, Kunde> kundenMap) {
		this.kundenMap = kundenMap;
	}
	
	/**
	 * getRechnung
	 * @return Rechnung
	 */
	public List<Rechnung> getRechnung() {
		return rechnung;
	}

	/**
	 * setRechnungs
	 * @param rechnungsMap
	 */
	public void setRechnung(List<Rechnung> rechnung) {
		this.rechnung = rechnung;
	}

	/**
	 * getAuto
	 * @param kennzeichen
	 * @return
	 */
	public Auto getAuto(String kennzeichen) {
		if(autoMap.get(kennzeichen)!= null) {
			return autoMap.get(kennzeichen);
		}
		else {
			System.out.println("Auto mit diesem Kennzeichen: "+kennzeichen+" ist nicht gefunden");
			return null;
		}
	}
	
	/**
	 * getAutoMap
	 * @return autoMap
	 */
	public Map<String, Auto> getAutoMap() {
		return autoMap;
	}

	/**
	 * setAutoMap
	 * @param auto
	 */
	public void setAutoMap(Map<String, Auto> autoMap) {
		this.autoMap = autoMap;
	}

	@Override
	public String toString() {
		return "Autovermietung [" + name + "]" + ad;
	}
}
