package model;

import java.io.Serializable;

public class Auto implements Serializable{
    
	/**
	 * Variablen
	 */
	String kennzeichen;
	double kmStand;
	double preis;
	
	/**
	 * Konstrukor
	 * @param kennzeichen
	 * @param kmStand
	 * @param preis
	 */
	public Auto(String kennzeichen, double kmStand, double preis) {
		super();
		this.kennzeichen = kennzeichen;
		this.kmStand = kmStand;
		this.preis = preis;
	}
	
	/**
	 * get Kenzeichen des Autos
	 * @return kennzeichen
	 */
	public String getKennzeichen() {
		return kennzeichen;
	}

	/**
	 * set Kenzeichen des Autos
	 * @param kennzeichen
	 */
	public void setKennzeichen(String kennzeichen) {
		this.kennzeichen = kennzeichen;
	}

	/**
	 * get KmStand des Autos
	 * @return kmStand
	 */
	public double getKmStand() {
		return kmStand;
	}

	/**
	 * set KmStand des Autos
	 * @param kmStand
	 */
	public void setKmStand(double kmStand) {
		this.kmStand = kmStand;
	}

	/**
	 * get Preis pro km des Autos
	 * @return
	 */
	public double getPreis() {
		return preis;
	}

	/**
	 * set Preis pro km des Autos
	 * @param preis
	 */
	public void setPreis(double preis) {
		this.preis = preis;
	}

	@Override
	public String toString() {
		return "Auto [kennzeichen= " + kennzeichen + ", kmStand= " + kmStand + ", Preis= " + preis + " Euro" +"]";
	}

}
