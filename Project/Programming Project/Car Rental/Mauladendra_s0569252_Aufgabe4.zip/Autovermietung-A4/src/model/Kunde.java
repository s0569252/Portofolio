package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import daten.Adresse;

public abstract class Kunde implements Serializable{

	/**
	 * Variablen
	 */
	private String kundenId;
	private Adresse adresse;
	private String telefonNummer;
	private String eAdresse;
	private Auto auto;
	private List<Rechnung> rechnung;
	protected String kundentyp;

	/**
	 * Konstruktor
	 * @param kundenId
	 * @param anrede
	 * @param vorName
	 * @param nachName
	 * @param gDatum
	 * @param adresse
	 * @param telefonNummer
	 * @param eAdresse
	 */
	public Kunde(String kundenId, Adresse adresse, String telefonNummer, String eAdresse) {
		super();
		this.kundenId = kundenId;
		this.adresse = adresse;
		this.telefonNummer = telefonNummer;
		this.eAdresse = eAdresse;
		this.rechnung=new ArrayList<Rechnung>();
	}
	
	/**
	 * Autos werden addiert
	 * @param auto
	 * @return false
	 */
	public void addAuto(Auto neuAuto) {
		this.auto=neuAuto;
	}
	
	/**
	 * Autos werden addiert
	 * @param auto
	 * @return false
	 */
	public void addRechnung(Rechnung neuRechnung) {
		this.rechnung.add(neuRechnung);
	}
	
	/**
	 * get Auto
	 * @return Auto
	 */
	public Auto getAuto() {
		return this.auto;
	}

	/**
	 * set Auto
	 * @param auto
	 */
	public void setAuto(Auto auto) {
		this.auto = auto;
	}
	
	/**
	 * get Rechnung
	 * @return Rechnung
	 */
	public List<Rechnung> getRechnung() {
		return rechnung;
	}

	/**
	 * set Rechnung
	 * @param rechnung
	 */
	public void setRechnung(List<Rechnung> rechnung) {
		this.rechnung = rechnung;
	}

	/**
	 * get Kundennummer
	 * @return kundenId
	 */
	public String getKundenId() {
		return kundenId;
	}

	/**
	 * set kundennummer
	 * @param kundenId
	 */
	public void setKundenId(String kundenId) {
		this.kundenId = kundenId;
	}

	
	/**
	 * get Adresse
	 * @return
	 */
	public Adresse getAdresse() {
		return adresse;
	}

	/**
	 * set Adresse
	 * @param adresse
	 */
	public void setAdresse(Adresse adresse) {
		this.adresse = adresse;
	}

	abstract public String getName();

	/**
	 * get Telefonnummer des Kundes
	 * @return telefonNummer
	 */
	public String getTelefonNummer() {
		return telefonNummer;
	}

	/**
	 * set Telefonnummer des Kundes
	 * @param telefonNummer
	 */
	public void setTelefonNummer(String telefonNummer) {
		this.telefonNummer = telefonNummer;
	}

	/**
	 * get Emailadresse des Kundes
	 * @return eAdresse
	 */
	public String geteAdresse() {
		return eAdresse;
	}

	/**
	 * set Emailadresse des Kundes
	 * @param eAdresse
	 */
	public void seteAdresse(String eAdresse) {
		this.eAdresse = eAdresse;
	}
	
	/**
	 * get Typ des Kundes
	 * @param eAdresse
	 */
	public String getKundentyp() {
		return kundentyp;
	}

	@Override
	public String toString() {
		return ", kundenId= " + kundenId + ", Telefonnummer= " + telefonNummer
				+ ", E-Mail= " + eAdresse + adresse ;
	}


}
