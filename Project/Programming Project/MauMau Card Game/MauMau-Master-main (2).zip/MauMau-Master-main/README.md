# MauMau-Master

## Aufgaben ##
- die Logik für alle Komponenten implementieren (95% ferig)
- Configuration Komponente für die Dependency-Injection (DI) benutzen (PicoContainer)
- Logging Framework umsetzen (Log4J)
- UI bauen (Consolen-Oberfläche)
- Mock-Tests für importierende Interfaces von GameManagement und PlayerManagement erstellen (als letztes erledigen!)


  
# Abgabe bis 20.06 23:59
