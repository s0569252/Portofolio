package de.htwberlin.kompbentw.maumau.Configuration;

import org.picocontainer.Characteristics;
import org.picocontainer.DefaultPicoContainer;
import org.picocontainer.MutablePicoContainer;
import org.picocontainer.injectors.ConstructorInjection;

import de.htwberlin.kompbentw.maumau.CardManagement.impl.CardServiceImpl;
import de.htwberlin.kompbentw.maumau.GameManagement.export.ApplicationException;
import de.htwberlin.kompbentw.maumau.GameManagement.impl.GameServiceImpl;
import de.htwberlin.kompbentw.maumau.GameManagement.impl.RuleServiceImpl;
import de.htwberlin.kompbentw.maumau.PlayerManagement.impl.PlayerServiceImpl;
import de.htwberlin.kompbentw.maumau.PlayerManagement.impl.VirtualPlayerServiceImpl;
import de.htwberlin.kompbentw.maumau.UserInterface.impl.GameControllerImpl;
import de.htwberlin.kompbentw.maumau.UserInterface.impl.GameViewer;

/**
 * Hello world!
 *
 */
public class ConfigurationImpl {
	
	//private CardService cardService;
	//private PlayerService playerService;
	//private GameService gameService;
	//private CColors cC;
	//private CValues cV;
	private static MutablePicoContainer pico = new DefaultPicoContainer(new ConstructorInjection());
    
	public static void main( String[] args ) throws ApplicationException {
		try {
			registerComponents();
        } catch (Exception e) {
            throw new ApplicationException("Component registration error");
        }

        try {
        	pico.getComponent(GameControllerImpl.class).run();
        } catch (java.lang.NullPointerException e) {
        	throw new ApplicationException("Failure to open component");
        } catch (Exception e){
            throw new ApplicationException();
        }
		
    }

	private static void registerComponents() {
		//CardServiceImpl cardService = new CardServiceImpl();
		//PlayerServiceImpl playerService = new PlayerServiceImpl();
		//GameServiceImpl gameService = new GameServiceImpl();
		pico.addComponent(CardServiceImpl.class);
		pico.addComponent(PlayerServiceImpl.class);
		pico.addComponent(RuleServiceImpl.class);
		pico.addComponent(GameServiceImpl.class);
		pico.addComponent(GameControllerImpl.class);
		pico.addComponent(GameViewer.class);
		pico.addComponent(VirtualPlayerServiceImpl.class);
		//pico.as(Characteristics.USE_NAMES).addComponent(GameServiceImpl.class);
	}

}
