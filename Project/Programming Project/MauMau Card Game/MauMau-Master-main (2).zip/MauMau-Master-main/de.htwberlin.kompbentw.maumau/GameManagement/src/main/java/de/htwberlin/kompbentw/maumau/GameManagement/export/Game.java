package de.htwberlin.kompbentw.maumau.GameManagement.export;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import de.htwberlin.kompbentw.maumau.CardManagement.export.CColors;
import de.htwberlin.kompbentw.maumau.CardManagement.export.Card;
import de.htwberlin.kompbentw.maumau.PlayerManagement.export.Player;

@Entity
public class Game {
	
	private Long gameSessionID;
	private Player activePlayer;
	private List<Player>  allPlayers = new ArrayList<>();
	private int cardsToPick;
	private List<Card> deckToPickFrom = new ArrayList<>();
	private List<Card> deckToPlaceOn = new ArrayList<>();
	private boolean rightGameDirection = true;
	private boolean successfullyLaid;
	private boolean suspend = false;
	private CColors color;
	private boolean skipRound = false;
	private boolean chooseColor = false;
	private int gameRoundIndex;
	private boolean extendedRules;
	private String winner;
	
	@Id
    @GeneratedValue
	public Long getGameSessionID() {
		return gameSessionID;
	}
	public void setGameSessionID(Long gameSessionID) {
		this.gameSessionID = gameSessionID;
	}
	public Player getActivePlayer() {
		return activePlayer;
	}
	public void setActivePlayer(Player activePlayer) {
		this.activePlayer = activePlayer;
	}
	public List<Player> getAllPlayers() {
		return allPlayers;
	}
	public void setAllPlayers(List<Player> allPlayers) {
		this.allPlayers = allPlayers;
	}
	public int getCardsToPick() {
		return cardsToPick;
	}
	public void setCardsToPick(int cardsToPick) {
		this.cardsToPick = cardsToPick;
	}
	public List<Card> getDeckToPickFrom() {
		return deckToPickFrom;
	}
	public void setDeckToPickFrom(List<Card> deckToPickFrom) {
		this.deckToPickFrom = deckToPickFrom;
	}
	public List<Card> getDeckToPlaceOn() {
		return deckToPlaceOn;
	}
	public void setDeckToPlaceOn(List<Card> deckToPlaceOn) {
		this.deckToPlaceOn = deckToPlaceOn;
	}
	public boolean isRightGameDirection() {
		return rightGameDirection;
	}
	public void setRightGameDirection(boolean rightGameDirection) {
		this.rightGameDirection = rightGameDirection;
	}
	public boolean isSuccessfullyLaid() {
		return successfullyLaid;
	}
	public void setSuccessfullyLaid(boolean successfullyLaid) {
		this.successfullyLaid = successfullyLaid;
	}
	public boolean isSuspend() {
		return suspend;
	}
	public void setSuspend(boolean suspend) {
		this.suspend = suspend;
	}
	public CColors getColor() {
		return color;
	}
	public void setColor(CColors color) {
		this.color = color;
	}
	public boolean isSkipRound() {
		return skipRound;
	}
	public void setSkipRound(boolean skipRound) {
		this.skipRound = skipRound;
	}
	public boolean isChooseColor() {
		return chooseColor;
	}
	public void setChooseColor(boolean chooseColor) {
		this.chooseColor = chooseColor;
	}
	public int getGameRoundIndex() {
		return gameRoundIndex;
	}
	public void setGameRoundIndex(int gameRoundIndex) {
		this.gameRoundIndex = gameRoundIndex;
	}
	public boolean isExtendedRules() {
		return extendedRules;
	}
	public void setExtendedRules(boolean extendedRules) {
		this.extendedRules = extendedRules;
	}
	public String getWinner() {
		return winner;
	}
	public void setWinner(String winner) {
		this.winner = winner;
	}
	
}