package de.htwberlin.kompbentw.maumau.GameManagement.export;

import de.htwberlin.kompbentw.maumau.CardManagement.export.CColors;
import de.htwberlin.kompbentw.maumau.CardManagement.export.Card;

public interface RuleService {
	
	/**
	 *  Die Methode prueft, ob der naechste Spieler zwei Karten ziehen soll.
	 * @param placedCard - letzte gelegte Karte
	 * @param pickingCardsQty - Anzahl zu ziehende Karten fuer den naechsten Spieler
	 * @return int Wert - neue Anzahl 
	 */
	int pickMoreCards(Card lastPlacedCard, int pickingCardsQty);
	
	/**
	 *  Die Methode pruft, ob die zulegende Karte gelegt werden darf.
	 * @param currentActiveCard - die letzte auf dem Ablagestapel gelegte Karte
	 * @param placedCard - die zulegende Karte
	 * @param color - Farbe der Karte, die gelegt werden kann
	 * @return boolean Wert - ob die Karte gelegt werden kann
	 */
	boolean placedCardAllowed(Card currentActiveCard, Card placedCard, CColors color);
	
	/**
	 * Die Methode prueft, ob die Farbe gewaehlt werden kann, weil die letzte gelegte
	 * Karte ein Bube war.
	 * @param placedCard - letzte gelegte Karte
	 * @return boolean Wert - ob ein Spieler neue Farbe wuenschen kann
	 */
	boolean choosingColorAllowed(Card placedCard);
	
	/**
	 * Die Methode prueft, ob ein Richtungswechsel ausgeloest werden muss.
	 * @param placedCard - letzte gelegte Karte
	 * @return boolean Wert - ob die Richtung gewechselt werden muss
	 */
	boolean changingDirectionAllowed(Card placedCard);
	
	/**
	 * Die Methode prueft, ob der aktive Spieler diese Runde eine Karte ablegen darf.
	 * @param lastPlayedCard - letzte gelegte Karte
	 * @return boolean Wert - ob der aktive Spieler ein Karte legen darf
	 */
	boolean playingThisRoundAllowed(Card lastPlacedCard);
	
}
