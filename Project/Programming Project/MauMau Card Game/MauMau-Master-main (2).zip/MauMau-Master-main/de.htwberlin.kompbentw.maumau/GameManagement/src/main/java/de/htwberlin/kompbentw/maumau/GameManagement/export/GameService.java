/**
 * @author Imdi Melvana Mauladendra, Azmi Hasan, Tachmyrat Annayev
 */
package de.htwberlin.kompbentw.maumau.GameManagement.export;

import java.util.List;

import de.htwberlin.kompbentw.maumau.CardManagement.export.CColors;
import de.htwberlin.kompbentw.maumau.CardManagement.export.Card;
import de.htwberlin.kompbentw.maumau.CardManagement.export.CardStack;
import de.htwberlin.kompbentw.maumau.PlayerManagement.export.Player;

public interface GameService {
	
	/**
	 * Diese Methode legt ein Spiel an
	 * @param players -  Aller Spielern
	 * @param extendedRules
	 * @return gibt das neu angelegte Spiel zurueck
	 */
	Game createNewGame(List<String> players, boolean extendedRules);
	
	/**
	 * Die Methode entnimmt eine Karte aus dem Ziehstapel
	 * @param game - Das Spiel
	 * @param cardStack - Der Ziehstapel
	 * @return Spiel
	 */
	Game pickCards(Game game, List<Card> cardStack);
	
	/**
	 * Die Methode prueft, ob die Karte gelegt werden darf und fuegt diese danach hinzu.
	 * @param game - Das Spiel
	 * @param player - Der aktueller Spieler
	 * @param playCard - Die Karte, die gelegt werden soll
	 * @return Das Spiel
	 */
	Game playCard(Game game, Player player, Card playCard);
	
	/**
	 * Diese Methode zieht Karten vom Ablagestapel und sorgt dafuer, dass der Spieler sie als Handkarten bekommt
	 * @param drawstack  -  Liste an Karten, von denen gezogen werden soll (Ziehstapel)
	 * @param player  - Spieler, der die Karten ziehen soll
	 * @param count  -  Anzahl der Karten, die gezogen werden sollen
	 * @return Liste der restlichen Karten, stellt Ziehstapel des Spieles dar
	 */
	List<Card> pickFirstCards(CardStack drawstack, Player player, int count);
	
	/**
	 * Prueft am Ende eines Zuges, ob das Spiel zu Ende ist
	 * @param player  aktueller Spieler
	 * @return boolean, der angibt, ob das Spiel zu Ende ist
	 */
	boolean checkGameEnd(Player player);
	
	/**
	 * Prueft ob der Spieler Mau geklickt hat
     * und falls nicht, bekommt der Spieler auch die Strafkarten auf die Hand
	 * @param game  Das Spiel
	 * @return Das Spiel, nachdem ggfs. Strafkarten dem Spieler zugefuehrt wurden
	 */
	Game checkMau(Game game);
	
	/**
	 * Setzt Mau bei einem Spieler.
	 * @param player - Spieler
	 * @param newMauState - der Mauzustand danach
	 */
	void sayMau(Player player, boolean newMauState);
	
	/**
	 * Prüft, ob Karten gemischt werden muessen, und tut es ggf.
	 * @param game - Das Spiel
	 * @return Das Spiel
	 */
	Game mussCardsBeMixed(Game game);
	
	/**
	 * Die Methode sortiert die Karten, die auf dem Hand sind.
	 * @param game - Das Spiel
	 * @return Liste von Karten - die sortiert sind
	 */
	Game sortPlayerCards(Game game);
	
	/**
	 * Die Methode setzt den naechsten Spieler aktiv.
	 * @param game - Das Spiel
	 * @return Das Spiel
	 */
	Game setNextPlayer(Game game);
	
	/**
	 * Die Methode setzt die Kartenfarbe im Spiel um.
	 * @param game - das Spiel
	 * @param color - Die Farbe, die gesetzt werden soll
	 * @return Das Spiel
	 */
	Game pickCardColor(Game game, CColors color);
	
	
	

}
