package de.htwberlin.kompbentw.maumau.GameManagement.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.log4j.Logger;

import de.htwberlin.kompbentw.maumau.CardManagement.export.CColors;
import de.htwberlin.kompbentw.maumau.CardManagement.export.Card;
import de.htwberlin.kompbentw.maumau.CardManagement.export.CardService;
import de.htwberlin.kompbentw.maumau.CardManagement.export.CardStack;
import de.htwberlin.kompbentw.maumau.GameManagement.export.Game;
import de.htwberlin.kompbentw.maumau.GameManagement.export.GameService;
import de.htwberlin.kompbentw.maumau.GameManagement.export.RuleService;
import de.htwberlin.kompbentw.maumau.PlayerManagement.export.Player;
import de.htwberlin.kompbentw.maumau.PlayerManagement.export.PlayerService;

public class GameServiceImpl implements GameService {
	
	private PlayerService playerservice;
	private CardService cardservice;
	private RuleService simplerule;
	private RuleService extendedrule;
	private RuleService rules;
	private static Logger log = Logger.getRootLogger();
	
	public GameServiceImpl(PlayerService playerService, CardService cardService, RuleService simpleRule, RuleService extendedRule) {
		
		this.playerservice = playerService;
		this.cardservice = cardService;
		this.simplerule = simpleRule;
		this.extendedrule = extendedRule;
		
	}
	
	@Override
	public Game createNewGame(List<String> players, boolean extendedRules) {
		log.debug("createGame");
		Game game = new Game();
		rules = rulesAdd(extendedRules);
		
		List<Player> playersList = new ArrayList<>();
		CardStack discardpile = new CardStack();
		
		game.setExtendedRules(extendedRules);
		for(String value : players) {
			Player thePlayer = null;
			thePlayer = playerservice.createNewPlayer(value);
			playersList.add(thePlayer);
		}
		
		game.setAllPlayers(playersList);
		game.setActivePlayer(game.getAllPlayers().get(0));
		game.setDeckToPickFrom(cardservice.mixCardStack(cardservice.createDeck().getCards(), false));
		discardpile.getCards().add(game.getDeckToPickFrom().get(game.getDeckToPickFrom().size() - 1));
		game.setDeckToPickFrom(removeDrawnCardFromDrawPile(game.getDeckToPickFrom(), game.getDeckToPickFrom().get(game.getDeckToPickFrom().size() - 1)));
		game.setDeckToPlaceOn(discardpile.getCards());
		return game;
	}
	
	public RuleService rulesAdd(boolean extendedRule) {
		if(extendedRule) {
			rules = this.extendedrule;
		}else {
			rules = this.simplerule;
		}
		return rules;
	}


	@Override
	public Game pickCards(Game game, List<Card> cardStack) {
		log.debug("pickCards");
		Card card = game.getDeckToPickFrom().get(game.getDeckToPickFrom().size() - 1);
		playerservice.addCardToHandout(card,game.getActivePlayer());
		game.setDeckToPickFrom(removeDrawnCardFromDrawPile(game.getDeckToPickFrom(), card));		
		return game;
	}

	@Override
	public Game playCard(Game game, Player player, Card playCard) {
		game.setActivePlayer(player);
		player.getCards().equals(playCard);
		
		return game;
	}
	
	@Override
	public List<Card> pickFirstCards(CardStack drawpile, Player player, int count) {
		log.debug("pickFirstCards");
		List<Player> playerlist = new ArrayList<>();
		playerlist.add(player);
		handingOutCard(drawpile, playerlist, count);
		return drawpile.getCards();
	}
	
	/**
     * Verteilt karten auf Spielerhaende
     *
     * @param drawpile   - der Stapel von dem die Karten genommen werden sollen
     * @param player - Liste der Spieler die die Karten bekommen sollen
     * @param count  - Anzahl der neuen Karten pro Spieler
     * @return - der reduzierte ziehstapel
     */
	public List<Card> handingOutCard(CardStack drawpile, List<Player> player, int count) {
		log.debug("handingOutCards");
		for(int round = 0; round < count; round ++) {
			for(int playercounter = 0; playercounter < player.size(); playercounter++) {
				Card card = drawpile.getCards().get(drawpile.getCards().size() - 1);
				playerservice.addCardToHandout(card, player.get(playercounter));
				drawpile.removeCard(card);
			}
		}
		return drawpile.getCards();
	}
	
	
	
	@Override
	public boolean checkGameEnd(Player player) {
		log.debug("checkGameEnd");
		return !player.getCards().getCards().isEmpty();
	}

	@Override
	public Game checkMau(Game game) {
		log.debug("checkMau");
		List<Player> playerList = new ArrayList<>();
		playerList.add(game.getActivePlayer());
		if(isMauNecessary(game.getActivePlayer())) {
			game = mussCardsBeMixed(game);
			if(!game.getActivePlayer().isMau()) {
				CardStack cs = new CardStack();
				cs.setCards(game.getDeckToPickFrom());
				handingOutCard(cs,playerList ,2);
			}
		}
	
		return game;
	}
	
	/**
     * Schaut ob Mau von noeten ist
     *
     * @param spieler die Aktuellen Spieler
     * @return Ob ja oder nein
     */
    private boolean isMauNecessary(Player player) {
        log.debug("isMauNecessary");
        return player.getCards().getCards().size() == 1;
    }

	@Override
	public void sayMau(Player player, boolean newMauState) {
		log.debug("sayMau");
		player.setMau(newMauState);
	}

	@Override
	public Game mussCardsBeMixed(Game game) {
		log.debug("mussCardsBeMixed");
		List<Card> cardstack;// Deck to pick 
		List<Card> discardpile = new ArrayList<>(); // Discard deck
		
		cardstack = game.getDeckToPickFrom();
		
		if(cardstack.size() < 2) {
			Card OneDraw = cardstack.get(0);
			cardstack = game.getDeckToPlaceOn();
			discardpile.add(cardstack.get(cardstack.size() - 1));
			cardstack.remove(cardstack.size() - 1);
			cardstack.add(OneDraw);
			game.setDeckToPickFrom(cardservice.mixCardStack(cardstack, false));
			game.setDeckToPlaceOn(discardpile);
			
		}
		return game;
	}

	@Override
	public Game sortPlayerCards(Game game) {
		CardStack cards = new CardStack();
		cards.setCards(cardservice.mixCardStack(game.getActivePlayer().getCards().getCards(), false));
		game.getActivePlayer().setCards(cards);
		return game;
	}

	@Override
	public Game setNextPlayer(Game game) {
		log.debug("setNextPlayer");
		game.setSuccessfullyLaid(false);;
		int changing = 1;
		int nextplayer;
		int playerlist = game.getAllPlayers().size();
		if(game.isSkipRound()) {
			changing++;
		}
		if(game.isRightGameDirection()) {
			nextplayer = game.getAllPlayers().indexOf(game.getActivePlayer()) + changing;
		} else {
			nextplayer = game.getAllPlayers().indexOf(game.getActivePlayer()) - changing;
		}
		if( nextplayer >= playerlist) {
			game.setActivePlayer(game.getAllPlayers().get(nextplayer - playerlist));
		}else {
			if(playerlist < 0) {
				game.setActivePlayer(game.getAllPlayers().get(playerlist + nextplayer));
			} else {
				game.setActivePlayer(game.getAllPlayers().get(nextplayer));
			}
		}
		return game;
	}

	@Override
	public Game pickCardColor(Game game, CColors color) {
		log.debug("");
		game.setColor(color);
		game.setChooseColor(false);
		return game;
	}

	 /**
     * Diese Methode entfernt eine bestimmte Karte vom Kartenstapel
     *
     * @param karteStapel - Kartenstapel der geaendert werden soll
     * @param karte - zu entfernende Karte
     * @return - der neue Kartenstapel
     */
	private List<Card> removeDrawnCardFromDrawPile(List<Card> cardstack, Card card ) {
		log.debug("removeDrawnCardFromDrawPile");
		cardstack.remove(card);
		return cardstack;
	}


	

}
