package de.htwberlin.kompbentw.maumau.GameManagement;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import de.htwberlin.kompbentw.maumau.CardManagement.export.CColors;
import de.htwberlin.kompbentw.maumau.CardManagement.export.CValues;
import de.htwberlin.kompbentw.maumau.CardManagement.export.Card;
import de.htwberlin.kompbentw.maumau.CardManagement.export.CardService;
import de.htwberlin.kompbentw.maumau.CardManagement.export.CardStack;
import de.htwberlin.kompbentw.maumau.CardManagement.impl.CardServiceImpl;
import de.htwberlin.kompbentw.maumau.GameManagement.export.Game;
import de.htwberlin.kompbentw.maumau.GameManagement.export.GameService;
import de.htwberlin.kompbentw.maumau.GameManagement.export.RuleService;
import de.htwberlin.kompbentw.maumau.GameManagement.impl.GameServiceImpl;
import de.htwberlin.kompbentw.maumau.GameManagement.impl.RuleServiceImpl;
import de.htwberlin.kompbentw.maumau.PlayerManagement.export.Player;
import de.htwberlin.kompbentw.maumau.PlayerManagement.export.PlayerService;
import de.htwberlin.kompbentw.maumau.PlayerManagement.impl.PlayerServiceImpl;

import org.junit.Before;
import org.junit.Ignore;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class GameServiceTest {
	
	@InjectMocks
    private GameServiceImpl gameservice;
    @Mock
    private PlayerService playerservice;
    @Mock
    private RuleService ruleservice;
    @Mock
    private CardService cardservice;

	//private CardService cardservice = new CardServiceImpl();
	//private PlayerService playerservice = new PlayerServiceImpl();
	//private RuleService ruleservice = new RuleServiceImpl();
	
	
	//global arrange
	private CardStack carddeck = new CardStack();
	private Card hA = new Card(CColors.Heart, CValues.Ace);
	private Card h2 = new Card(CColors.Heart, CValues.Two);
	private Card h7 = new Card(CColors.Heart, CValues.Seven);
	private Card dA = new Card(CColors.Diamond, CValues.Ace);
	private Card d2 = new Card(CColors.Diamond, CValues.Two);
	private Card d7 = new Card(CColors.Diamond, CValues.Seven);
	private Card cA = new Card(CColors.Club, CValues.Ace);
	private Card c2 = new Card(CColors.Club, CValues.Two);
	private Card cJ = new Card(CColors.Club, CValues.Jack);
	private Card sA = new Card(CColors.Spade, CValues.Ace);
	private Card s2 = new Card(CColors.Spade, CValues.Two);
	private Card sJ = new Card(CColors.Spade, CValues.Jack);
	private Player samuel = new Player("Samuel");
	private Player john = new Player("John");
	private Game game = new Game();
	private List<Player> players = new ArrayList();
	
	@Before
	public void SetUp() {
	carddeck.getCards().add(hA);
	carddeck.getCards().add(h2);
	carddeck.getCards().add(h7);
	carddeck.getCards().add(dA);
	carddeck.getCards().add(d2);
	carddeck.getCards().add(d7);
	carddeck.getCards().add(cA);
	carddeck.getCards().add(c2);
	carddeck.getCards().add(cJ);
	carddeck.getCards().add(sA);
	carddeck.getCards().add(s2);
	carddeck.getCards().add(sJ);
	players.add(samuel);
	players.add(john);
	game.setDeckToPickFrom(carddeck.getCards());
	game.setAllPlayers(players);
	game.setActivePlayer(samuel);
	game.setRightGameDirection(true);
	game.setDeckToPlaceOn(carddeck.getCards());
	game.setColor(CColors.Heart);
	
	}
	
	/**
     * Testmethode für createNewGame
     */
	/*@Test
	public void testCreateNewGame() {
		CardStack cardDeck = new CardStack();
        for (CColors color : CColors.values()){
            for (CValues value : CValues.values()) {
            	Card card = cardservice.createNewCard(color, value);
                cardDeck.getCards().add(card);
                System.out.println(card.toString());
            }
        }


	}*/
	/**
     * Testmethode für pickCards
     */
	@Ignore
	public void testPickCards() {
		CardStack cardDeck = new CardStack();
        for (CColors color : CColors.values()){
            for (CValues value : CValues.values()) {
            	Card card = cardservice.createNewCard(color, value);
                cardDeck.getCards().add(card);
                System.out.println(card.toString());
            }
        }

		assertTrue(game.getActivePlayer().getCards().getCards().contains(cJ));
	}
	
	/**
     * Testmethode für pickCards
     */
	@Test
	public void testPlayCards() {
		

		
	}
	/**
     * Testmethode für pickCards
     */
	
	@Test
	public void testPickFirstCards() {
		assertEquals(10, gameservice.pickFirstCards(carddeck, samuel, 2).size());
	
	}
	
	@Test
	public void testCheckGameEnd() {
		gameservice.playCard(game, john, cA);
		assertFalse("player still not finished", gameservice.checkGameEnd(john));
	}
	
	@Test
	public void testCheckMau() {
		samuel.getCards().addCard(h2);;
		game.getActivePlayer().setMau(true);
		
		game = gameservice.checkMau(game);
		assertEquals(1, game.getActivePlayer().getCards().getCards().size());
	}
	
	@Test
	public void testSayMau() {
		gameservice.sayMau(john, true);;
		assertTrue("Mau hätte gesetzt sein müssen", john.isMau());
	    gameservice.sayMau(john, false);
	    assertFalse(john.isMau());
		
	}
	
	@Test
	public void testMussCardsBeMixed() {
		
		
	}
	
	@Test
	public void testSortPlayerCards() {
		
		
	}
	
	@Test
	public void testSetNextPlayer() {
		Player bon = new Player("bon");
		
		players.add(bon);
		game = gameservice.setNextPlayer(game);
		
		assertEquals(john, game.getActivePlayer());
		
	}
	
	
	
	@Test
	public void testPickCardColor() {
		game.setColor(CColors.Heart);
		assertEquals(CColors.Spade, gameservice.pickCardColor(game, CColors.Spade).getColor());
		game.setChooseColor(true);
		assertFalse(gameservice.pickCardColor(game, CColors.Spade).isChooseColor());

	}
}
