package de.htwberlin.kompbentw.maumau.GameManagement.impl;

import de.htwberlin.kompbentw.maumau.CardManagement.export.CColors;
import de.htwberlin.kompbentw.maumau.CardManagement.export.Card;
import de.htwberlin.kompbentw.maumau.GameManagement.export.RuleService;

public class RuleServiceImpl implements RuleService {

    @Override
	public int pickMoreCards(Card lastPlacedCard, int pickingCardsQty) {
		return 0;
	}

	@Override
	public boolean placedCardAllowed(Card currentActiveCard, Card placedCard, CColors color) {
		if(currentActiveCard.getValue().equals(placedCard.getValue())) {
			return true;
		} else {
			return currentActiveCard.getColor().equals(placedCard.getColor());
		}
	}
	
	@Override
	public boolean choosingColorAllowed(Card placedCard) {
		return false;
	}

	@Override
	public boolean changingDirectionAllowed(Card placedCard) {
		return false;
	}
	
	@Override
	public boolean playingThisRoundAllowed(Card lastPlacedCard) {
		return false;
	}
}
