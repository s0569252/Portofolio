package de.htwberlin.kompbentw.maumau.GameManagement.export;

public class ApplicationException extends Exception {

	private static final long serialVersionUID = -8352229222413665305L;
	

    public ApplicationException() {
        super("Sorry, something went wrong!");
    }

    public ApplicationException(String message) {
        super("Sorry, something went wrong! Error Message: " + message);
    }
}
