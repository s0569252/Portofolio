package de.htwberlin.kompbentw.maumau.GameManagement.impl;

import de.htwberlin.kompbentw.maumau.CardManagement.export.CColors;
import de.htwberlin.kompbentw.maumau.CardManagement.export.CValues;
import de.htwberlin.kompbentw.maumau.CardManagement.export.Card;
import de.htwberlin.kompbentw.maumau.GameManagement.export.RuleService;

public class RuleServiceExtendedImpl implements RuleService {

	@Override
	public int pickMoreCards(Card lastPlacedCard, int pickingCardsQty) {
		if (lastPlacedCard.getValue().equals(CValues.Seven)) {
			return pickingCardsQty + 2;
		}
		return pickingCardsQty;
	}

	@Override
	public boolean placedCardAllowed(Card currentActiveCard, Card placedCard, CColors color) {
		if (currentActiveCard.getValue().equals(CValues.Jack)) {
			if (color == null) {
				return currentActiveCard.getColor().equals(placedCard.getColor());
			} else {
				return color.equals(placedCard.getColor());
			}
		} else {
			if (currentActiveCard.getValue().equals(placedCard.getValue())) {
				return true;
			} else {
				return currentActiveCard.getColor().equals(placedCard.getColor());
			}
		}
	}

	@Override
	public boolean choosingColorAllowed(Card placedCard) {
		return placedCard.getValue().equals(CValues.Jack);
	}

	@Override
	public boolean changingDirectionAllowed(Card placedCard) {
		return placedCard.getValue().equals(CValues.Nine);
	}

	@Override
	public boolean playingThisRoundAllowed(Card lastPlacedCard) {
		return lastPlacedCard.getValue().equals(CValues.Eight);
	}
}
