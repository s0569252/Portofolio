package de.htwberlin.kompbentw.maumau.CardManagement.export;

public class Card {
	private CColors color;
	private CValues value;
	
	public Card(CColors color, CValues value) {
		this.color = color;
		this.value = value;
	}

	public CColors getColor() {
		return color;
	}

	public void setColor(CColors color) {
		this.color = color;
	}

	public CValues getValue() {
		return value;
	}

	public void setValue(CValues value) {
		this.value = value;
	}
	
	public String toString() {
		return value.toString() + " " + color.toString();
	}
	

}
