package de.htwberlin.kompbentw.maumau.CardManagement.impl;

import java.util.*;

import de.htwberlin.kompbentw.maumau.CardManagement.export.CColors;
import de.htwberlin.kompbentw.maumau.CardManagement.export.CValues;
import de.htwberlin.kompbentw.maumau.CardManagement.export.Card;
import de.htwberlin.kompbentw.maumau.CardManagement.export.CardService;
import de.htwberlin.kompbentw.maumau.CardManagement.export.CardStack;

public class CardServiceImpl implements CardService {
	

	private CardStack cardDeck;
	

	@Override
	public CardStack createDeck() {
		cardDeck = new CardStack();
        for (CColors color : CColors.values()){
            for (CValues value : CValues.values()) {
                cardDeck.getCards().add(new Card(color, value));
                //System.out.println(card.toString());
            }
        }
        return cardDeck;

	}

	@Override
	public List<Card> mixCardStack(List<Card> cards, boolean topCardRemains) {

		if(topCardRemains) {
			Card topcard = cards.get(cards.size() - 1);
			System.out.println(topcard.getValue() + " " + topcard.getColor());
			cards.remove(cards.size() - 1);
			Collections.shuffle(cards);
			cards.add(topcard);
//			System.out.println(cards.get(cards.size() - 1).getValue() + " " + topcard.getColor());
		} else {
			Collections.shuffle(cards);
		}
		return cards;

	}

	@Override
	public Card createNewCard(CColors color, CValues value) {
		return new Card(color, value);
	}
	
	@Override
	public boolean removeCard(CColors color, CValues value, CardStack deck) {
		Card removecard = new Card(color, value);
		boolean removed = false;
		for(Card card : deck.getCards()) {
			if(card.getColor() == removecard.getColor() && card.getValue() == removecard.getValue()) {
				deck.getCards().remove(card);
				removed = true;
			}
		}
		
		return removed;
		
	}

	@Override
	public CardStack ShowCard(CardStack cs) {
		System.out.println("Card:\n");
		CardStack c = new CardStack();
		for (int i = 0; i < c.getCards().size(); i++) {
			System.out.println(c.getCards().get(i));
		}
		return cs;
		
	}

	@Override
	public CardStack playCard(Card cd, boolean cardsSt) {
		CardStack cardToPlay = new CardStack();
		cardsSt = cardToPlay.getCards().remove(cd);
		return cardToPlay;
	}

	
}
