package de.htwberlin.kompbentw.maumau.CardManagement;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import de.htwberlin.kompbentw.maumau.CardManagement.export.CColors;
import de.htwberlin.kompbentw.maumau.CardManagement.export.CValues;
import de.htwberlin.kompbentw.maumau.CardManagement.export.Card;
import de.htwberlin.kompbentw.maumau.CardManagement.export.CardService;
import de.htwberlin.kompbentw.maumau.CardManagement.export.CardStack;
import de.htwberlin.kompbentw.maumau.CardManagement.impl.CardServiceImpl;

/**
 * Unit test for simple App.
 */
public class CardServiceTest 
{
	//global arrange
		private CardService cardservice = new CardServiceImpl();
		private Card cardass = new Card(CColors.Heart, CValues.Ace);
		private Card cardtwo = new Card(CColors.Heart, CValues.Two);
		private Card cardthree = new Card(CColors.Heart, CValues.Three);
		private List<Card> cards = new ArrayList<>();
		private CardStack cs = new CardStack();
		
		@Before
		public void setUp() {
			cards.add(cardass);
			cards.add(cardtwo);
			cards.add(cardthree);
			cs.getCards().add(cardtwo);
		}
		/**
	     * Testmethode für createDeck
	     */
		@Test
		public void testCreateDeck() {


			int size = cardservice.createDeck().getCards().size();
			assertEquals(52, size);

			
		}
		
		/**
	     * Testmethode für mixCardStack
	     */
		@Test
		public void testMixCardStack() {
			List<Card> mix = new ArrayList<>();
			mix.add(cardtwo);
			mix.add(cardass);
			mix.add(cardthree);
			List<Card> mixedCard = cardservice.mixCardStack(cards, true);
			assertEquals(mix.get(cards.size() -1), mixedCard.get(cards.size() -1));
			mixedCard = cardservice.mixCardStack(cards, false);
			
		}
		/**
	     * Testmethode für createNewCard
	     */
		@Test
		public void testCreateNewCard() {
			Card card = cardservice.createNewCard(CColors.Heart, CValues.Two);
			assertEquals(cardtwo.getColor(), card.getColor());
			assertEquals(cardtwo.getValue(), card.getValue());
			
		}
		/**
	     * Testmethode für createNewCard
	     */
		@Ignore
		public void testRemoveCard() {
			CardStack cardDeck = new CardStack();
	        for (CColors color : CColors.values()){
	            for (CValues value : CValues.values()) {
	            	Card card = cardservice.createNewCard(color, value);
	                cardDeck.getCards().add(card);
	                System.out.println(card.toString());
	            }
	        }
			assertTrue(cardservice.removeCard(CColors.Heart, CValues.Two, cardDeck));
		}

		/**
	     * Testmethode für showCard
	     */
		@Test
		public void testShowCard() {
			CardStack c = new CardStack();
			c.getCards().add(cardtwo);
			CardStack ca = cardservice.ShowCard(cs);
			assertEquals(c.getCards(), ca.getCards());
	
		}
		
		/**
	     * Testmethode für playCard
	     */
		@Test
		public void testPlayCard() {
			CardStack c = new CardStack();
			c.getCards().remove(cardthree);
			CardStack ca = cardservice.playCard(cardthree, false);
			assertEquals(c.getCards(), ca.getCards());
	
		}
}
