package de.htwberlin.kompbentw.maumau.CardManagement.export;

import java.util.List;


public interface CardService {
	/**Diese Methode legt einen Kartenstapel von 52 Karten an
    *
    * @return Liste der Karten von 52
    */
   CardStack createDeck();
   
   /**
    * Diese Methode mischt den Ziehstapel einmalig durch.
    *
    * @param obersteKarteBleibt - boolean, der angibt, ob die oberste Karte des Ablagestapels bleibt.
    * @return Gibt eine Liste an Karten zurueck, diese Liste ist dann durchgemischt
    */
   public List<Card> mixCardStack(List<Card> cards, boolean topCardRemains);
   

   /**
    * Diese Methode legt neue Karten an
    *
    * @param farbe - Die Farbe der neuen Karte (Enum Farbe beachten)
    * @param wert - Den Wert der neuen Karte
    * @return Die neue Karte
    */
   Card createNewCard(CColors color, CValues value);
   

   /** Diese Methode zeigt Kartenstapel an
    * @param cs
    * @return 
    */
   public CardStack ShowCard(CardStack cs);
   
   /**
    * @param cd
    * @param cardsSt
    * @return
    */
   CardStack playCard(Card cd, boolean cardsSt);

   /**
    * Diese Methode entfernt bestimmte Karte aus dem Stapel
    *
    * @param color - Die Farbe der neuen Karte (Enum Farbe beachten)
    * @param value - Den Wert der neuen Karte
    * @param deck - Kartestapel
    * @return Die entfernte Karte
    */
   boolean removeCard(CColors color, CValues value,CardStack deck);
   
   
}
