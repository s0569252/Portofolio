package de.htwberlin.kompbentw.maumau.CardManagement.export;

public enum CColors {
	Club {
    	public String toString() {
    		return "\u2663";
    	}
    },
	Diamond {
    	public String toString() {
    		return "\u2666";
    	}
    },
	Heart {
    	public String toString() {
    		return "\u2665";
    	}
    },
	Spade {
    	public String toString() {
    		return "\u2660";
    	}
    }
}
