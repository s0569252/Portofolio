package de.htwberlin.kompbentw.maumau.CardManagement.export;

public enum CValues {
    Two {
    	public String toString() {
    		return "2";
    	}
    },
    Three {
    	public String toString() {
    		return "3";
    	}
    },
    Four {
    	public String toString() {
    		return "4";
    	}
    },
    Five {
    	public String toString() {
    		return "5";
    	}
    },
    Six {
    	public String toString() {
    		return "6";
    	}
    },
    Seven {
    	public String toString() {
    		return "7";
    	}
    },
    Eight {
    	public String toString() {
    		return "8";
    	}
    },
    Nine {
    	public String toString() {
    		return "9";
    	}
    },
    Ten {
    	public String toString() {
    		return "10";
    	}
    },
    Jack {
    	public String toString() {
    		return "J";
    	}
    },
    Queen {
    	public String toString() {
    		return "Q";
    	}
    },
    King {
    	public String toString() {
    		return "K";
    	}
    },
    Ace {
    	public String toString() {
    		return "A";
    	}
    }
}
