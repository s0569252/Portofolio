package de.htwberlin.kompbentw.maumau.UserInterface.export;

import de.htwberlin.kompbentw.maumau.GameManagement.export.ApplicationException;

public interface GameController {
	
	/**
     * Die Methode, die den Ablauf des Spieles steuert
     */
	void run() throws ApplicationException;
	
}
