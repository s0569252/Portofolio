package de.htwberlin.kompbentw.maumau.UserInterface.impl;


import de.htwberlin.kompbentw.maumau.CardManagement.export.CColors;
import de.htwberlin.kompbentw.maumau.CardManagement.export.CValues;

public class GameViewer {
	
	static final String ANSI_RESET = "\u001B[0m";
	static final String ANSI_RED = "\u001B[31m";
	static final String GREEN = "\033[0;32m";
	static final String BLUE = "\033[0;34m";
    
    
    /**
     * Diese Methode fragt ab, ob ein weiterer menschlicher Spieler hinzugefuegt werden soll
     *
     */
    public void shallAddPlayer() {
    	System.out.println();
    	System.out.println("Want to add another player to the game?");
    }
    
    /**
     * Diese Methode gibt erst eine gestrichelte Linie und im Anschluss eine leere Zeile aus
     */
    public void LineWithStitches() {
    	System.out.println("-------------------------------------------------------");
        System.out.println();
    }
    
    /**
     * Diese Methode fordert den Spieler nach fehlerhafter ja nein Eingabe auf,
     * entweder ja oder nein einzugeben
     */
    public void YesNoQueryErrorMessage() {
        System.out.println(ANSI_RED + "Your input was incorrect, please enter \\\"yes\\\" or \\\"no\\\"." + ANSI_RESET);
    }
    
    /**
     * Diese Methode zeigt die Regeln des Spieles an.
     */
    
    public void showRules() {
    	System.out.println("\n---- THE RULES ----\n"+
    "- The simple rules -\n"+
    "Each player may discard one card at a time in clockwise order. \n"+
    "Only one card may be placed if it is in suit (hearts, clubs, spades, diamonds) .\n"+
    "or in value (for example: king or 7) match. \n"+
    "If a player cannot lay a card, he must draw a card and it is the next player's turn. \n"+
    "If a player wants to place his penultimate card, he must first enter \"m\" for Mau. \n"+
    "If \"Mau\" is forgotten, the player gets 2 penalty cards in his hand. \n");
    	System.out.println("\n"+
    "- The extended rules - \n" + 
    "The following rules apply in addition to the simple rules.\n"+
    "When a player places a \"Jack\", he must choose a color, it does not matter,\n"+
    "which color it is.\n"+
    "But on a jack may not be placed another.\n"+
    "If a player lays a \"7\", the next player must draw 2 cards.\n"+
    "If a player lays an \"8\", the following player must sit out.\n"+
    "If, on the other hand, a player lays a \"9\", the direction of play is reversed.\n");
    }
    
    /**
     * Feedback, wenn der Spieler Mau gesagt hat
     */
    public void mauSaid() {
        System.out.println("You just said \"mau\".");
        System.out.println("Which card do you want to lay?");
    }
    
    /**
     * Gibt die Infos zu einer Karte aus
     *
     * @param cardnumber - Kartennummer auf der Hand
     * @param color - Farbe der Karte
     * @param value - Wert der Karte
     */
    public void outputCard(int cardnumber, CColors color, CValues value) {
        System.out.println("Card Number " + cardnumber + " : " + color + " " + value);
    }
    
    /**
     * Methode fragt, welche Karte der Spieler ablegen will oder ob er eine Ziehen will
     * Außerdem das der Spieler hier Mau sagen koennte
     */
    public void whichCardToDiscard() {
        System.out.println("\nWhich card do you want to lay? (If Mau is necessary, enter it first \"m\" \n and confirm it with ENTER..)\n" +
                "If no card is possible, just enter \"z\" for pull. \n" +
                "Please enter the card number.");
    }
    
    /**
     * Methode sagt dem Spieler, das die Nummer seiner Handkarte, die er legen wollte, unsinnig ist
     */
    public void cardnumberNonsense() {
        System.out.println(ANSI_RED + "You made an input that doesn't make sense with your hand cards.\n" +
                "Please make a sensible input." + ANSI_RESET);
    }

    /**
     * Methode begruesst die Spieler zu einem neuen Spiel
     * und fragt ihn ob er ein neues Spiel starten oder ein altes fortsetzen will
     */
    public void welcome() {
        System.out.println("\n" +
                "-----------------------------------------------------------" +
                "\nWelcome to the MauMau game.");
        System.out.println("If you want to start a new game, please enter 1"); //Vorbereitung Aufgabe 4
        System.out.println("If you want to continue a game, select the 2");
        System.out.println("Which variant do you want to play?");
    }
    
    /**
     * Methode fragt nach dem Namen des menschlichen Spieler
     */
    public void playerNamesRequests() {
        System.out.println();
        System.out.println("What name should the human player have?");
    }
    
    /**
     * Methode fragt, ob die Regeln angezeigt werden sollen
     */
    public void ShallRuleShow() {
        System.out.println();
        System.out.println("Would you like to see the rules,\n" +
                "before you decide whether to play with simple or extended rules?\n" +
                "ATTENTION: The rules can be viewed only now.");
    }
    
    /**
     * Methode fragt, ob nach erweiterten Regeln gespielt werden soll
     */
    public void ShallBePlayedByExtendedRules() {
        System.out.println("Would you like to play by extended rules?");
    }

    /**
     * Diese Methode zeigt dem jeweils naechsten Spieler alle wichtigen Infos fuer seinen Zug an
     *
     * @param playername - Name des Spielers
     * @param numBerOfDrawnCards - Anzahl der Karten die er zu beginn seines Zuges ziehen musste
     */
    public void infosforNextPlayer(String playername, int numBerOfDrawnCards) {
        System.out.println("\n\n-- actual player --");
        System.out.println(playername);
        System.out.println("\nYou must " + numBerOfDrawnCards + " Cards drawn.");

    }

    /**
     * Diese Methode gibt aus, welche Karte oben auf dem Ablagestapel liegt
     *
     * @param TopCardDrawStackColor - Farbe der obersten Karte auf dem Ablagestapel
     * @param TopCardDrawStackValue - Wert der obersten Karte auf dem Ablagestapel
     */
    public void DiscardpileShow(CColors TopCardDrawStackColor, String TopCardDrawStackValue) {
        System.out.println("The top card of discard pile shows: " + TopCardDrawStackColor + " " + TopCardDrawStackValue);
    }

    /**
     * Methode weisst den Spieler darauf hin, dass er eine falsche Karte legen wollte
     */
    public void wrongCard () {
        System.out.println(ANSI_RED + "You have tried to put a imposible card, " +
                "please now put a possible." + ANSI_RESET);
    }

    /**
     * Methode bitten den Spieler, nach dem Legen eines Buben, eine Farbe zu waehlen
     */
    public void colorChoose() {
        System.out.println("You have laid a jack please choose the number of the color:\n" +
                "The choices are\n1: Heart\n2: Cross\n3: Diamonds\n4: Spades\n");
    }

    /**
     * Methode weisst den naechsten Spieler daraufhin, dass durch einen Buben soeben die Farbe gewechselt wurde
     * @param colorJack - Die Farbe die nun nach dem Buben gilt
     */
    public void playerInfoOfJack(CColors colorJack) {
        System.out.println("The last player has laid a jack and wished the color \"" + colorJack);
    }

    /**
     * Information, dass der Spieler vergessen habe Mau zu sagen und daher zwei Strafkarten auf die Hand bekommen hat
     */
    public void PenaltyCardsForgottenMau(String playername) {
        System.out.println(ANSI_RED + "The Player" + playername + " forgot to say Mau und must take 2 penalty cards" + ANSI_RESET);
    }

    /**
     * Informiert, dass automatisch ein weiterer Spieler hinzugefuegt wurde, da die Mindestspielerzahl 2 betraegt
     */
    public void otherPlayerNecessary() {
        System.out.println("Since a game requires at least two players,\nanother one must be added.");
    }

    /**
     * Methode gibt aus, das ein anderer gespielt hat
     * @param spielerName - Name des Spielers der gespielt hat
     */
    public void kiHatPlayed(String playerName) {
        System.out.println(playerName + " has played.");
    }

    /**
     * Fragt den Spieler ob er ein neues Spiel starten will
     */
    public void nextGameStarten() {
        System.out.println("Do you want to start another game?");
    }

    /**
     * Methode gibt aus, das ein Spieler gewonnen hat.
     * @param name - Name des Gewinners
     */
    public void winnerOutput(String name) {
        System.out.println( name + "has won");
    }

    /**
     * Methode informiert den Spieler das ein Karte ziehen nicht moeglich ist,
     * da alle Karten bereits auf den Spielerhaenden liegen
     */
    public void playerCheated() {
        System.out.println(ANSI_RED + "A card draw is no longer possible, since you have cheated " +
                "\nand now all cards are on your hands " + ANSI_RESET);
    }

    /**
     * Diese Methode informiert über einen weiteren Mitspieler und dessen Anzahl an Handkarten
     * @param mitspielername - Name des Mitspielers
     * @param mitspielerhandkarten - Anzahl der Handkarten jenes Mitspielers
     */
    public void infoAboutOtherPlayers(String opponentname, int opponenthandcards) {
        System.out.println("The Opponent " + opponentname + " has " + opponenthandcards + " hand cards(n)");
    }

    /**
     * Methode informiert darueber das ein anderer Spieler eine Karte gezogen hat
     * @param name - Name des Spielers, der eine Karte gezogen hat
     */
    public void pcHasDrawn(String name) {
        System.out.println(name + " has drawn.");
    }

    /**
     * Methode gibt aus, das der letzte Spieler Mau sagte
     */
    public void playerSayMau() {
        System.out.println("The last player said Mau");
    }

    /**
     * Methode zeigt die Frage, wie viele pc gesteuerte Spieler gewuenscht sind
     */
    public void amountKI() {
        System.out.println("How many computer controlled players do you want?");
    }

    /**
     * Methode gibt an, dass eine gewisse Zahleneingabe erwartet wurde, diese aber nicht erfuellt wurde
     *
     * @param minimumNumber - kleinste erwartete Zahl
     * @param maximumNumber - groesste erwartete Zahl
     */
    public void inputNumberError(int minimumNumber, int maximumNumber) {
        System.out.println("Your input was incorrect, please enter a number between" + minimumNumber + " and "
                + maximumNumber);
    }

    /**
     * Methode gibt dank aus, das der Spieler dieses Spiel spielte
     */
    public void gameend() {
        System.out.println("It was nice playing with you. Please check back soon.");
    }

    /**
     * gibt Aufforderung zum Eingeben der SpielID aus.
     */
    public void gameIDenter() {
        System.out.println("Please enter the game ID");
    }

    /**
     * Methode gibt zum laufenden Spiel die Info ueber die aktuelle SpielID aus.
     *
     * @param gameid - ID, die ausgegeben wird
     */
    public void showGameID(Long gameid) {
        System.out.println(ANSI_RED + "For this game, the game ID is: " + gameid +
                "\nThis is needed to continue the game later.\n" + ANSI_RESET);
    }

    /**
     * Methode gibt an, dass die SpielID nicht vorhanden ist
     */
    public void wrongID() {
        System.out.println(ANSI_RED + "This game ID doesn't exist!" + ANSI_RESET);
    }

    /**
     * Methode gibt an, dass das geswuenschte Spiel bereits beendet ist
     * Außerdem informiert sie uber den Gewinner
     *
     * @param winner - Name des Gewinners
     */
    public void gameReadyEnded(String winner) {
        System.out.println(ANSI_RED + "This ID has a winner! The winner is " + winner + ANSI_RESET);
    }

    /**
     * Methode gibt aus, dass das ziehen von Strafkarten nicht moeglich war
     */
    public void penaltyCardsNotPossible() {
        System.out.println(ANSI_RED + "Drawing penalty cards after forgotten mau was " +
                "\nimpossible, as there are no more cards"+ ANSI_RESET);
    }
    
}
