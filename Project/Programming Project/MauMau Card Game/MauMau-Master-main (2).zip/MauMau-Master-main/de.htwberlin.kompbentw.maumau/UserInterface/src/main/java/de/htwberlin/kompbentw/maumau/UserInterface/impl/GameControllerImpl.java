package de.htwberlin.kompbentw.maumau.UserInterface.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import org.apache.log4j.Logger;

import de.htwberlin.kompbentw.maumau.CardManagement.export.CColors;
import de.htwberlin.kompbentw.maumau.CardManagement.export.CValues;
import de.htwberlin.kompbentw.maumau.CardManagement.export.Card;
import de.htwberlin.kompbentw.maumau.CardManagement.export.CardStack;
import de.htwberlin.kompbentw.maumau.GameManagement.export.ApplicationException;
import de.htwberlin.kompbentw.maumau.GameManagement.export.Game;
import de.htwberlin.kompbentw.maumau.GameManagement.export.GameService;
import de.htwberlin.kompbentw.maumau.PlayerManagement.export.Player;
import de.htwberlin.kompbentw.maumau.UserInterface.export.GameController;

public class GameControllerImpl implements GameController{
	
	private GameService gameservice;
	private GameViewer view = new GameViewer();
	private List<String> players;
	private Game game;
	
	private boolean gamerunning;
	private boolean extendedrules;
	
	
	private Scanner sc = new Scanner(System.in);
	private static Logger log = Logger.getRootLogger();
	
	
	public GameControllerImpl(GameService gameservice) {
		this.gameservice = gameservice;		
	}
	
	// non jpa
	@Override
	public void run() throws ApplicationException {
		do {
			//Building new game
			
			game = new Game();
			players = new ArrayList<>();
			game.setGameRoundIndex(0);
			
			
			do {
				players.add(playerAdd());
			}while(nextPlayer()== true);
			game = gameservice.createNewGame(players, extendedrules);
			
			
			log.debug("Game is running");
			// Das Spiel beginnt
			
			
			gameplay(this.game);
			
		}while(nextRound());
		sc.close();
		view.gameend();
	}

	/**
     * Diese Methode steuert den eigentlichen Spielablauf
     * Inklusive noetiger Exceptionbehandlungen
     *
     * @param dasSpiel - Das zu spielende Spiel
     */
    private void gameplay( Game theGame) throws ApplicationException {
        gamerunning = true;
        while (gamerunning) {
        	
        	CardStack csPickFrom = new CardStack();
        	csPickFrom.setCards(theGame.getDeckToPickFrom());
        	gameservice.pickFirstCards(csPickFrom, theGame.getActivePlayer(),theGame.getCardsToPick());
        	
        	// if sequence for choosing between human and computer player
        	theGame = playerPlay(theGame);
        	
        	gamerunning = gameservice.checkGameEnd(theGame.getActivePlayer());
        	
        	if(!gamerunning) {
        		view.winnerOutput(theGame.getActivePlayer().getName());
        		theGame.setWinner(theGame.getActivePlayer().getName());
        		
        		break;
        	}
        	
        	theGame.setGameRoundIndex(theGame.getGameRoundIndex() + 1);
        	
        	if(theGame.getGameRoundIndex() > 0 ) {
        		gameservice.setNextPlayer(theGame);
        		theGame.setSuspend(false);
        	}
        	
        }
    }
    
	// with jpa
	/**@Override
	public void run() {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("jpaDemoSSPU");
		EntityManager em = entityManagerFactory.createEntityManager();
		
		do {
			
			log.debug("Game is running");
			// Das Spiel beginnt
			gameplay( em, game);
			
		}while(nextRound());
		sc.close();
		view.gameend();
	}
	**/
	
	 /**
     * Diese Methode steuert den eigentlichen Spielablauf
     * Inklusive noetiger Exceptionbehandlungen
     *
     * @param dasSpiel - Das zu spielende Spiel
     */
    /**
    private void gameplay(EntityManager em, Game theGame)  {
        gamerunning = true;
        while (gamerunning) {
        	em = establishConnection(em);
        	
        	CardStack csPickFrom = new CardStack();
        	csPickFrom.setCards(theGame.getDeckToPickFrom());
        	gameservice.pickFirstCards(csPickFrom, theGame.getActivePlayer(),theGame.getCardsToPick());
        	
        	// if sequence for choosing between human and computer player
        	
        	
        	gamerunning = gameservice.checkGameEnd(theGame.getActivePlayer());
        	
        	if(!gamerunning) {
        		view.winnerOutput(theGame.getActivePlayer().getName());
        		theGame.setWinner(theGame.getActivePlayer().getName());
        		em = savingDatabase(theGame, em);
        		break;
        	}
        	
        	theGame.setGameRoundIndex(theGame.getGameRoundIndex() + 1);
        	
        	if(theGame.getGameRoundIndex() > 0 ) {
        		gameservice.setNextPlayer(theGame);
        		theGame.setSuspend(false);
        	}
        	
        	em = savingDatabase(theGame, em);
        }
    }
    **/
    
    // implementing jpa 
    /**
     * Methode wendet begin() auf den EntityManager an und behandelt gleichzeitig moegliche Exceptions
     *
     * @param em - der zuveraendernde EntityManager
     * @return - den veraenderten EntityManager
     * 
     */
    private EntityManager establishConnection(EntityManager em) {
        try {
            em.getTransaction().begin();
        } catch (Exception e) {
            System.out.println("Error in databank");
        }
        return em;
    }
	
    private EntityManager savingDatabase(Game theGame, EntityManager em) {
    	try {
    		em.persist(theGame);
    		em.getTransaction().commit();
    	}catch(Exception e) {
    		em.getTransaction().rollback();
    		System.out.println("Error in saving on databank");
    	}
    	return em;
    }
    
    
    
    
    
    
    // game controll management
    
    /**
     * Methode prueft ob die Karte gelegt werden darf
     *
     * @param requestedCards - die Karte die der Spieler legen will
     * @param theGame - Das laufende Spiel
     * @return - Das veraenderte Spiel
     */
    private Game successfullyPlaced (Game theGame, int requestedCards) {
    	theGame = gameservice.playCard(theGame, theGame.getActivePlayer(), theGame.getActivePlayer().getCards().getCards().get(requestedCards));
    	return theGame;
    }
    
    /**
     * Methode steuert alles, was fuer einen Zug eines realen Spielers noetig ist
     *
     * @param dasSpiel - Das laufende Spiel
     * @return - Das veraenderte Spiel
     */
    private Game playerPlay(Game theGame) {
    	theGame = playerInfo(theGame);
    	theGame = createCard(theGame);
    	theGame = mauChecking(theGame);
    	gameservice.sayMau(theGame.getActivePlayer(), false);
    	try {
    		gameservice.mussCardsBeMixed(theGame);
    	}catch(IndexOutOfBoundsException e) {
    		view.playerCheated();
    	}
    	return theGame;
    }
    
    /**
     * Diese Methode fragt ob ein weiterer Spieler gewuenscht ist
     *
     * @return boolean - der angibt, ob es einen weiteren Spieler geben soll
     */
    
    private boolean nextPlayer() {
    	log.debug("nextPlayer");
    	if(players.size() < 2) {
    		view.otherPlayerNecessary();
    		return true;
    	}else {
    		return shallPlayerAdded();
    	}
    	
    }    
    /**
     * Methode prueft ob es der Spieler Mau gesagt hat, oder ob er Strafkarten ziehen muss und sorgt
     * falls nicht dafuer, dass Strafkarten gezogen werden und fuer eine Info
     *
     * @param game - Das Spiel mit dem enthaltenen Spieler, der geprueft werden soll
     * @return - Das Spiel mit dem ggfs geaenderten Spieler
     */
    private Game mauChecking(Game game) {
    	log.debug("mauChecking");
    	int numberCardBeforeChecking;
    	int numberCardAfterChecking;
    	
    	numberCardBeforeChecking = game.getActivePlayer().getCards().getCards().size();
    	try {
    		game = gameservice.checkMau(game);
    	}catch (IndexOutOfBoundsException e) {
    		view.penaltyCardsNotPossible();
    	}
    	numberCardAfterChecking = game.getActivePlayer().getCards().getCards().size();
    	
    	if(numberCardBeforeChecking > numberCardAfterChecking) {
    		view.PenaltyCardsForgottenMau(this.game.getActivePlayer().getName());
    	}
    	
    	return game;
    }
    /**
     * Gibt alle Infos aus, die der Spieler zu Beginn seiner Runde braucht
     * Ausserdem werden dem Spieler ggfs Karten auf die Hand gegeben, falls er ziehen muss
     * Und der Zahler im Spiel, wie viele Karten gezogen werden muessen wird resettet
     * Außerdem werden Infos ueber die anderen Spieler angezeigt
     *
     * @param spiel - Aus dem die Infos entnommen werden sollen
     * @return - Das angepasste Spiel
     */
    private Game playerInfo(Game game) {
    	log.debug("playerInfo");
    	String playername;
    	int pickedCardNumber;
    	playername = game.getActivePlayer().getName();
    	pickedCardNumber = game.getCardsToPick();
    	
    	view.infosforNextPlayer(playername, pickedCardNumber);
    	showTopCard(game);
    	
    	for(int i = 0; i< game.getAllPlayers().size(); i++) {
    		if(!game.getAllPlayers().get(i).equals(game.getActivePlayer())) {
    			String coplayer = game.getAllPlayers().get(i).getName();
    			int coplayerCard = game.getAllPlayers().get(i).getCards().getCards().size();
    			view.infoAboutOtherPlayers(coplayer, coplayerCard);
    		}
    	}
    	this.game.setCardsToPick(0);
    	return game;
    }
    
    /**
     * Methode stellt eine Ausgabe zusammen, die anzeigt, welche Karte oben auf dem Ablagestapel liegt
     * sofern dies ein Bube ist und nach erweiterten Regeln gespielt wird, gibt sie auch den neuen Farbwunsch aus
     *
     * @param theGame - Spiel dem die Infos entnommen werden sollen
     */
    private void showTopCard(Game theGame) {
    	CColors colorForJack;
    	CColors topCardFillingStackColor;
    	CValues topCardFillingStackValue;
    	
    	topCardFillingStackColor = theGame.getDeckToPlaceOn().get(theGame.getDeckToPlaceOn().size() - 1).getColor();
    	topCardFillingStackValue = theGame.getDeckToPlaceOn().get(theGame.getDeckToPlaceOn().size() - 1).getValue();
    	colorForJack = theGame.getColor();
    	
    	if(topCardFillingStackValue.equals(CValues.Jack)) {
    		if(theGame.getColor() != null) {
    			view.playerInfoOfJack(colorForJack);
    		}
    	}
    	
    	view.DiscardpileShow(topCardFillingStackColor, topCardFillingStackValue.toString());
    }
    
    /**
     * Diese Methode kuemmert sich um das legen einer Karte. Dafuer werden dem Spieler erst einmal alle benoetigten
     * Informationen zu seinen Moeglichkleiten angezeigt
     * Der Spieler muss eine Entscheidung treffen und die Karte wird gespielt
     *
     * @param spiel - das zu aendernde Spiel
     * @return - das Spiel in neuer Form
     */
    private Game createCard(Game game) {
    	log.debug("createCard");
    	
    	view.whichCardToDiscard();
    	for (int i = 0; i < game.getActivePlayer().getCards().getCards().size(); i++) {
    		CColors color = game.getActivePlayer().getCards().getCards().get(i).getColor();
    		CValues value = game.getActivePlayer().getCards().getCards().get(i).getValue();
    		view.outputCard(i, color, value);
    	}
    	
    	game = inputForCreateCard(game);
    	
    	if (game.isChooseColor()) {
    		game = colorChoose(game);
    	}
    	
    	return game;
    }
    
    /**
     * Methode steuert alles notwenige fuer die Eingabe eines Spielers, wenn er aufgefordert wird eine Karte zu legen
     * Dabei auftretende Exceptions werden gleich mitbehandelt
     *
     * @param game - Das laufende Spiel
     * @return - Das veraenderte Spiel
     */
    private Game inputForCreateCard(Game game) {
    	String answer;
    	boolean renewedQuestions = false;
    	int answerAsNumber;
    	
    	do {
    		answer = sc.next();
    		answer = answer.toLowerCase();
    		if(answer.equals("m")) {
    			view.mauSaid();
    			gameservice.sayMau(game.getActivePlayer(), true);
    		}else if(answer.equals("z")){
    			try {
    				
    			}catch (IndexOutOfBoundsException e) {
    				view.playerCheated();
    			}
    			renewedQuestions = false;
    		}else {
    			try {
    				answerAsNumber = Integer.parseInt(answer);
    				if(answerAsNumber >= 0 && answerAsNumber < game.getActivePlayer().getCards().getCards().size()) {
    					game = successfullyPlaced(game, answerAsNumber);
    					renewedQuestions = !game.isSuccessfullyLaid();
    					if(renewedQuestions) {
    						view.wrongCard();
    					}
    				} else {
    					renewedQuestions = true;
    					view.cardnumberNonsense();
    				}
    				
    			}catch(java.lang.NumberFormatException e) {
    				view.cardnumberNonsense();
    				renewedQuestions = true;
    			}
    		}
    	} while (renewedQuestions);
    	return game;
    }
    
    /**
     * Methode ist da, damit der Spieler nach einem legen eines Buben aufgefordert wird eine Farbe zu waehlen.
     *
     * @param spiel - Das veraendert werden soll
     * @return - dasSpiel, was uebergeben wurde, nachdem es veraendert wurde
     */
    private Game colorChoose(Game game) {
    	log.debug("gameChoose");
    	int answer;
    	CColors color = null;
    	
    	view.colorChoose();
    	
    	answer = numberInput(1, 4);
    	switch(answer) {
    		case 1:
    			color = CColors.Heart;
    			break;
    		case 2:
    			color = CColors.Diamond;
    			break;
    		case 3:
    			color = CColors.Club;
    			break;
    		case 4:
    			color = CColors.Spade;
    			break;
    	}
    	
    	gameservice.pickCardColor(game, color);
    	return game;
    }
    
    /**
     * Diese Methode fragt ab, ob ein neues Spiel gestartet werden soll oder ein vorheriges fortgesetzt
     *
     * @return - 1 fuer neues Spiel, 2 fuer fortsetzen
     */
    
    private int whichGameType() {
    	log.debug("whichGameType");
    	int gametype = 0;
    	view.welcome();
    	gametype = numberInput(1, 2);
    	return gametype;
    }
    
    /**
     * Methode fragt, welche SpielID fortgesetzt werden soll
     *
     * @return - gewuenschte SpielID
     */
    
    private int whichGameId() {
    	log.debug("whichGameId");
    	int gameid;
    	view.gameIDenter();
    	
    	gameid = numberInput(0, 1000000);
    	return gameid;
    }
    
    /**
     * Diese Methode fragt ab, ob ein weiterer Spieler hinzugefuegt werden soll
     *
     * @return boolean, ob weiterer Spieler erwuenscht ist
     */
    private boolean shallPlayerAdded() {
    	log.debug("shallPlayerAdded");
    	view.shallAddPlayer();
    	return yesNoRequest();
    }
    
	/**
     * Diese Methode liest die Konsoleneingabe und prueft, ob mit ja oder nein geantwortet wurde,
     * sofern dies nicht der Fall ist, wird ein Fehler ausgegeben und der Benutzer wird aufgefordert mit
     * ja oder nein zu antworten
     *
     * @return - boolean: true fuer ja, false fuer nein
     */
    private boolean yesNoRequest() {
        log.debug("yesNoRequest");
        boolean nextRound = true;
        boolean returned = false;

        while (nextRound) {
            String antwort = sc.next();
            antwort = antwort.toLowerCase();
            if (antwort.equals("yes")) {
            	returned = true;
                nextRound = false;
            } else if (antwort.equals("no")) {
            	returned = false;
                nextRound = false;
            } else {
                view.YesNoQueryErrorMessage();
            }
        }
        return returned;
    }
    
    /**
     * Methode fragt den Namen des hinzuzufuegenden Spielers ab
     * und speichert diese Information als String
     *
     * @return - String mit dem Name des Spielers
     */
    private String playerAdd() {
    	log.debug("playerAdd");
    	view.playerNamesRequests();
    	String name = sc.next();
    	return name;
    }
    /**
     * Diese Methode fragt erst ab, ob die Spieler die Regeln lesen wollen und im Anschluss
     * nach welchen Regeln gespielt werden soll.
     *
     * @return - boolean, der angibt ob die erweiterten Regeln gewuenscht sind
     */
    private boolean extendedRules() {
    	log.debug("extendedRules");
    	boolean answer;
    	view.ShallRuleShow();
    	answer = yesNoRequest();
    	if( answer == true) {
    		view.showRules();
    	}
    	view.ShallBePlayedByExtendedRules();
    	return yesNoRequest();
    }
	
	/**
     * Methode fragt den Spieler ob er eine weitere Runde spielen will
     *
     * @return - Ergebnis ob er es moechte
     */
    private boolean nextRound() {
        view.nextGameStarten();
        return yesNoRequest();
    }
	
	/**
     * Methode liest eine Zahl ein, dabei darf diese nur aus einem bestimmten Bereich sein
     *
     * Methode faengt dabei auftretende Exceptions ab
     *
     * @param minimumNumber - kleinste Zahl die der Benutzer eingeben darf
     * @param maximumNumber - groesste Zahl die der Benutzer eingeben darf
     * @return - readInNumber
     */
	
	private int numberInput(int minimumNumber, int maximumNumber) {
		int readInNumber = 0;
		boolean error;
		String input;
		do {
			input = sc.next();
			try {
				readInNumber = Integer.parseInt(input);
				error = false;
			} catch (Exception e) {
				view.inputNumberError(minimumNumber, maximumNumber);
				error = true;
			}
		}while(error);
		
		return readInNumber;
	}
	
	
}
