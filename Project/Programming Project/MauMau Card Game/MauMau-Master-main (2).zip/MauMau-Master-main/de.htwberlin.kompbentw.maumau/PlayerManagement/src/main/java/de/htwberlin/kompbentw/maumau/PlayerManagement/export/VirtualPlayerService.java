package de.htwberlin.kompbentw.maumau.PlayerManagement.export;

import de.htwberlin.kompbentw.maumau.CardManagement.export.CColors;

public interface VirtualPlayerService {
	
	/**
	 * Hier wird die Name fuer Computer Spieler vergeben
	 * @param count Nummer des Computer Spielers
	 * @return Name des Computer Spielers
	 */
	String createVirtualPlayer(int count);
	/**
	 * Diese Methode waehlt zufaellig eine Farbe
	 * @return gewaehlte Farbe
	 */
	CColors virtualPlayerPicksColor();
	/**
	 * Diese Methode wird pruefen, ob ein Computer Spieler Mau sagen kann
	 * und entscheidet zufaellig ob es Mau sagt
	 * @param player - Computer Spieler
	 * @return True oder False
	 */
	boolean setMau(Player player);
	
}
