package de.htwberlin.kompbentw.maumau.PlayerManagement.impl;

import java.util.Random;
import de.htwberlin.kompbentw.maumau.CardManagement.export.CColors;
import de.htwberlin.kompbentw.maumau.PlayerManagement.export.Player;
import de.htwberlin.kompbentw.maumau.PlayerManagement.export.VirtualPlayerService;

public class VirtualPlayerServiceImpl implements VirtualPlayerService {

	@Override
	public String createVirtualPlayer(int count) {
		return "Bot: " + count;
	}

	@Override
	public CColors virtualPlayerPicksColor() {
		CColors color = null;
		
		var randomNum = new Random().nextInt(4);
		switch(randomNum) {
			case 0:
				color = CColors.Club;
				break;
			case 1:
				color = CColors.Diamond;
				break;
			case 2:
				color = CColors.Heart;
				break;
			case 3:
				color = CColors.Spade;
				break;
			default:
				color = null;
				break;
		}
		return color;
	}

	@Override
	public boolean setMau(Player player) {
		return (player.getCards().getCards().size() == 1) && (new Random().nextInt(10) < 8);
	}

}
