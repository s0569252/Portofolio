package de.htwberlin.kompbentw.maumau.PlayerManagement.export;



import de.htwberlin.kompbentw.maumau.CardManagement.export.CardStack;

public class Player {
	private String name;
	private CardStack cards = new CardStack();
	private boolean mau = false;
	
	public Player(String name) {
		this.name = name;
	}
	
	public boolean isMau() {
		return mau;
	}

	public void setMau(boolean mau) {
		this.mau = mau;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public CardStack getCards() {
		return cards;
	}

	public void setCards(CardStack cards) {
		this.cards = cards;
	}
	
	public String toString() {
		return this.name;
	}

	

}
