package de.htwberlin.kompbentw.maumau.PlayerManagement.export;

import de.htwberlin.kompbentw.maumau.CardManagement.export.Card;



public interface PlayerService {
	 /**
     * Diese Methode fuegt einem Spieler eine Karte zu seinen Handkarten hinzu
     *
     *@param card - Die Karte die Hinzugefuegt werden soll
     *@param player - Der Spieler, dem die Karte hinzugefuegt werden soll
     */
	Player addCardToHandout(Card card, Player player);
	/**
     * Diese Methode entfernt eine Karte aus den Handkarten eines Spielers
     *
     *@param card - zu entfernende Karte
     *@param player - Der Spieler, aus dessen Handkarten die Karte entfernt werden soll
     */
	Player removeCardFromHandout(Card card, Player player);
	/**
     * Diese Methode sortiert die Liste der Karte aus den Handkarten eines Spielers
     *
     *@param cards - zu entfernende Karte
     *@param player - Der Spieler, aus dessen Handkarten die Karte sortiert werden soll
     */
	Player sortCardOnHand( Player player);
    /**
     * Legt einen neuen spielerverwaltung an
     *
     *@param name  - Name des neuen spielerverwaltung
     *@return der neue spielerverwaltung
     */
	Player createNewPlayer(String name);
	/**
     * Aufruf der Playerinfo
     *
     *@param player - Name des neuen spielerverwaltung
     */
	Player displayPlayerInfo(Player player);
	/**
     * Bestimmt ob der Spieler "Mau-Mau" sagte 
     *
     *@param player - Name des neuen spielerverwaltung
     */
	boolean isMau(Player player);


}
