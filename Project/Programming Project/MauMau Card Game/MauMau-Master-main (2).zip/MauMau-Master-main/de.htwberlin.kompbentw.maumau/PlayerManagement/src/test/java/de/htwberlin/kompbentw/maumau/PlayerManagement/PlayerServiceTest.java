package de.htwberlin.kompbentw.maumau.PlayerManagement;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import de.htwberlin.kompbentw.maumau.CardManagement.export.CColors;
import de.htwberlin.kompbentw.maumau.CardManagement.export.CValues;
import de.htwberlin.kompbentw.maumau.CardManagement.export.Card;
import de.htwberlin.kompbentw.maumau.PlayerManagement.export.Player;
import de.htwberlin.kompbentw.maumau.PlayerManagement.export.PlayerService;
import de.htwberlin.kompbentw.maumau.PlayerManagement.impl.PlayerServiceImpl;

/**
 * Unit test for simple App.
 */
public class PlayerServiceTest 
{
	//global Arrange
		PlayerService p;
		private List<Card> cardsonhand = new ArrayList<>();
		private Card card1 = new Card(CColors.Heart, CValues.Ace);
		private Card card2 = new Card(CColors.Heart,CValues.Two);
		private Card card3 = new Card(CColors.Heart,CValues.Three);
		private Card card4 = new Card(CColors.Heart,CValues.Four);
		private Player player = new Player("Samuel");
		
		
		@Before
		public void setUp() {
			p = new PlayerServiceImpl();
			cardsonhand.add(card1);
			player.getCards().setCards(cardsonhand);
		}
		
		/**
	     * Testmethode für addCardToHandout
	     */
		@Test
		public void testAddCardToHandout() {
			//Arrange

			//Act
			p.addCardToHandout(card2, player);
			cardsonhand.add(card2);
			//Assert
			assertEquals(cardsonhand,player.getCards().getCards());
		}
		
		/**
	     * Testmethode für removeCardToHandout
	     */
		@Test
		public void testRemoveCardFromHandout() {
			p.removeCardFromHandout(card1, player);
			cardsonhand.remove(card1);
			assertEquals(cardsonhand,player.getCards().getCards());
		}
		
		/**
	     * Testmethode für sortCardOnHand
	     */
		@Ignore
		public void testSortCardOnHand() {
			player.getCards().getCards().add(card1);
			player.getCards().getCards().add(card2);
			player.getCards().getCards().add(card3);
			player.getCards().getCards().add(card4);
			cardsonhand.add(card1);
			cardsonhand.add(card2);
			cardsonhand.add(card3);
			cardsonhand.add(card4);
			p.sortCardOnHand(player);
			Collections.shuffle(cardsonhand);
			assertEquals(cardsonhand,player.getCards().getCards());
		}
		
		/**
	     * Testmethode für createNewPlayer
	     */
		@Test
		public void testCreateNewPlayer() {
			Player playerSamuel = p.createNewPlayer("Samuel");
			assertEquals(player.getName(), playerSamuel.getName());
		}
		
		/**
	     * Testmethode für displayPlayerInfo
	     */
		@Test
		public void testDisplayPlayerInfo() {
			player = p.displayPlayerInfo(player);
			assertNotNull(player);
		}
		/**
	     * Testmethode für displayPlayerInfo
	     */
		@Test
		public void testIsMau() {
			assertTrue(p.isMau(player));
		}
		

}
