package de.htwberlin.kompbentw.maumau.PlayerManagement.impl;



import java.util.Collections;


import de.htwberlin.kompbentw.maumau.CardManagement.export.Card;

import de.htwberlin.kompbentw.maumau.PlayerManagement.export.Player;
import de.htwberlin.kompbentw.maumau.PlayerManagement.export.PlayerService;

public class PlayerServiceImpl implements PlayerService {

	@Override
	public Player addCardToHandout(Card card, Player player) {
		// arrange cardstack from player and add card into it
		player.getCards().getCards().add(card);
		return player;

	}

	@Override
	public Player removeCardFromHandout(Card card, Player player) {
		// arrange cardstak from player and remove card from it
		player.getCards().getCards().remove(card);
		return player;

	}
	
	@Override
	public Player sortCardOnHand( Player player) {
		Collections.sort(player.getCards().getCards(),Collections.reverseOrder());
		return player;
	}

	@Override
	public Player createNewPlayer(String name) {
		Player player = new Player(name);
		player.setName(name);
		return player;
	}
	
	@Override
	public Player displayPlayerInfo(Player player) {
		player.toString();
		player.setCards(player.getCards());
		return player;
	}
	
	@Override
	public boolean isMau(Player player) {
		player.setMau(true);
		return player.isMau();
	}

}
