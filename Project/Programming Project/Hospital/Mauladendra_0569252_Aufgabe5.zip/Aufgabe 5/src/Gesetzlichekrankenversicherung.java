import java.io.*;

public class Gesetzlichekrankenversicherung extends Krankenversicherung implements Serializable{
	
	/**
	 * konstruktor Gesetzlichekrankenversicherung mit Versicherungsname
	 * @param Versicherungsnummer
	 * @param Versicherungsname
	 */
	public Gesetzlichekrankenversicherung(String Versicherungsnummer, String Versicherungsname)
	{
		super(Versicherungsnummer, Versicherungsname);
		
	}
	
	/**
	 * konstruktor Gesetzlichekrankenversicherung ohne Versicherungsname
	 * @param Versicherungsnummer
	 */
	public Gesetzlichekrankenversicherung(String Versicherungsnummer)
	{
		super(Versicherungsnummer);
		
	}
	
	/* (non-Javadoc)
	 * @see Krankenversicherung#calculateCoverage(double, int, int)
	 */
	@Override
	public double calculateCoverage(double cost, int quarter, int previousQuarter) {
		if(quarter!= previousQuarter) {
		return cost;
		}
		else
			return 0;
	}

	
}
