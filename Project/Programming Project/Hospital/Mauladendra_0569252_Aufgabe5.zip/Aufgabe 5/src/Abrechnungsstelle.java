
public class Abrechnungsstelle extends Stelle{
	
	public Abrechnungsstelle() {
		super();
		stelletyp = new ABRinfo();
	}
}
