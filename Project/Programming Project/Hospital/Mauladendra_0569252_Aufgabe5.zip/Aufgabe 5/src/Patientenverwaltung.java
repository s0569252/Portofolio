import java.util.*;
import java.io.*;
import java.nio.file.FileAlreadyExistsException;

/**
 * @author Imdi Melvana
 *
 */
public class Patientenverwaltung 
{
	static Scanner scan = new Scanner(System.in);
	static Krankhaus Helios= new Krankhaus("DE812524991", "Helios", "Schwanebecker", "Chaussee",5013125, "BERLIN");
	
	
	/**
	 * 	
	 * Beschreibung: Die Methoden wird in main-Methode gelesen und gedruckt
	 * @param args
	 */
	public static void main (String args[])
	{
		System.out.println(Helios.toString()+"\n");
		try 
		{
		Helios.patient.put("D1234", new Patient ("D1234","Herr","M�ller", "Hanna", "13.06.1992", "+491237891210", "Hannah@gmail.com", "A14567", "AOK", 7000, "Johannesstr. 18","", 1234567, "K�LN")) ;
		Helios.patient.put("D1264", new Patient ("D1264","Herr","Nash", "Jacob", "14.05.1991", "+491537892910", "Jacob@gmail.com", "B14311", "Allianz", 7000, "Hermannstr. 10","", 9827323, "BERLIN"));
		Helios.patient.put("D1334", new Patient ("D1334","Frau","Christin", "Rieka", "18.02.1982", "+491577803200", "Rieka@yahoo.com", "C11963", "Technniker Krankenkasse", 7000,"Friedrichstr. 01","", 3421414, "D�SSELDORF"));
		Helios.patient.put("D1554", new Patient ("D1554","Herr","Zapacosta", "Hermann", "01.03.1989", "+491537291191", "Hermann@yahoo.com", "D12366", "DAK", 7000, "Grenzstr. 05", "", 9848739, "BERLIN-NEUK�LN"));
		Helios.patient.put("D1104", new Patient ("D1104","Frau","Mocha", "Bianca", "12.11.1999", "+491337013232", "Mocha@gmail.com", "E24097", "Mawista",7000, "Markstr. 20", "", 3356478, "HAMBURG"));
		Helios.patientToString();
		}
		catch (Exception e) {
		System.err.println(e.getMessage());
		}
		auswahlMenu();
		
}
	/**
	 * Beschreibung: erzeugt die Methoden bei Eingabe 3
	 * @return
	 */
	private static String privatversicherungAnlegen() {
		String pkvn;
		String pkvnr;
		String patnr;
		System.out.println(" ");
		System.out.println("Bitte geben Sie die Versicherung ein: ");
		pkvn = scan.nextLine();
		System.out.println("Bitte geben Sie die Versicherungnummer ein: ");
		pkvnr = scan.nextLine();
		System.out.println("Bitte geben Sie die Patientennummer ein: ");
		patnr = scan.nextLine();
		
				if(Helios.patient.containsKey(patnr.toUpperCase())) 
				{
					Helios.patient.get(patnr.toUpperCase()).KVN.add(new Privatkrankenversicherung(pkvnr, pkvn));
					
				}
			
			else  
			{
				System.out.println("Fehler");
			}
		
		return pkvn+" - "+pkvnr+" wurde zur "+patnr+" hinzugefuegt";
	}
	
	/**
	 * Beschreibung: erzeugt die Methoden bei Eingabe 2
	 * @return String
	 */
	private static String gesetzversicherungAnlegen() {
		String pkvn;
		String pkvnr;
		String patnr;
		System.out.println(" ");
		System.out.println("Bitte geben Sie die Versicherung ein: ");
		pkvn = scan.nextLine();
		System.out.println("Bitte geben Sie die Versicherungnummer ein: ");
		pkvnr = scan.nextLine();
		System.out.println("Bitte geben Sie die Patientennummer ein: ");
		patnr = scan.nextLine();
		
		if(Helios.patient.containsKey(patnr.toUpperCase())) 
		{
			Helios.patient.get(patnr.toUpperCase()).KVN.add(new Gesetzlichekrankenversicherung(pkvnr, pkvn));
					
		}	
			
			else 
			{
				System.out.println("Fehler");
			}
		
		return pkvn+" - "+pkvnr+" wurde zur "+patnr+" hinzugefuegt";
	}
	
	/**
	 * Beschreibung: erzeugt die Methoden bei Eingabe 1
	 * @return String
	 */
	private static String patientAnlegenundpatnrZuordnen() {
		String patientID;
		String anrede;
		String Nachname; 
		String Vorname; 
		String Geburtsdatum; 
		String Telefonnumer; 
		String Email;
		String VNr; 
		String VNa;
		String Adresszeile1;
		String Adresszeile2;
		int Postleitzahl;
		String Ort;
		System.out.println(" ");
		System.out.println("Bitte geben Sie Patient-ID ein: ");
		patientID = scan.nextLine();
		System.out.println("Bitte geben Sie Anrede ein: ");
		anrede = scan.nextLine();
		System.out.println("Bitte geben Sie Nachname ein: ");
		Nachname = scan.nextLine();
		System.out.println("Bitte geben Sie Vorname ein: ");
		Vorname = scan.nextLine();
		System.out.println("Bitte geben Sie Geburtsdatum ein: ");
		Geburtsdatum = scan.nextLine();
		System.out.println("Bitte geben Sie Telefonnummer ein: ");
		Telefonnumer = scan.nextLine();
		System.out.println("Bitte geben Sie Email ein: ");
		Email = scan.nextLine();
		System.out.println("Bitte geben Sie Versicherungsnummer ein: ");
		VNr = scan.nextLine();
		System.out.println("Bitte geben Sie Versicherungsname ein: ");
		VNa = scan.nextLine();
		System.out.println("Bitte geben Sie Adresse1 ein: ");
		Adresszeile1 = scan.nextLine();
		System.out.println("Bitte geben Sie die Adresse2 ein: ");
		Adresszeile2 = scan.nextLine();
		System.out.println("Bitte geben Sie Postleitzahl ein: ");
		Postleitzahl = scan.nextInt();
		System.out.println("Bitte geben Sie Ort ein: ");
		Ort = scan.nextLine();
		Helios.addPatient(patientID, anrede, Nachname, Vorname, Geburtsdatum, Telefonnumer, Email, VNr, VNa, Adresszeile1, Adresszeile2, Postleitzahl, Ort);
		return patientID+" - "+anrede+" - "+Nachname+" - "+Vorname+" - "+Geburtsdatum+" - "+Telefonnumer+" - "+Email+" - "+VNr+" - "+VNa+" - "+Adresszeile1+" - "+Adresszeile2+" - "+Postleitzahl+" - "+Ort+" - "+" wurde hinzugefuegt";
	}
	
	/**
	 * Beschreibung: erzeugt die Methoden bei Eingabe 4
	 * @return String
	 */
	private static String auswahlPatientnr() {
		String patnr;
		System.out.println("Bitte geben Sie die Patientennummer ein: ");
		patnr = scan.nextLine();
		if(Helios.patient.containsKey(patnr.toUpperCase())) 
		{
			Helios.patient.get(patnr.toUpperCase()).toString();
			
		}
			else  {
				System.out.println("");
				System.out.println("Angabe nicht gefunden!!");
				System.out.println("");
			}
		
		return "";
	}
	
	/**
	 * Beschreibung: erzeugt die Methoden bei Eingabe 5
	 * @return String
	 */
	private static String auswahlName() {
		String patna;
		System.out.println("Bitte geben Sie Nachname ein: ");
		patna = scan.nextLine();
		String patvona;
		System.out.println("Bitte geben Sie Vorname ein: ");
		patvona = scan.nextLine();
		for(String i: Helios.patient.keySet()) {
		if(patna.equalsIgnoreCase(Helios.patient.get(i).getNachname()) && patvona.equalsIgnoreCase(Helios.patient.get(i).getVorname()) ) 
		{
			Helios.patient.get(i).toString();
			break;
		}	
		else {
					System.out.println("");
					System.out.println("Angabe nicht gefunden!!");
					System.out.println("");
		}
		}
		return "";
	}
	
	/**
	 * Beschreibung: erzeugt die Methoden bei Eingabe 6
	 * @return String
	 */
	private static String versicherungnrAnzeigen() {
		String vernr;
		boolean gefunden= false;
		System.out.println("Bitte geben Sie die Versicherungsnummer ein: ");
		vernr = scan.nextLine();
		
		for(String i: Helios.patient.keySet()) {
			for(int j=0; j<Helios.patient.get(i).KVN.size();j++) {
					if(vernr.equalsIgnoreCase(Helios.patient.get(i).KVN.get(j).getVersicherungsnummer())) 
					{
						System.out.println("");
						System.out.println(Helios.patient.get(i).KVN.get(j).toString());
						System.out.println("");
						gefunden = true;
						break;
					}	
					
				}
			}
		if (!gefunden) 
		{	
			System.out.println("");
			System.out.println("Angabe nicht gefunden!!");		
			System.out.println("");
		}
		return vernr;
	}
	
	/**
	 * Beschreibung: erzeugt die Methoden bei Eingabe 7
	 */
	private static void sortierenPatientennummer() {
		List<String> sortpatnr = new ArrayList<>(Helios.patient.keySet());
		Collections.sort(sortpatnr);
			for(int i=0; i<sortpatnr.size(); i++) {
				System.out.println (Helios.patient.get(sortpatnr.get(i)).toString());
			}
	}
	
	/**
	 * Beschreibung: erzeugt die Methoden bei Eingabe 8
	 */
	private static void sortierenNachname() {
		List<String> sortpatna = new ArrayList<>(Helios.patient.keySet());
			for(int i=0; i<sortpatna.size()-1; i++) {
				for(int j=i+1; j<sortpatna.size(); j++) {
					if(Helios.patient.get(sortpatna.get(j)).getNachname().compareToIgnoreCase(Helios.patient.get(sortpatna.get(i)).getNachname())<0) {
						String temp= sortpatna.get(i);
						sortpatna.set(i, sortpatna.get(j));
						sortpatna.set(j, temp);
					}		
				}
			}
			for(int i=0; i<sortpatna.size(); i++) {
	     		System.out.println (Helios.patient.get(sortpatna.get(i)).toString());
	     	}
	}
	
	/**
	 * Beschreibung: erzeugt die Methoden bei Eingabe 9
	 */
	private static void unsortierenKrankenversicherung() {
		
		for (Patient patient : Helios.patient.values())  
			System.out.println(patient);
	}
	
	public static void datenExport() {
		 
        try
        {    
            FileOutputStream file = new FileOutputStream("Heliosdata.ser"); 
            ObjectOutputStream out = new ObjectOutputStream(file); 
              
             
            out.writeObject(Helios); 
              
            out.close(); 
            file.close(); 
              
            System.out.println("Object has been saved"); 
            
        } 
          
        catch(FileNotFoundException e0) {
			 System.err.println("Die Datei wurde nicht gefunden.");
		 }
		 catch(FileAlreadyExistsException e1) {
			 System.err.println("Datei existiert bereits.");
		 }
		 catch(IOException e) {
			 System.err.println("Eingabe- oder Ausgabefehler!");
		 }
		catch(Exception exc) {
			 System.err.println("Fehler!");
		} 
	}
	
	private static void datenImport() {
		
		try {
            FileInputStream file = new FileInputStream("Heliosdata.ser");
            ObjectInputStream in = new ObjectInputStream(file);
            Krankhaus h = (Krankhaus) in.readObject();
            in.close();
            h.toString();
            h.patientToString();
            
		}
		catch(FileNotFoundException e0) {
			 System.err.println("Die Datei wurde nicht gefunden.");
		 }
		 catch(FileAlreadyExistsException e1) {
			 System.err.println("Datei existiert bereits.");
		 }
		 catch(IOException e) {
			 System.err.println("Eingabe- oder Ausgabefehler!");
		 }
		catch(Exception exc) {
			 System.err.println("Fehler!");
		} 
	}
	
	private static void sortierenCSV() {
		    String header= "Patientennummer,Name,AnzahlKV,HauptKV";
			String path = "Heliosdata.csv";
		    try { 
		    	FileWriter writer = new FileWriter(path, true);
		    	BufferedWriter bw = new BufferedWriter(writer);
		    	bw.write(header);
		    	bw.write("\n");
		    	
		    	for (String patient : Helios.patient.keySet()) { 
		    		System.out.println(" ");
		    		bw.write(Helios.patient.get(patient).getPatientID());
		    		bw.write(";");
		    		bw.write(Helios.patient.get(patient).getNachname());
		    		bw.write(",");
		    		bw.write(Helios.patient.get(patient).getVorname());
		    		bw.write(";");
		    		bw.write(Integer.toString(Helios.patient.get(patient).KVN.size()));
		    		bw.write(";");
		    		for(int j=0; j<Helios.patient.get(patient).KVN.size();j++) {
		    		bw.write(Helios.patient.get(patient).KVN.get(j).getVersicherungsname());
		    		bw.write("\r\n");
		    		}
		    		}
		    		System.out.println("Write success!");
		    		
		    		bw.close();
		     }
		    catch(FileNotFoundException e0) {
				 System.err.println("Die Datei wurde nicht gefunden.");
			 }
			 catch(FileAlreadyExistsException e1) {
				 System.err.println("Datei existiert bereits.");
			 }
			 catch(IOException e) {
				 System.err.println("Eingabe- oder Ausgabefehler!");
			 }
			catch(Exception exc) {
				 System.err.println("Fehler!");
			}

	}
	
	private static void readCSV() {	      
	        
	        BufferedReader br = null;
	      
			try {
	        	br = new BufferedReader(new FileReader("Heliosdata.csv"));
	            br.readLine(); //Skip the header line
	            String line = "";
	            while ((line = br.readLine()) != null) {
	    			System.out.println(line);
	    		}

	    		br.close();
	            }
	        catch(FileNotFoundException e0) {
				 System.err.println("Die Datei wurde nicht gefunden.");
			 }
			 catch(FileAlreadyExistsException e1) {
				 System.err.println("Datei existiert bereits.");
			 }
			 catch(IOException e) {
				 System.err.println("Eingabe- oder Ausgabefehler!");
			 }
			catch(Exception exc) {
				 System.err.println("Fehler!");
			}
	}
	
	private static void patientAufnehmen() {
		

	}
	
	private static void patientEntlassen() {
		

	}
	
	private static void protokollStrategie() {
		

	}
	/**
	 * Beschreibung: Ein Auswahlmen� wird erstellt und eingegeben
	 */
	public static void auswahlMenu() {
		String Eingabe= null;
		Scanner scan = new Scanner(System.in);
		
		while (!"16".equals(Eingabe))
		{
			System.out.println("**************************************************");
			System.out.println("\n");
			System.out.println("(1) Patient anlegen");
			System.out.println("(2) Gesetzliche Versicherung anlegen und Patientennummer zuordnen");
			System.out.println("(3) Privatversicherung anlegen und Patientennummer zuordnen");
			System.out.println("(4) Patient mit Krankenversicherungen anzeigen (Auswahl durch Patientennummer) ");
			System.out.println("(5) Patient mit Krankenersicherungen anzeigen (Auswahl durch Name)");
			System.out.println("(6) Krankenversicherungen anzeigen (Auswahl durch KVN)");
			System.out.println("(7) Alle Patienten sortiert nach aufsteigender Patientennummer anzeigen)");
			System.out.println("(8) Alle Patienten sortiert nach aufsteigendem Nachnamen");
			System.out.println("(9) Alle Krankenversicherungen unsortiert anzeigen");
			System.out.println("(10) Daten Export");
			System.out.println("(11) Daten Import");
			System.out.println("(12) Patienten nach Namen sortiert als CSV-Datei exportieren");
			System.out.println("(13) Patient aufnehmen");
			System.out.println("(14) Patient entlassen");
			System.out.println("(15) Protokoll-Strategie w�hlen");
			System.out.println("(16) Beenden");
			
			System.out.print("Eingabe:	");
			Eingabe= scan.nextLine();
		
			if(Eingabe.equals("1"))
			{
				patientAnlegenundpatnrZuordnen();
			}
		
			if(Eingabe.equals("2"))
			{
				gesetzversicherungAnlegen();
			}
		
			if(Eingabe.equals("3"))
			{
				privatversicherungAnlegen();
			}
		
			if(Eingabe.equals("4"))
			{
				auswahlPatientnr();
			}
		
			if(Eingabe.equals("5"))
			{
				auswahlName();
			}
		
			if(Eingabe.equals("6"))
			{
				versicherungnrAnzeigen();
			}
		
			if(Eingabe.equals("7"))
			{
				sortierenPatientennummer();
			}
			
			if(Eingabe.equals("8"))
			{
				sortierenNachname();
			}
			
			if(Eingabe.equals("9"))
			{
				unsortierenKrankenversicherung();
			}
			
			if(Eingabe.equals("10"))
			{
				datenExport();
			}
			
			if(Eingabe.equals("11"))
			{
				datenImport();
			}
			
			if(Eingabe.equals("12"))
			{
				sortierenCSV();
				readCSV();
			}
			
			if(Eingabe.equals("13"))
			{
				
			}
			
			if(Eingabe.equals("14"))
			{
				
			}
			
			if(Eingabe.equals("15"))
			{
				
			}
			
			if(!"1".equals(Eingabe) && !"2".equals(Eingabe) && !"3".equals(Eingabe) && !"4".equals(Eingabe) && !"5".equals(Eingabe) && !"6".equals(Eingabe) && !"7".equals(Eingabe) && !"8".equals(Eingabe) && !"9".equals(Eingabe) && !"10".equals(Eingabe) && !"11".equals(Eingabe) && !"12".equals(Eingabe) && !"13".equals(Eingabe) && !"14".equals(Eingabe) && !"15".equals(Eingabe) && !"16".equals(Eingabe))
			{
				System.out.println("Falsche Eingabe - Bitte neu Waehlen");
			}
		
		}	
		System.out.println("Programm beendet");
	}

}