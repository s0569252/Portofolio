import java.util.*;

public class Stelle {
	Observable observable;
	ArrayList<Patient> aufenthalt= new ArrayList<Patient>();
	public Information stelletyp;
	public Stelle() {} 
	public void setStelletyp (Information newInfotyp) {
		 stelletyp = newInfotyp;
		
	}
	
	public void addObserver(Patient PatientID) {
        this.aufenthalt.add(PatientID);
    }
 
    public void removeObserver(Patient PatientID) {
        this.aufenthalt.remove(PatientID);
    }
	
}
