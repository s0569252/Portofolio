import java.io.*;
/**
 * @author Imdi Melvana
 *
 */
public class Privatkrankenversicherung extends Krankenversicherung implements Serializable{
	
	private double deckungsLimit = 5062.50;
	/**
	 * 
	 */
	public Privatkrankenversicherung()
	{
		
	}
	
	/**
	 * konstruktor Privatkrankenversicherung mit Versicherungsname und deckungslimit
	 * @param Versicherungsnummer
	 * @param Versicherungsname
	 * @param deckungsLimit
	 */
	public Privatkrankenversicherung(String Versicherungsnummer, String Versicherungsname, double deckungsLimit)
	{
		super(Versicherungsnummer, Versicherungsname);
		this.deckungsLimit= deckungsLimit;
		
	}
	
	/**
	 * konstruktor Privatkrankenversicherung mit Versicherungsname 
	 * @param Versicherungsnummer
	 * @param Versicherungsname
	 */
	public Privatkrankenversicherung(String Versicherungsnummer, String Versicherungsname)
	{
		super(Versicherungsnummer, Versicherungsname);
		
	}
	
	/**
	 * konstruktor Privatkrankenversicherung ohne Versicherungsname und deckungslimit
	 * @param Versicherungsnummer
	 */
	public Privatkrankenversicherung(String Versicherungsnummer)
	{
		super(Versicherungsnummer);
		
	}
	
	/* (non-Javadoc)
	 * @see Krankenversicherung#calculateCoverage(double, int, int)
	 */
	@Override
	public double calculateCoverage(double cost, int quarter, int previousQuarter) {
		if(cost < deckungsLimit) {
		return cost;
		}
		else
			return deckungsLimit;
	}

}
