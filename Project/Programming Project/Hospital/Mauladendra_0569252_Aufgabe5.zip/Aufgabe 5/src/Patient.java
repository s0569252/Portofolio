import java.util.*;
import java.io.*;
/**
 * @author Imdi Melvana
 *
 */
public class Patient implements Serializable {
	
	private String PatientID;
    private Anrede anrede;
    private String Nachname;
    private String Vorname;
    private String Geburtsdatum;
    private String Telefonnumer;
    private String Email;
    ArrayList<Krankenversicherung> KVN = new ArrayList<Krankenversicherung>();
    private Adresse adresse;
    
   

    /**
     * konstruktor patient ohne Adresszeile2
     * @param PatientID
     * @param anrede
     * @param Nachname
     * @param Vorname
     * @param Geburtsdatum
     * @param Telefonnumer
     * @param Email
     * @param VNr
     * @param VNa
     * @param Adresszeile1
     * @param Postleitzahl
     * @param Ort
     */
    Patient (String PatientID,String anrede, String Nachname, String Vorname, String Geburtsdatum, String Telefonnumer, String Email, String VNr, String VNa, double deckungsLimit, String Adresszeile1, String Adresszeile2, int Postleitzahl, String Ort)
    {
        
        this.PatientID= PatientID;
        switch(anrede.toUpperCase()) {
        case "HERR" : 
        	this.anrede = Anrede.HERR;
        	break;
        case "FRAU" : 
        	this.anrede = Anrede.FRAU;
        	break;
        case "ANDERE" : 
        	this.anrede = Anrede.ANDERE;
        	break;
        
        }
        this.Nachname= Nachname;
        this.Vorname= Vorname;
        this.Geburtsdatum= Geburtsdatum;
        this.Telefonnumer= Telefonnumer;
        this.Email= Email;
        KVN.add(new Privatkrankenversicherung(VNr, VNa, deckungsLimit));
        adresse= new Adresse(Adresszeile1, Adresszeile2, Postleitzahl, Ort);
        
    }  
    
    /**
     * konstruktor patient mit Adresszeile2
     * @param PatientID
     * @param anrede
     * @param Nachname
     * @param Vorname
     * @param Geburtsdatum
     * @param Telefonnumer
     * @param Email
     * @param VNr
     * @param VNa
     * @param Adresszeile1
     * @param Adresszeile2
     * @param Postleitzahl
     * @param Ort
     */
    Patient (String PatientID,String anrede, String Nachname, String Vorname, String Geburtsdatum, String Telefonnumer, String Email, String VNr, String VNa, String Adresszeile1, String Adresszeile2, int Postleitzahl, String Ort)
    {
        
        this.PatientID= PatientID;
  
        switch(anrede.toUpperCase()) {
        case "HERR" : 
        	this.anrede = Anrede.HERR;
        	break;
        case "FRAU" : 
        	this.anrede = Anrede.FRAU;
        	break;
        case "ANDERE" : 
        	this.anrede = Anrede.ANDERE;
        	break;
        
        }
        this.Nachname= Nachname;
        this.Vorname= Vorname;
        this.Geburtsdatum= Geburtsdatum;
        this.Telefonnumer= Telefonnumer;
        this.Email= Email;
        KVN.add(new Privatkrankenversicherung(VNr, VNa));
        adresse= new Adresse(Adresszeile1, Adresszeile2, Postleitzahl, Ort);
        
    }  

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
    	System.out.println("");
    	System.out.println(this.PatientID+" - "+ this.anrede+" "+this.Nachname+", "+ this.Vorname +"\n"+ this.Geburtsdatum );  
     	for(int i=0; i<KVN.size(); i++) {
     		System.out.println (KVN.get(i).toString());
     	}
     	System.out.println (adresse.toString()+ "\n"+this.Telefonnumer);
     	return this.Email +"\n";
    }
          
    /**
     * @return String
     */
    public String getPatientID() 
    {
		return PatientID;
	}


	/**
	 * @return String
	 */
	public String getNachname() 
	{
		return Nachname;
	}

	/**
	 * @return String
	 */
	public String getVorname() 
	{
		return Vorname;
	}


	/**
	 * @return String
	 */
	public String getGeburtsdatum() 
	{
		return Geburtsdatum;
	}

	
	/**
	 * @return String
	 */
	public String getTelefonnumer() 
	{
		return Telefonnumer;
	}

	
	/**
	 * @return String
	 */
	public String getEmail() 
	{
		return Email;
	}


}

enum Anrede           
{
   HERR, FRAU , ANDERE
}