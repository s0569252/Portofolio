
public class QMstelle extends Stelle{
	
	public QMstelle() {
		super();
		stelletyp = new QMinfo();
	}
	
}
