
/**
 * @author Imdi Melvana
 *
 */
public abstract class Krankenversicherung 
{
	private String Versicherungsnummer;
	private String Versicherungsname;
		
	/**
	 * 
	 */
	public Krankenversicherung()
	{
	}
	
	
	/**
	 * konstruktor Krankenversicherung mit versicherungname
	 * @param Versicherungsnummer
	 * @param Versicherungsname
	 */
	public Krankenversicherung(String Versicherungsnummer, String Versicherungsname)
	{
		this.Versicherungsnummer= Versicherungsnummer;
		this.Versicherungsname= Versicherungsname;	
	}
	
	/**
	 * konstruktor Krankenversicherung ohne versicherungname
	 * @param Versicherungsnummer
	 */
	public Krankenversicherung(String Versicherungsnummer)
	{
		this.Versicherungsnummer= Versicherungsnummer;
		
		
	}
	
	/**
	 * Methode calculateCoverage
	 * @param cost
	 * @param quarter
	 * @param previousQuarter
	 * @return
	 */
	public double calculateCoverage(double cost, int quarter, int previousQuarter) {
		
		return previousQuarter;
		
	}
	
	/**
	 * @return String
	 */
	public String getVersicherungsnummer() 
	{
		return this.Versicherungsnummer;
	}
	
	/**
	 * @return String
	 */
	public String getVersicherungsname() 
	{
		return this.Versicherungsname;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() 
	{
		return this.Versicherungsnummer+" - "+this.Versicherungsname;
	}
}
