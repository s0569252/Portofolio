
public class Logger {
	private static Logger lg1;
	private Logger() {
		
	}
	
	public static Logger getInstance() {
		return lg1;
	}
	
	public void log(String message) {
		
	}
}
