import java.io.*;
import java.util.HashMap;

/**
 * @author Imdi Melvana
 *
 */
public class Krankhaus implements Serializable
{
	private String IDNummer;
	private String Name;
	HashMap<String, Patient> patient = new HashMap<String, Patient>();
	private Adresse adresse;
	
	
	/**
	 * konstruktor f�r Krankhaus 
	 * @param IDNummer
	 * @param Name
	 * @param Adresszeile1
	 * @param Adresszeile2
	 * @param Postleitzahl
	 * @param Ort
	 */
	public Krankhaus(String IDNummer, String Name, String Adresszeile1, String Adresszeile2, int Postleitzahl, String Ort) 
	{
		

		this.IDNummer = IDNummer;
		this.Name = Name;
		adresse= new Adresse(Adresszeile1, Adresszeile2, Postleitzahl, Ort);	
	}
		
	 /**
	  * koonstruktor f�r addPatient
	 * @param PatientID
	 * @param anrede
	 * @param Nachname
	 * @param Vorname
	 * @param Geburtsdatum
	 * @param Telefonnumer
	 * @param Email
	 * @param VNr
	 * @param VNa
	 * @param Adresszeile1
	 * @param Adresszeile2
	 * @param Postleitzahl
	 * @param Ort
	 */
	public void addPatient(String PatientID,String anrede, String Nachname, String Vorname, String Geburtsdatum, String Telefonnumer, String Email, String VNr, String VNa, String Adresszeile1, String Adresszeile2, int Postleitzahl, String Ort)
	   	{	
	   		patient.put(PatientID, new Patient(PatientID, anrede, Nachname, Vorname, Geburtsdatum, Telefonnumer, Email, VNr, VNa, Adresszeile1, Adresszeile2, Postleitzahl, Ort));
	   	}
	
	/**
	 * 
	 */
	public void patientToString() 
	{
		for(String i : patient.keySet())
		{
			System.out.println(patient.get(i));
		}
		
	}
	

		/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() 
	{
		return this.IDNummer+ " - " + this.Name+"\n"+adresse.toString();
		
	}
	
	
	

}
