import java.io.*;
/**
 * @author Imdi Melvana
 *
 */
public class Adresse implements Serializable 
{
	private String Adresszeile1;
	private String Adresszeile2;
	private int Postleitzahl;
	private String Ort;
	
	/**
	 * konstruktor Adresse mit Adressezzeile2
	 * @param Adresszeile1
	 * @param Adresszeile2
	 * @param Postleitzahl
	 * @param Ort
	 */
	public Adresse(String Adresszeile1, String Adresszeile2, int Postleitzahl, String Ort) 
	{
		this.Adresszeile1 = Adresszeile1;
		this.Adresszeile2 = Adresszeile2;
		this.Postleitzahl = Postleitzahl;
		this.Ort = Ort;
		
		
	}
	
	/**
	 * konstruktor Adresse ohne Adressezzeile2
	 * @param Adresszeile1
	 * @param Postleitzahl
	 * @param Ort
	 */
	public Adresse(String Adresszeile1, int Postleitzahl, String Ort) 
	{
		this.Adresszeile1 = Adresszeile1;
		this.Postleitzahl = Postleitzahl;
		this.Ort = Ort;	
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() 
	{
		if (Adresszeile2 == null || Adresszeile2 == "") 
		{
			return this.Adresszeile1+"\n"+this.Postleitzahl+" "+this.Ort;
		}
		else if (Adresszeile1 == null || Adresszeile1 == "") 
		{
			return this.Adresszeile2+"\n"+this.Postleitzahl+" "+this.Ort;
		}
	
		else
			
		return this.Adresszeile1+"\n"+this.Adresszeile2+"\n"+this.Postleitzahl+" "+this.Ort;
		
		
	}
	
}
