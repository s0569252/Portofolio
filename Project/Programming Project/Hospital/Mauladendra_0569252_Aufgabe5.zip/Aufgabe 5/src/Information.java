
public interface Information {
	String text();
}

class QMinfo implements Information{
	public String text() {
		return"Qualitaetsmanagementstelle hat die Information erhalten, dass ein X-Tage Aufenthalt f�r den Patient Y mit der Patientennummer Z stattgefunden hat.";
		}
}

class ABRinfo implements Information{
	public String text() {
		return"Abrechnungsstelle hat die Information erhalten, dass ein X-Tage Aufenthalt f�r den Patient Y mit der Patientennummer Z stattgefunden hat.";
		}
}