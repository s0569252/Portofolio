package model;

import java.util.ArrayList;
import java.util.UUID;

import Util.Settings;


/**
 * @author Imdi Melvana Mauladendra
 * @Matrikelnummer s0569252
 * @version 0.2
 */
public abstract class Kunde {
	
	/**
	 * Variable
	 */
	private String kundenId = UUID.randomUUID().toString().split("-")[4];
	private String vorName, nachName;
	private String gDatum;
	private Adresse privateAdresse;
	private Adresse businessAdresse;
	private String telefonNummer;
	private String eAdresse;
	private ArrayList<Reservierung> Reservierung;
	private static long nextKundennummer = 1;
	/**
	 * Konstruktor
	 * @param kundenId
	 * @param anrede
	 * @param vorName
	 * @param nachName
	 * @param gDatum
	 * @param telefonNummer
	 * @param eAdresse
	 * @param privateAdresse
	 * @param bezahlmethode
	 */
	public Kunde(String gDatum, String telefonNummer, String eAdresse, Adresse privateAdresse) {
	
		this.gDatum = gDatum;
		this.telefonNummer = telefonNummer;
		this.eAdresse = eAdresse;
		this.privateAdresse = privateAdresse;
		this.Reservierung = new ArrayList<Reservierung>(Settings.MAX_RESERVIERUNGEN_PRO_KUNDE);
	}
	
	public Kunde(String vorName, String nachName) {
		this.vorName=vorName;
		this.nachName=nachName;
		this.nextKundennummer = nextKundennummer++;
	}

	public void addReservierung(Reservierung reservierung) {
        Reservierung.add(reservierung);
    }

	/**
	 * get KundenID
	 * @return kundenId
	 */
	public String getKundenId() {
		return kundenId;
	}
	
	public ArrayList<Reservierung> getReservierung() {
		return Reservierung;
	}

	public void setReservierung(ArrayList<Reservierung> reservierung) {
		Reservierung = reservierung;
	}

	/**
	 * abstrakt Methode 
	 * get Name
	 * @return getName
	 */
	public abstract String getName();
	
	public String getVorName() {
		return vorName;
	}

	public void setVorName(String vorName) {
		this.vorName = vorName;
	}

	public String getNachName() {
		return nachName;
	}

	public void setNachName(String nachName) {
		this.nachName = nachName;
	}

	public static long getNextKundennummer() {
		return nextKundennummer;
	}

	public static void setNextKundennummer(long nextKundennummer) {
		Kunde.nextKundennummer = nextKundennummer;
	}

	/**
	 * get Geburtsdatum
	 * @return gDatum
	 */
	public String getgDatum() {
		return gDatum;
	}
	
	/**
	 * set Geburtsdatum
	 * @param gDatum
	 */
	public void setgDatum(String gDatum) {
		this.gDatum = gDatum;
	}
	
	/**
	 * get Telefonnummer
	 * @return telefonNummer
	 */
	public String getTelefonNummer() {
		return telefonNummer;
	}
	
	/**
	 * set Telefonnummer
	 * @param telefonNummer
	 */
	public void setTelefonNummer(String telefonNummer) {
		this.telefonNummer = telefonNummer;
	}
	
	/**
	 * get EmailAdresse
	 * @return eAdresse
	 */
	public String geteAdresse() {
		return eAdresse;
	}
	
	/**
	 * set EmailAdresse
	 * @param eAdresse
	 */
	public void seteAdresse(String eAdresse) {
		this.eAdresse = eAdresse;
	}
	
	/**
	 * set Privatadresse
	 * @param privateAdresse
	 */
	public void setPrivateAdresse(Adresse privateAdresse) {
		this.privateAdresse = privateAdresse;
	}
	
	public Adresse getPrivateAdresse() {
		return privateAdresse;
	}

	/**
	 * set Bussinessadresse
	 * @param businessAdresse
	 */
	public void setBusinessAdresse(Adresse businessAdresse) {
		this.businessAdresse = businessAdresse;
	}
	
	public abstract Anrede getAnrede();
	public abstract Bezahlmethode[] getBezahlMethode();

	
	@Override
	public String toString() {
		return " - KundenId= " + getKundenId() + " - " + gDatum + ", Privateadresse=" + privateAdresse + ", Businessadresse=" + businessAdresse
				+ " - Telefonnr.= " + telefonNummer + " - E-mail= " + eAdresse;
	}
	
	
	
}
