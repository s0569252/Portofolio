package model;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

/**
 * @author Imdi Melvana Mauladendra
 * @Matrikelnummer s0569252
 * @version 0.2
 */
public class Input {
	private BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
	
	/**
	 * lies Eingabe der Kunden
	 * @return textInput
	 * @throws Exception
	 */
	public String textInput() throws Exception {
		return input.readLine();
	}
	 
	/**
	 * lies String
	 * @param wort
	 * @return input(String)
	 */
	public String stringInput(String wort) {
		String iString = "";
		boolean sip = true;
		
		do {
			try {
			System.out.println(wort + " :");
			iString = textInput();
			sip = false;
			} catch (Exception e) {
				} if (sip) {
					System.out.print("Ungueltige Eingabe. Bitte Ihre Eingabe ueberpruefen");
				} 
		}	while(sip);
		
		return iString;
	}
	
	/**
	 * lies Nummer
	 * @param wort
	 * @param min
	 * @param max
	 * @return nummer
	 */
	public int nummerInput(String wort, int min, int max) {
		int iNummer = 0;
		boolean sip= true;
		
		do {
			try {
			System.out.println("Bitte geben Sie " + wort + " ein :");
			iNummer = Integer.parseInt(textInput());
			if (iNummer>=min && iNummer<=max) {
				sip = false;
			}
		} catch (Exception e) {
		} if (sip) {
			System.out.print("Ungueltige Eingabe. Bitte Ihre Eingabe ueberpruefen");
			} 
		}	while(sip);
		
		return iNummer;
	}
	
	/**
	 * lies Datum (im Form DD.MM.YYY)
	 * @param wort
	 * @return datum
	 */
	public String datumInput(String wort) {
		String iDatum = "";
		boolean sip=true;
		
		do {
			try {
			System.out.println(wort + " : ");
			iDatum = textInput();
			if (Pattern.matches("\\d{2}.\\d{2}.\\d{4}", iDatum)) {
				sip = false;
			}
		} catch (Exception e) {
		} if (sip) {
			System.out.println("Ungueltige Eingabe. Bitte Ihre Eingabe ueberpruefen");
			} 
		}	while(sip);
		return iDatum;
	}
	
	/**
	 * lies Telefonnummer {im Form '0123456789')
	 * @param wort
	 * @return telefon
	 */
	public String telefonInput(String wort) {
		String iTelefon = "";
		boolean sip = true;
		
		do {
			try {
			System.out.println(wort + ": ");
			iTelefon = textInput();;
			if (Pattern.matches("\\d{10}", iTelefon)) {
				sip = false;
			}
		} catch (Exception e) {
		} if (sip) {
			System.out.println("Fehler Meldung. Bitte machen Sie eine neue Eingabe");
			} 
		}	while(sip);
		return iTelefon;
	}
	
	/**
	 * lies Postleitzahl (im Form '12345') 
	 * @return plz
	 */
	
	public String plzInput(String wort) {
		String iPLZ = "";
		boolean sip = true;
		
		do {
			try {
			System.out.println(wort + " : ");
			iPLZ = textInput();
			if(Pattern.matches("\\d{5}", iPLZ)) {
				sip = false;
			}
		} catch (Exception e) {
		} if (sip) {
			System.out.println("Ungueltige Eingabe. Bitte Ihre Eingabe ueberpruefen");
			} 
		}	while(sip);
		return iPLZ;
	}
	
}
