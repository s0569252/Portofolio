package model;

import java.util.Comparator;

public class KundeComparator implements Comparator<Kunde> {

		public int compare(Kunde k1, Kunde k2) {
			int ais = 0;
			 ais = k1.getName().compareTo(k2.getName());
			 return ais;
		}


}
