package model;

import java.util.UUID;

/**
 * @author Imdi Melvana Mauladendra
 * @Matrikelnummer s0569252
 * @version 0.2
 */
public class Flugreservierung extends Reservierung{
	/**
	 *Variable 
	 */
	private String abFlughafen, zielFlughafen;
	private String flugNr = UUID.randomUUID().toString().split("-")[4];
	
	/**
	 * Konstruktor
	 * @param date
	 * @param abFlughafen
	 * @param zielFlughafen
	 */
	public Flugreservierung(String date, String abFlughafen, String zielFlughafen) {
		super(date);
		this.abFlughafen = abFlughafen;
		this.zielFlughafen = zielFlughafen;
		
	}
	
	public Flugreservierung(String date, String abFlughafen, String zielFlughafen, String flugNr) {
		super(date);
		this.abFlughafen = abFlughafen;
		this.zielFlughafen = zielFlughafen;
		this.flugNr=flugNr;
	}
	
	/**
	 * get Abflughafen
	 * @return
	 */
	public String getAbFlughafen() {
		return abFlughafen;
	}

	/**
	 * set Abflughafen
	 * @param abFlughafen
	 */
	public void setAbFlughafen(String abFlughafen) {
		this.abFlughafen = abFlughafen;
	}

	/**
	 * get Zielflughafen
	 * @return
	 */
	public String getZielFlughafen() {
		return zielFlughafen;
	}

	/**
	 * set Zielflughafen
	 * @param zielFlughafen
	 */
	public void setZielFlughafen(String zielFlughafen) {
		this.zielFlughafen = zielFlughafen;
	}

	/**
	 * get Flugnr
	 * @return
	 */
	public String getFlugNr() {
		return flugNr;
	}

	@Override
	public String toString() {
		return super.toString() + " Flugreservierung [Abflughafen= " + abFlughafen + " - Zielflughafen= " + zielFlughafen + " - Flugnummer="
				+ getFlugNr() + "]";
	}
	
}
