package model;

/**
 * @author Imdi Melvana Mauladendra
 * @Matrikelnummer s0569252
 *
 */
public class Adresse {
	/**
	 *Variable 
	 */
	private String str; 
	private String hausNr;
	private String plz;
	private String ort;
	
	/**
	 * Konstruktor
	 * @param str
	 * @param hausNr
	 * @param plz
	 * @param ort
	 */
	public Adresse(String str, String hausNr, String plz, String ort) {
		this.str = str;
		this.hausNr = hausNr;
		this.plz = plz;
		this.ort = ort;
	}
	
	/**
	 * get Strasse
	 * @return str
	 */
	public String getStr() {
		return str;
	}
	
	/**
	 * set Strasse
	 * @param str
	 */
	public void setStr(String str) {
		this.str = str;
	}
	
	/**
	 * get Hausnr
	 * @return hausNr
	 */
	public String getHausNr() {
		return hausNr;
	}
	
	/**
	 * set Hausnr
	 * @param hausNr
	 */
	public void setHausNr(String hausNr) {
		this.hausNr = hausNr;
	}
	
	/**
	 * get Postleitzahl
	 * @return plz
	 */
	public String getPlz() {
		return plz;
	}
	
	/**
	 * set Postleitzahl
	 * @param plz
	 */
	public void setPlz(String plz) {
		this.plz = plz;
	}
	
	/**
	 * get Ort
	 * @return ort
	 */
	public String getOrt() {
		return ort;
	}
	
	/**
	 * set Ort
	 * @param ort
	 */
	public void setOrt(String ort) {
		this.ort = ort;
	}
	
	@Override
	public String toString() {
		return str + " " + hausNr + " " + plz + " " + ort;
	}
	
	
	
}
