package model;

/**
 * @author Imdi Melvana Mauladendra
 * @Matrikelnummer s0569252
 *
 */
public class Bezahlmethode {
	
	/**
	 *Variable 
	 */
	private String bezeichnung;
	private String kBeschreibung;
	
	/**
	 * Konstruktor
	 * @param bezeichnung
	 * @param kBeschreibung
	 */
	Bezahlmethode(String bezeichnung, String kBeschreibung){
		this.bezeichnung=bezeichnung;
		this.kBeschreibung=kBeschreibung;
	}

	public String getBezeichnung() {
		return bezeichnung;
	}

	public void setBezeichnung(String bezeichnung) {
		this.bezeichnung = bezeichnung;
	}

	public String getkBeschreibung() {
		return kBeschreibung;
	}

	public void setkBeschreibung(String kBeschreibung) {
		this.kBeschreibung = kBeschreibung;
	}

	@Override
	public String toString() {
		return "Bezahlmethode: "+ bezeichnung + ", " + kBeschreibung;
	}
	
}
