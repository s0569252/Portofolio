package model;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * @author Imdi Melvana Mauladendra
 * @Matrikelnummer s0569252
 * @version 0.2
 */
public class Reiseagentur {
	
	/**
	 * Variable
	 */
	private String name;
	private String idNr;
	private Adresse ad;
	private Kunde[] kunde;
	
	/**
	 * Konstruktor 
	 * @param name
	 * @param idNr
	 * @param ad
	 */
	public Reiseagentur(String name, String idNr, Adresse ad) {
		this.name = name;
		this.idNr = idNr;
		this.ad=ad;
		
	}
	
	/**
	 * Kunden werden addiert
	 * @param kunde
	 * @return
	 */
	public boolean addKunde(Kunde kunde) {
		for (int i = 0; i < this.kunde.length; i++) {
			if (this.kunde[i] == null) {
				this.kunde[i] = kunde;
				return true;
			}
		}

		return false;
	}
	
	

	/**
	 * get Name
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * set Name
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * get IdNr
	 * @return idNr
	 */
	public String getIdNr() {
		return idNr;
	}

	/**
	 * set IdNr
	 * @param idNr
	 */
	public void setIdNr(String idNr) {
		this.idNr = idNr;
	}

	/**
	 * get Ad
	 * @return
	 */
	public Adresse getAd() {
		return ad;
	}

	/**
	 * set Ad
	 * @param ad
	 */
	public void setAd(Adresse ad) {
		this.ad = ad;
	}

	/**
	 * get Kunde
	 * @return kunde
	 */
	public Kunde[] getKunde() {
		return kunde;
	}

	/**
	 * set Kunde
	 * @param kunde
	 */
	public void setKunde(Kunde[] kunde) {
		this.kunde = kunde;
	}

	@Override
	public String toString() {
		return  name + " - " + idNr + " - " + ad;
	}

}
	
