package model;

/**
 * @author Imdi Melvana Mauladendra
 * @Matrikelnummer s0569252
 * @version 0.2
 */
public class Geschaeftskunde extends Kunde{
	/**
	 * Variable
	 */
	private String firmaName;
	private Anrede anrede;
	private Bezahlmethode bezahlmethode;
	
	/**
	 * Konstruktor
	 * @param anrede
	 * @param vorName
	 * @param name
	 * @param firmaName
	 * @param gDatum
	 * @param telefonNummer
	 * @param eAdresse
	 * @param privateAdresse
	 */
	public Geschaeftskunde(Anrede anrede, String vorName, String nachName, String firmaName, String gDatum, String telefonNummer, String eAdresse, Adresse privateAdresse) {
		super(gDatum, telefonNummer, eAdresse, privateAdresse);
		this.anrede=anrede;
		this.firmaName = firmaName;
		this.bezahlmethode = new Bezahlmethode("Rechnung", "E-Mail");
	}
	
	public Geschaeftskunde(Anrede anrede, String vorname, String nachname, String firmenname) {
		super(vorname, nachname);
		this.firmaName = firmenname;
		this.bezahlmethode = new Bezahlmethode("Rechnung", "E-Mail");
	}
	
	/**
	 *Methode, die Bezahlmethode addiert
	 */
	public Bezahlmethode[] getBezahlMethode() {
		
		return new Bezahlmethode[] { this.bezahlmethode };
	}
	public void rechnungMitDerPostSchicken() {
		this.bezahlmethode.setkBeschreibung("Post");
	}

	public void rechnungPerEmailSchicken() {
		this.bezahlmethode.setkBeschreibung("E-Mail");
	}
	/**
	 * get Firmenname
	 * @return Firmenname
	 */
	public String getFirmaName() {
		return firmaName;
	}

	/**
	 * set Firmenname
	 * @param firmaName
	 */
	public void setFirmaName(String firmaName) {
		this.firmaName = firmaName;
	}

	/**
	 *get Nachname
	 */
	public String getName() {
		return super.getVorName() + " " + super.getNachName() + " - " + this.firmaName;
	}
	
	/**
	 *get Anrede
	 */
	public Anrede getAnrede() {
		return anrede;
	}

	/**
	 * set Anrede
	 * @param anrede
	 */
	public void setAnrede(Anrede anrede) {
		this.anrede = anrede;
	}

}

