package model;

import java.util.Scanner;
import java.util.UUID;

import Util.Init;

/**
 * @author Imdi Melvana Mauladendra
 * @Matrikelnummer s0569252
 * @version 0.2
 */
public class Starter {
	private static Scanner scan = new Scanner(System.in);
	static Input input = new Input();
	static Adresse adresseMhr = new Adresse("Hauptstra�e","5a","10559","Berlin");
	static Reiseagentur mhr = new Reiseagentur("Magic Holidays Reiseagentur", "DE812524001", adresseMhr);

	/**
	 * Mainmethode
	 * @param args
	 */
	public static void main (String args[]){	
	
	System.out.println(mhr+"\n");
	
	while (true) {
		auswahlMenu();
		int eingabe = eingabeMenu();
		menuEingabe(eingabe);
		System.out.println("\n==================================================");
	}
	}
	
	/**
	 * Metode zum Aufrufen des gewuenschten Menues
	 * @return eingabe
	 */
	private static int eingabeMenu() {
		System.out.print("Bitte, geben Sie die Nummer des Menueeintrages ein:\t");
		int eingabe = scan.nextInt();
		return eingabe;
	}
	
	/**
	 * menueingabe
	 * @param eingabe
	 */
	private static void menuEingabe(int eingabe) {
		switch (eingabe) {
		case 1:
			pkundeAnlegen();
			break;
		case 2:
			gkundeAnlegen();
			break;
		case 3:
			reservierungAnlegen();
			break;
		case 4:
			auswahlKnr();
			break;
		case 5:
			auswahlKname();
			break;
		case 6:
			resAnz();
			break;
		
		default: {
			System.out.println("Ungueltige Eingabe. Bitte Ihre Eingabe ueberpruefen");
			auswahlMenu();
			}
		}
	}
	
	
	/**
	 * lies Kundenadresse
	 * @return adresse
	 */
	public static Adresse kundeAdresse() {
		String strasse = input.stringInput("Strasse");
		String hNummer= input.stringInput("Hausnummer");
		String plz = input.plzInput("Postleitzahl");
		String ort = input.stringInput("Ort");
		Adresse adresse = new Adresse(strasse,hNummer,plz,ort);

		return adresse;
	}
	
	/**
	 * lies Bezahlmethode
	 * @return bMethode
	 */
	public static Bezahlmethode addBmethode() {
		String bez = input.stringInput("Bezahlmethode");
		String kBesr = input.stringInput("kurz Bezeichnung");
		Bezahlmethode bMethode = new Bezahlmethode(bez, kBesr);

		return bMethode;
	}
	
	/**
	 * lies Hotelreservierung
	 * @return hr
	 */
	public static Hotelreservierung addHres() {
		String date = input.datumInput("Datum");
		int summe = input.nummerInput("die Anzahl der Personen", 1, 1000);
		String hName = input.stringInput("Hotelname");
		int rDauer = input.nummerInput("Reisedauer", 1, 1000);
		
		Hotelreservierung hr = new Hotelreservierung(date, summe, hName,rDauer);

		return hr;
	}
	
	/**
	 * lies Flugreservierung
	 * @return fr
	 */
	public static Flugreservierung addFres() {
		String date = input.datumInput("Datum");
		String abFhafen = input.stringInput("Abflughafen");
		String zielFhafen = input.stringInput("Zielflughafen");
		Flugreservierung fr = new Flugreservierung(date, abFhafen, zielFhafen);

		return fr;
	}

	/**
	 * Methode Privatkunden anlegen 
	 */
	public static void pkundeAnlegen() {
		String anrede = input.stringInput("Anrede");
		String vorName = input.stringInput("Vorname");
		String nachName = input.stringInput("Nachname");
		String gDatum = input.datumInput("Geburtsdatum");
		String telefonNummer = input.telefonInput("Telefon");
		String eMail = input.stringInput("E-Mail");
		Adresse adresse = kundeAdresse();
		Bezahlmethode bMethode = addBmethode();
		
		Kunde pKunde = new Privatekunde(Anrede.valueOf(anrede.toUpperCase()), vorName, nachName, gDatum, telefonNummer, eMail, adresse);
		mhr.addKunde(pKunde);
		System.out.println(pKunde);
		System.out.println(bMethode);
	}
	
	
	/**
	 * Methode Geschaeftkunden anlegen 
	 */
	public static void gkundeAnlegen() {
		String anrede = input.stringInput("Anrede");
		String vorName = input.stringInput("Vorname");
		String firmaName = input.stringInput("Firmaname");
		String nachName = input.stringInput("Nachname");
		String gDatum = input.datumInput("Geburtsdatum");
		String telefonNummer = input.telefonInput("Telefon");
		String eMail = input.stringInput("E-Mail");	
		Adresse adresse = kundeAdresse();
		Bezahlmethode bMethode = addBmethode();
		
		Geschaeftskunde gKunde = new Geschaeftskunde(Anrede.valueOf(anrede.toUpperCase()), vorName, nachName, firmaName, gDatum, telefonNummer, eMail, adresse);
		mhr.addKunde(gKunde);
		System.out.println(gKunde);
		System.out.println(bMethode);
	}
	
	/**
	 * Reservierung anlegen
	 */
	private static void reservierungAnlegen() {
		
		System.out.println("Bitte Bitte w�hlen Sie die Art der Reservierung:\t");
		System.out.println("(1) Hotelreservierung \t (2) Flugreservierung");
		scan.nextLine();
		String rTyp = scan.nextLine();
		
		if (rTyp.equals("1")) {

			System.out.println("Bitte geben Sie die KundenID ein:\t");
			String kId = scan.nextLine();
			for (int i = 0; i < mhr.getKunde().length; i++) {
				if (mhr.getKunde()[i] != null) {
					if (kId.equalsIgnoreCase(mhr.getKunde()[i].getKundenId())) {	
						mhr.getKunde()[i].addReservierung(addHres());
						//break;
							
					}
				} else if (i == mhr.getKunde().length - 1) {
					System.out.println("Angabe nicht gefunden!");
				}
			}

		}
		if (rTyp.equals("2")) {

			System.out.println("Bitte geben Sie die KundenID ein:\t");
			
			String kId = scan.nextLine();
			for (int i = 0; i < mhr.getKunde().length; i++) {
				if (mhr.getKunde()[i] != null) {
					if (kId.equalsIgnoreCase(mhr.getKunde()[i].getKundenId())) {	
						mhr.getKunde()[i].addReservierung(addFres());
						//break;
							
					}
				} else if (i == mhr.getKunde().length - 1) {
					System.out.println("Angabe nicht gefunden!");
				}

		}

		if (!"1".equals(rTyp) && !"2".equals(rTyp)) {
			System.out.print("fehler \n\n");

		}
		
		}
	}
	
	/**
	 * Kunden anzeigen. Auswahl durch Kundennummer 
	 */
	private static void auswahlKnr() {
		String kNr;
		System.out.println("Bitte geben Sie die Kundennnummer ein: ");
		scan.nextLine();
		kNr = scan.nextLine();
		for(int i=0; i<mhr.getKunde().length; i++) {	
			if(mhr.getKunde()[i]!=null) {
				if(kNr.equalsIgnoreCase(mhr.getKunde()[i].getKundenId())) {
					System.out.println("");
					System.out.println(mhr.getKunde()[i].toString());
					System.out.println("");
					for(int j=0; j< mhr.getKunde()[i].getReservierung().size(); j++) {
						if(mhr.getKunde()[i].getReservierung() != null) {
								System.out.println(mhr.getKunde()[i].getReservierung().toString());	
								//break;
							
						}			
					}		
				}
				//break;
			}
			else  if(i == mhr.getKunde().length-1) {
				System.out.println("");
				System.out.println("Angabe nicht gefunden!!");
				System.out.println("");
			}
		}
	}
	
	/**
	 * Kunden anzeigen. Auswahl durch Kundenname 
	 */
	private static void auswahlKname() {
		String kNachname;
		scan.nextLine();
		System.out.println("Bitte geben Sie die Nachname ein: ");
		kNachname = scan.nextLine();
		for(int i=0; i<mhr.getKunde().length; i++) {	
			if(mhr.getKunde()[i]!=null) {
				if(kNachname.equalsIgnoreCase(mhr.getKunde()[i].getName())) {
					System.out.println("");
					System.out.println(mhr.getKunde()[i].toString());
					System.out.println("");
					for(int j=0; j< mhr.getKunde()[i].getReservierung().size(); j++) {
						if(mhr.getKunde()[i].getReservierung() != null) {
								System.out.println(mhr.getKunde()[i].getReservierung().toString());	
								//break;
							
						}			
					}
				}
				//break;
			}
				else if(i == mhr.getKunde().length-1) 
				{
					System.out.println("");
					System.out.println("Angabe nicht gefunden!!");
					System.out.println("");
				}
				
			
			}
	}
	
	/**
	 * Reservierung anzeigen. Auswahl durch Reservierungsnummer 
	 */
	private static void resAnz() {
		
		
		
	}
	
	/**
	 * Auswahlmenu 
	 */
	private static void auswahlMenu() {
		String menuList[] = { "(01)\tPrivatkunde anlegen", "(02)\tGesch�ftskunde anlegen",
				"(03)\tReservierung anlegen und Kundennummer zuordnen", "(04)\tKunde mit Reservierungen anzeigen (Auswahl durch Kundennummer)",
				"(05)\tKunde mit Reservierungen anzeigen (Auswahl durch Name)", "(06)\tReservierung anzeigen (Auswahl durch Reservierungsnummer)",
				 "(07)\tAlle Kunden sortiert nach aufsteigendem Vornamen, aufsteigendem Nachnamen zeigen",  
				 "(08)\t�bersicht der Bezahlmethoden (Bezeichnungen) sortiert nach absteigender H�ufigkeit zeigen",
				 "(09)\tAlle Reservierungen eines Datums sortiert nach Nachnamen der Kunden zeigen",
				 "(10)\tBeenden"};

		for (int i = 0; i < menuList.length; i++) {
			System.out.println(menuList[i]);
		}
	}

}
