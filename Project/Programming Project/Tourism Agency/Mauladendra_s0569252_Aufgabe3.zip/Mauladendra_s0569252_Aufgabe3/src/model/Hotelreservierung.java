package model;


/**
 * @author Imdi Melvana Mauladendra
 * @Matrikelnummer s0569252
 * @version 0.2
 */
public class Hotelreservierung extends Reservierung{
	/**
	 *Variable 
	 */
	private String hotelName;
	private double reiseDauer;
	
	/**
	 * Konstruktor
	 * @param date
	 * @param summe
	 * @param hotelName
	 * @param reiseDauer
	 */
	public Hotelreservierung(String date, int summe, String hotelName, double reiseDauer) {
		super(date, summe);
		this.hotelName = hotelName;
		this.reiseDauer = reiseDauer;
		
	}
	
	public Hotelreservierung(String date, String hotelName, double reiseDauer) {
		super(date);
		this.hotelName = hotelName;
		this.reiseDauer = reiseDauer;
		
	}

	/**
	 * get Hotelname
	 * @return
	 */
	public String getHotelName() {
		return hotelName;
	}


	/**
	 * set Hotelname
	 * @param hotelName
	 */
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}


	/**
	 * get Reisedauer
	 * @return
	 */
	public double getReiseDauer() {
		return reiseDauer;
	}


	/**
	 * set Reisedauer
	 * @param reiseDauer
	 */
	public void setReiseDauer(double reiseDauer) {
		this.reiseDauer = reiseDauer;
	}


	@Override
	public String toString() {
		return super.toString() + " Hotelreservierung [ " + hotelName + " - Reisedauer= " + reiseDauer + "]";
	}
	
	
	
}
