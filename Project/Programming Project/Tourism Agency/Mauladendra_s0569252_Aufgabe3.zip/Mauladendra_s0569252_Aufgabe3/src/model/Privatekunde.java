package model;

/**
 * @author Imdi Melvana Mauladendra
 * @Matrikelnummer s0569252
 * @version 0.2
 */
public class Privatekunde extends Kunde {
	/**
	 * Variable
	 */
	private Anrede anrede;
	private Bezahlmethode Bezahlmethoden[];
	
	/**
	 * Konstruktor
	 * @param anrede
	 * @param vorName
	 * @param name
	 * @param gDatum
	 * @param telefonNummer
	 * @param eAdresse
	 * @param privateAdresse
	 */
	public Privatekunde(Anrede anrede, String vorName, String nachName, String gDatum, String telefonNummer, String eAdresse,
			Adresse privateAdresse) {
		super( gDatum, telefonNummer, eAdresse, privateAdresse);
		this.anrede=anrede;
		Bezahlmethoden= new Bezahlmethode[3];
	}
	
	public Privatekunde(Anrede anrede, String vorName, String nachName) {
		super(vorName, nachName);
		this.anrede=anrede;
		Bezahlmethoden= new Bezahlmethode[3];
	}
	/**
	 *Methode, die Bezahlmethode addiert
	 */
	public Bezahlmethode[] getBezahlMethode() {
		return this.Bezahlmethoden;
	}
	
	/**
	 * get Nachname
	 */
	public String getName() {
		return super.getVorName() + " " + super.getNachName();
	}
	
	/**
	 *get Anrede
	 */
	public Anrede getAnrede() {
		return anrede;
	}


	/**
	 * set Anrede
	 * @param anrede
	 */
	public void setAnrede(Anrede anrede) {
		this.anrede = anrede;
	}
	
}


