package model;

public enum Anrede {
	HERR, FRAU, ANDERE
}
