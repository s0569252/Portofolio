package model;

import java.util.UUID;

/**
 * @author Imdi Melvana Mauladendra
 * @Matrikelnummer s0569252
 * @version 0.2
 */
public abstract class Reservierung {
	/**
	 * Variable
	 */
	private long rId;
	private String date;
	private int summe;
	private static long nextReservierungsnummer = 1;
	/**
	 * Konstruktor
	 * @param date
	 * @param summe
	 */
	public Reservierung(String date, int summe) {
		super();
		this.date = date;
		this.summe = summe;
	}
	public Reservierung(String date) {
		this.date = date;
		this.nextReservierungsnummer = nextReservierungsnummer++;

	}
	/**
	 * get RID
	 * @return rId
	 */
	public long getrId() {
		return rId;
	}

	/**
	 * get Datum
	 * @return date
	 */
	public String getDate() {
		return date;
	}
	/**
	 * set Datum
	 * @param date
	 */
	public void setDate(String date) {
		this.date = date;
	}

	/**
	 * get Anzahl der Personen
	 * @return summe
	 */
	public int getSumme() {
		return summe;
	}

	/**
	 * set Anzahl der Personen
	 * @param summe
	 */
	public void setSumme(int summe) {
		this.summe = summe;
	}
	
	public static long getNextReservierungsnummer() {
		return nextReservierungsnummer;
	}
	public static void setNextReservierungsnummer(long nextReservierungsnummer) {
		Reservierung.nextReservierungsnummer = nextReservierungsnummer;
	}
	@Override
	public String toString() {
		return "Reservierung [Reservierungs-ID= " + getrId() + " - Datum= " + date + " - Summe= " + summe + "]";
	}
	
}
