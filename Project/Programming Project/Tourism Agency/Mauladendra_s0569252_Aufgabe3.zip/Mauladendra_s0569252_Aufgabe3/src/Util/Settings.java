package Util;

/**
 * @author Mohammed AbuJarour (mohammed.abujarour@htw-berlin.de)
 *
 */
public class Settings {

	public static final int MAX_KUNDEN = 100;
	public static final int MAX_RESERVIERUNGEN_PRO_KUNDE = 100;
	public static final int MAX_BEZAHLMETHODEN_PRO_KUNDE = 3;

}
