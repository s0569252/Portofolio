package Util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;
import java.util.Random;

import model.Flugreservierung;
import model.Hotelreservierung;
import model.Kunde;
import model.Privatekunde;
import model.Geschaeftskunde;
import model.Reiseagentur;
import model.Reservierung;
import model.Anrede;



/**
 * 
 *
 */
public class Init {

	private static String companies[] = { "Essence", "Daydream Systems", "Icecap Foods", "Wooductions", "Elitelligence",
			"Vinedustries", "Blizzart", "Mountainway", "Crowcoms", "Cloudmaster" };

	private static String hotels[] = { "Snowy Lake Hotel", "King's Flower Hotel", "Winter Cove Hotel",
			"Ebony Landscape Hotel & Spa", "Illustrious Vertex Hotel", "Southern Veil Hotel", "Antique Hotel",
			"Recreation Hotel", "Mountain Hotel & Spa", "Majestic Hotel" };

	private static String flughaefen[] = { "Altenbach", "Bischofstein", "Antden", "Grimselt", "Saumur", "Maitoise",
			"Neunsloh", "Oderhofen", "Tullaroom", "Athnard", "Groveen", "Culemstein", "Spreitendrisio", "Reistadt" };

	public static void initReiseagentur(Reiseagentur agentur) {
		Kunde kunden[] = loadKunden();
		for (Kunde kunde : kunden) {
			agentur.addKunde(kunde);
			makeSomeReservations(kunde);
		}

	}

	private static void makeSomeReservations(Kunde kunde) {

		LocalDate startDate = LocalDate.of(2019, 1, 1);
		Random rand = new Random();
		for (int i = 0; i < rand.nextInt(10); i++) {
			LocalDate from = startDate.plusDays(rand.nextInt(30));
			String datum = from
					.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM).localizedBy(Locale.GERMAN));
			Reservierung reservierung;
			if (rand.nextBoolean())
				reservierung = new Hotelreservierung(hotels[i], datum, rand.nextInt(10) + 1);
			else
				reservierung = new Flugreservierung(datum, flughaefen[i], flughaefen[flughaefen.length - i - 1],
						"FL-" + (1000 + rand.nextInt(8999)));
			reservierung.setSumme(rand.nextInt(2000));
			kunde.addReservierung(reservierung);
		}
	}

	private static Kunde[] loadKunden() {

		Random rand = new Random();
		
		Kunde clara = new Privatekunde(Anrede.FRAU, "Clara", "Duete");
		Kunde erik = new Privatekunde(Anrede.HERR, "Erik", "Trohn");
		Kunde michael = new Privatekunde(Anrede.HERR, "Michael", "Turner");
		Kunde emma = new Privatekunde(Anrede.FRAU, "Emma", "Watson");
		Kunde erika = new Privatekunde(Anrede.FRAU, "Erika", "Bella");

		Kunde hart = new Geschaeftskunde(Anrede.HERR, "Hart", "Klein",
				companies[rand.nextInt(companies.length)]);
		Kunde veranda = new Geschaeftskunde(Anrede.FRAU, "Veranda", "Hofmann", companies[rand.nextInt(companies.length)]);
		Kunde jan = new Geschaeftskunde(Anrede.HERR, "Jan", "Hawk", companies[rand.nextInt(companies.length)]);
		Kunde geraldin = new Geschaeftskunde(Anrede.HERR, "Geraldin", "Fletcher",
				companies[rand.nextInt(companies.length)]);
		Kunde maria = new Geschaeftskunde(Anrede.FRAU, "Maria", "Abiati",
				companies[rand.nextInt(companies.length)]);
		Kunde sarah = new Geschaeftskunde(Anrede.FRAU, "Sarah", "Young", companies[rand.nextInt(companies.length)]);
		Kunde sabine = new Geschaeftskunde(Anrede.FRAU, "Sabine", "Klar", companies[rand.nextInt(companies.length)]);

		return new Kunde[] { clara, erik, michael, emma, erika, hart, veranda, jan, geraldin, sarah,
				sabine };

	}

}
