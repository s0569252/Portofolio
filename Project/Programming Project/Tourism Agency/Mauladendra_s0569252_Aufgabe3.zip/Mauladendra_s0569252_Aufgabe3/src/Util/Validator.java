package Util;

/**
 * @author Mohammed AbuJarour (mohammed.abujarour@htw-berlin.de)
 *
 */
public class Validator {

	public static boolean isValidReservierungsnummer(long reservierungsnummer) {

		return (reservierungsnummer > 0);

	}
}
