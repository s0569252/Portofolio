import java.io.*;
import java.util.*;


public class MainPrime {
	
	 /**
	  * Main Methode
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		    	PrintStream out = new PrintStream(new FileOutputStream(System.getProperty("user.dir")+"/va-ue02-[Imdi Melvana Mauladendra]-console.txt"));
		    	System.setOut(out);
		    	PrintWriter o= new PrintWriter("primes.txt");
		    	long startTime = System.currentTimeMillis();
		    	int x=8;
		    	int min = 0;
				int max =100000;
				List<Integer> primeList = Collections.synchronizedList(new ArrayList<Integer>());
				ArrayList<Thread>at = new ArrayList<Thread>();
				ArrayList<MyRunnable>mr = new ArrayList<MyRunnable>();
				System.out.println("Start, Hauptread hat die ID: "+Thread.currentThread().getId());
				System.out.println("Zahlenbereich: "+" "+min+" bis "+max);
				System.out.println("Anzahl paralleler Threads: "+ x);
				System.out.println("-------------------");

				MyRunnable pr=new MyRunnable(primeList,1,12500);
				MyRunnable pr2=new MyRunnable(primeList,12501,25000);
				MyRunnable pr3=new MyRunnable(primeList,25001,37500);
				MyRunnable pr4=new MyRunnable(primeList,37501,50000);
				MyRunnable pr5=new MyRunnable(primeList,50001,62500);
				MyRunnable pr6=new MyRunnable(primeList,62501,75000);
				MyRunnable pr7=new MyRunnable(primeList,75001,87500);
				MyRunnable pr8=new MyRunnable(primeList,87501,100000);
				
				Thread t1 = new Thread(pr);
				Thread t2 = new Thread(pr2);
				Thread t3 = new Thread(pr3);
				Thread t4 = new Thread(pr4);
				Thread t5 = new Thread(pr5);
				Thread t6 = new Thread(pr6);
				Thread t7 = new Thread(pr7);
				Thread t8 = new Thread(pr8);
				t1.start();
				t2.start();
				t3.start();
				t4.start();
				t5.start();
				t6.start();
				t7.start();
				t8.start();
				
				t1.join();
				t2.join();
				t3.join();
				t4.join();
				t5.join();
				t6.join();
				t7.join();
				t8.join();
				
					
					System.out.println("Thread-ID: "+ t1.getId()+" "+"-"+" Starte den Nebenthread, ID ist");
					System.out.println("Thread-ID: "+ t1.getId()+" "+"-"+" Zahlenbereich von "+"1"+" bis "+ "12500");
					System.out.println("Thread " + t1.getId() + "  Prime count: " + pr.count);
					o.println("-"+" Zahlenbereich von "+"1"+" bis "+ "12500");
					o.println("  Prime count: " + pr.count);
					at.add(t1);
					mr.add(pr);


					System.out.println("Thread-ID: "+ t2.getId()+" "+"-"+" Starte den Nebenthread, ID ist");
					System.out.println("Thread-ID: "+ t2.getId()+" "+"-"+" Zahlenbereich von "+"12501"+" bis "+ "25000");
					System.out.println("Thread " + t2.getId() + "  Prime count: " + pr2.count);
					o.println("-"+" Zahlenbereich von "+"12501"+" bis "+ "25000");
					o.println("  Prime count: " + pr2.count);
					at.add(t2);
					mr.add(pr2);
					
					System.out.println("Thread-ID: "+ t3.getId()+" "+"-"+" Starte den Nebenthread, ID ist");
					System.out.println("Thread-ID: "+ t3.getId()+" "+"-"+" Zahlenbereich von "+"25001"+" bis "+ "37500");
					System.out.println("Thread " + t3.getId() + "  Prime count: " + pr3.count);
					o.println("-"+" Zahlenbereich von "+"25001"+" bis "+ "37500");
					o.println("  Prime count: " + pr3.count);
					at.add(t3);
					mr.add(pr3);
					
					System.out.println("Thread-ID: "+ t4.getId()+" "+"-"+" Starte den Nebenthread, ID ist");
					System.out.println("Thread-ID: "+ t4.getId()+" "+"-"+" Zahlenbereich von "+"37501"+" bis "+ "50000");
					System.out.println("Thread " + t4.getId() + "  Prime count: " + pr4.count);
					o.println("-"+" Zahlenbereich von "+"37501"+" bis "+ "50000");
					o.println("  Prime count: " + pr4.count);
					at.add(t4);
					mr.add(pr4);
					
					System.out.println("Thread-ID: "+ t5.getId()+" "+"-"+" Starte den Nebenthread, ID ist");
					System.out.println("Thread-ID: "+ t5.getId()+" "+"-"+" Zahlenbereich von "+"50001"+" bis "+ "62500");
					System.out.println("Thread " + t5.getId() + "  Prime count: " + pr5.count);
					o.println("-"+" Zahlenbereich von "+"50001"+" bis "+ "62500");
					o.println("  Prime count: " + pr5.count);
					at.add(t5);
					mr.add(pr5);
					
					System.out.println("Thread-ID: "+ t6.getId()+" "+"-"+" Starte den Nebenthread, ID ist");
					System.out.println("Thread-ID: "+ t6.getId()+" "+"-"+" Zahlenbereich von "+"62501"+" bis "+ "75000");
					System.out.println("Thread " + t6.getId() + "  Prime count: " + pr6.count);
					o.println("-"+" Zahlenbereich von "+"62501"+" bis "+ "75000");
					o.println("  Prime count: " + pr6.count);
					at.add(t6);
					mr.add(pr6);

					System.out.println("Thread-ID: "+ t7.getId()+" "+"-"+" Starte den Nebenthread, ID ist");
					System.out.println("Thread-ID: "+ t7.getId()+" "+"-"+" Zahlenbereich von "+"75001"+" bis "+ "87500");
					System.out.println("Thread " + t7.getId() + "  Prime count: " + pr7.count);
					o.println("-"+" Zahlenbereich von "+"75001"+" bis "+ "87500");
					o.println("  Prime count: " + pr7.count);
					at.add(t7);
					mr.add(pr7);
					
					System.out.println("Thread-ID: "+ t8.getId()+" "+"-"+" Starte den Nebenthread, ID ist");
					System.out.println("Thread-ID: "+ t8.getId()+" "+"-"+" Zahlenbereich von "+"87501"+" bis "+ "100000");
					System.out.println("Thread " + t8.getId() + "  Prime count: " + pr8.count);
					o.println("-"+" Zahlenbereich von "+"87501"+" bis "+ "100000");
					o.println("  Prime count: " + pr8.count);
					at.add(t8);
					mr.add(pr8);
					
				int sum=pr.count+pr2.count+pr3.count+pr4.count+pr5.count+pr6.count+pr7.count+pr8.count;
				System.out.println("-------------------");
				System.out.println( "------- Ende vom Main-Thread ----------------");
				System.out.println("Thread-ID: "+t1.currentThread().getId()+"- Gefundene Primzahlen: " + sum); // Display Thread count
				o.println("- Gesamtzahl gefundener Primzahlen: " + sum); // Display Thread count
				long endTime = new Date().getTime();
				long timeElapsed = endTime - startTime;
				System.out.printf("Vergangene Zeit in �s: %d\n", timeElapsed);
				o.flush();
				o.close();
		    }
}
