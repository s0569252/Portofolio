import java.util.ArrayList;
import java.util.List;
import java.io.*;
import java.math.BigInteger;

/**
 * @author Imdi Melvana Mauladendra
 *	Matrkelnummer:s0569252
 */

public class MyRunnable extends Thread{
	public int count = 0;
    static List<Integer> primeList = new ArrayList<>();
    int start;
	int end;
		
	    public  MyRunnable(List<Integer> primeList, int start, int end) {
			super();
			this.primeList = primeList;
			this.start = start;
			this.end = end;
		}
	    
	    /**
	     * run Methode
	     */
	    public void run() {
	    	int ky=start;
	    	while(ky<=end) {
	    		if(isPrime(ky)) {
	    			count++;
	    			addPrime(ky);
	    		}
	    		ky++;
	    	}
	    	
	    }
	    
		
		/**
		 * Synchronized Methode isPrime
		 * @param n
		 * @return
		 */
		public boolean isPrime(int n) {
			if (n == 2 || n == 3 || n == 5) return true;
			if (n <= 1 || (n&1) == 0) return false;

			for (int i = 3; i*i <= n; i += 2)
			    if (n % i == 0) return false;

	    		return true;
	    
	    }
		
		 /**
		  * Synchronized Methode addPrime
		 * @param n
		 */
		public synchronized static void addPrime(int n) {
				primeList.add(n);
		 }
}
