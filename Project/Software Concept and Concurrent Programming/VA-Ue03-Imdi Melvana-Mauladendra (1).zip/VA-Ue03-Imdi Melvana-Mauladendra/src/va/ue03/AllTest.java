package va.ue03;

import static org.junit.jupiter.api.Assertions.*;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AllTest {
	
	Ue03DirectoryClient uedc;
	
	@BeforeEach
	void setUp() throws Exception 
	{
		uedc = new Ue03DirectoryClient();
	}

	@AfterEach
	void tearDown() throws Exception 
	{
		
	}

	/**
	 * Test der Query-Funktion auf mitgeschickte SID
	 */
	@Test
	void testQuery() {
		
		// In der sp�teren Implementation w�rden wir bei der Query-Anfrage alle registrierten 
		// Teilnehmer erwarten. 
		// In diesem Fall erwarten wir ein JSONString mit der gesendeten Anfrage
		
		String echoAnswer 	= uedc.query("bla");
		JSONObject jo 		= (JSONObject)JSONValue.parse(echoAnswer);
		String echoSID 		= (String)jo.get("SID");
		
		assertEquals("bla", echoSID);			// Ergebnis-Vergleich f�r den TEST
	}
	
	@Test
	void testQuery2() {
		
		String echoAnswer 	= uedc.register("not registerd");
		JSONObject jo 		= (JSONObject)JSONValue.parse(echoAnswer);
		String echoStatus 		= (String)jo.get("status");
		
		assertEquals("registerd", echoStatus); // Ergebnis-Vergleich f�r den TEST
	}
	
	@Test
	void testQuery3() {
		
		String echoAnswer 	= uedc.delete("bla");
		JSONObject jo 		= (JSONObject)JSONValue.parse(echoAnswer);
		String echoSID 		= (String)jo.get("status");
		
		assertEquals("bla", echoSID); // Ergebnis-Vergleich f�r den TEST
	}
	
	/**
	 * Test der query-function auf leere SID
	 */
	@Test
	void testQueryEmptySID()
	{
		String echoAnswer = uedc.query(null); 
		JSONObject jo = (JSONObject)JSONValue.parse(echoAnswer);
		String echoSID = (String)jo.get("SID");
		
		assertEquals(null, echoSID);			// Ergebnis-Vergleich f�r den TEST
	}
	
	/**
	 * Test ReturnNumber
	 */
	@Test
	void testReturnNumber()
	{
		int returnedNumber = uedc.returnNumber(123);
		assertEquals(123, returnedNumber);
			
	}
	
	 
}
