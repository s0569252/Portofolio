package va.ue03;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

public class EchoServer extends Thread {

    private DatagramSocket socket;
    private boolean running;
    private byte[] buf = new byte[1024]; //Buffergr��e von 256 kb
    
    /**
     * Konstruktor, bindet den Echo-Server an Port 11111
     * 
     * @throws SocketException
     */
    public EchoServer() throws SocketException 
    {
    	socket = new DatagramSocket(11111);
    }
    
    
    /**
     * Main mit Instanziierung des Echo-Servers und starten des Threads
     * 
     * @param args
     */
    public static void main(String[] args) {
    	try {
    		// Echo-Server l�uft in einem eigenen Thread
			EchoServer es = new EchoServer();
			es.run();
		} catch (SocketException e) 
    	{
			e.printStackTrace();
		}
	}
    
    /**
     *  Thread-Run
     *  
     *  Der Echo-Server l�uft in einer Endlosschleife, bis die �bertragende Nachricht "end" enth�lt.
     */
    public void run() 
    {
    	System.out.println("Start Server at 127.0.0.1");
        running = true;
        while (running) {
        	buf = new byte[1024];
            DatagramPacket packet = new DatagramPacket(buf, buf.length);
            try 
            {
				socket.receive(packet);
			} 
            catch (IOException e) 
            {
				e.printStackTrace();
			}
            
            InetAddress address = packet.getAddress();
            int port = packet.getPort();
            
            packet = new DatagramPacket(buf, buf.length, address, port);
            
            // Empfangene Nachricht besteht aus der Data-Load vom empfangenen Packet
            String received = new String(packet.getData(), 0, packet.getLength()); 
            
            // Begrenze den empfangenen String auf die letzte geschweifte Klammer (Buffer ist l�nger als emfange Nachricht)
            received = received.substring(0,received.lastIndexOf("}")+1 );
            
            // Wenn "end" empfangen wird dann beende die Schleife und damit den Thread
            if (received.equals("end")) 
            {
            	running = false;
            	continue;
            } 
            else
            {
            	// Empfangener String wird �ber die breakMsg-Funktion manipuliert und zur�ckgeschickt
            	String returnMsg  = breakMsg(received);
            	packet.setData(returnMsg.getBytes());
            	try 
            	{
            		socket.send(packet); // Zur�cksenden vom empfangenen Paket
            	} 
            	catch (IOException e) 
            	{
            		e.printStackTrace();
            	}
            }
        }
        socket.close();
    }
    
    /**
     * Ver�ndere das empfangene Paket 
     * @param msg - empfangene Nachricht als String
     * @return - ver�nderter JSON-String
     * 
     * Die empfangene Nachricht wird als JSON geparsed und in ein JSONObject gecasted.
     * 
     */
    private String breakMsg(String msg)
    {
    	//JSOn-String in ein JSON-Object parsen und casten
    	System.out.println("JSON-String to Break: " + msg);
    	
    	JSONObject jo = (JSONObject)JSONValue.parse(msg);
    	
    	String command = (String)jo.getOrDefault("Command", null);
    	if(command != null)
    	{
    		switch (command) 
    		{
			case "query": // Wenn das JSON den Query-Command hat, dann ver�ndere die mitgeschickte SID
				String SID = (String)jo.getOrDefault("SID", null);
				if(SID != null)
				{
					jo.remove("SID");
					jo.put("SID", SID+"-changed");
				}else{ }				
				break;
			case "register": 
				String SID2 = (String)jo.getOrDefault("SID", null);
				String status = (String)jo.getOrDefault("statusD", null);
				if(SID2 != null)
				{
					jo.remove("SID");
					jo.put("SID", SID2);
					jo.put("status", status);
					
				}else{ }
				break;
			case "delete":
				String SID1 = (String)jo.getOrDefault("SID", null);
				if(SID1 != null)
				{
					jo.remove("SID");
					jo.put("SID", SID1+" deleted");
					
				}else{ }				
				break;
				
			default:
				break;
			}
    	}
    	
    	String changedJSONstring = jo.toJSONString();
    	System.out.println("Broken JSON-String: " + changedJSONstring);
    	
    	return changedJSONstring;	// JSONObject in String umwandeln.
    }
}